package com.cathay.service.domain;

public class GetLowMarketingResponse extends BaseResponse {

	private GetLowMarketingResult result;

	public GetLowMarketingResponse() {
	}

	public GetLowMarketingResponse(String code, String description) {
		super(code, description);
	}

	public GetLowMarketingResponse(String code, String message, String description, String source) {
		super(code, message, description, source);
	}

	public GetLowMarketingResult getResult() {
		return result;
	}

	public void setResult(GetLowMarketingResult result) {
		this.result = result;
	}

	@Override
	public String toString() {
		return new StringBuilder("{code=" + getCode() + ", message=" + getMessage() + ", description="
				+ getDescription() + ", source=" + getSource() + ", result=" + result + "}").toString();
	}

}
