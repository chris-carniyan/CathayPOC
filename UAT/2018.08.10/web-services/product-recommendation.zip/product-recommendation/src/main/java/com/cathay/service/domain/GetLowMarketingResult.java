package com.cathay.service.domain;

public class GetLowMarketingResult {

	private String lowMarketingInd;

	public String getLowMarketingInd() {
		return lowMarketingInd;
	}

	public void setLowMarketingInd(String lowMarketingInd) {
		this.lowMarketingInd = lowMarketingInd;
	}

	@Override
	public String toString() {
		return new StringBuilder("{lowMarketingInd=" + lowMarketingInd + "}").toString();
	}

}
