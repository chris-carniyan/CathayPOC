package com.cathay.service.domain;

public class Constants {

	// Logging scope format
	public static final String LOGGER_START = "[START @{} ({})]";
	public static final String LOGGER_END = "[END @{} ({})]";

	// Response Code
	public static final String SUCCESS_CODE = "0000";
	public static final String ERROR_CODE = "1111";
	public static final String NO_DATA_CODE = "1001";

	// Response Message
	public static final String SUCCESS_MESSAGE = "Success";
	public static final String ERROR_MESSAGE = "Error";

	// Origin or Source
	public static final String SOURCE = "Product Recommendation Service";

	// Pitch Classify
	public static final String CDU = "CDU";

	/** Error Description **/
	public static final String GENERIC_ERROR = "An error occured, please see log details";
	public static final String BAD_REQUEST = "Invalid argument / request parameters";
	public static final String TYPE_MISMATCH_ERROR = "Type mismatch error, please check you request parameters";
	public static final String RESOURCE_ACCESS_ERROR = "Resource access error, could not establish a connection to this url: %s";
	public static final String API_UNAVAILABLE = "Error connecting to API, please try again later";
	public static final String RETRIEVE_CUSTOMER_ID_HTTP_ERROR = "Error while retrieving customer id using this url %s";
	public static final String STORE_RECOMMENDATION_HTTP_ERROR = "Error while storing recommendation using this url %s";
	public static final String GET_RECOMMENDATION_API_HTTP_ERROR = "Error while getting product recommendation using this url %s";
	public static final String GET_CPIN_HTTP_ERROR = "Error while getting CPIN using this url %s";
	public static final String RETRIEVE_PRODUCT_PITCH_HTTP_ERROR = "Error while retrieving product using this url %s";
	public static final String GET_LOW_MARKETING_HTTP_ERROR = "Error while getting low marketing ind using this url %s";
	public static final String AUDIT_TRAIL_HTTP_ERROR = "Error while saving audit trail using this url %s";
	/** Error Description **/

	/** Info Message **/
	public static final String GET_CUSTOMER_ID_REQUEST = "Get customer id request: {}";
	public static final String GET_CUSTOMER_ID_RESPONSE = "Get customer id response: {}";
	public static final String STORE_RECOMMENDATION_REQUEST = "Store recommendation request: {}";
	public static final String STORE_RECOMMENDATION_RESPONSE = "Store recommendation response: {}";
	public static final String GET_RECOMMENDATION_REQUEST = "Get product recommendation request: {}";
	public static final String GET_RECOMMENDATION_RESPONSE = "Get product recommendation response: {}";
	public static final String GET_CPIN_REQUEST = "Get CPIN request: {} {}";
	public static final String GET_CPIN_RESPONSE = "Get CPIN response: {}";
	public static final String RETRIEVE_PRODUCT_PITCH_REQUEST = "Retrieve product pitch request: {}";
	public static final String RETRIEVE_PRODUCT_PITCH_RESPONSE = "Retrieve product pitch response: {}";
	public static final String GET_LOW_MARKETING_REQUEST = "Get Low Marketing request: {}";
	public static final String GET_LOW_MARKETING_RESPONSE = "Get Low Marketing response: {}";
	/** Info Message **/

	/** Audit Trail **/
	public static final String SAVING_AUDIT_TRAIL = "Saving audit trail..";
	public static final String SUCCESS = "Success";
	public static final String FAILURE = "Failure";
	public static final String AUDIT_TRAIL_START = "Audit trail START";
	public static final String AUDIT_TRAIL_END = "Audit trail END";
	/** Audit Trail **/

	private Constants() {
	}

}
