package com.cathay.service.domain;

public class GetRecommendationRequest {

	private Header header;
	private String uniqueNumber;
	private String trustKey;

	public Header getHeader() {
		return header;
	}

	public void setHeader(Header header) {
		this.header = header;
	}

	public String getTrustKey() {
		return trustKey;
	}

	public void setTrustKey(String trustKey) {
		this.trustKey = trustKey;
	}

	public String getUniqueNumber() {
		return uniqueNumber;
	}

	public void setUniqueNumber(String uniqueNumber) {
		this.uniqueNumber = uniqueNumber;
	}

	@Override
	public String toString() {
		return new StringBuilder(
				"{header=" + header + ", uniqueNumber=" + uniqueNumber + ", trustKey=" + trustKey + "}").toString();
	}

}
