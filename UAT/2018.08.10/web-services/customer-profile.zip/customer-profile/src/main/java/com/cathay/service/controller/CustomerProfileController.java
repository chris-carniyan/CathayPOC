package com.cathay.service.controller;

import java.text.ParseException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.validator.constraints.NotBlank;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.cathay.service.domain.AppAuditTrailRequest;
import com.cathay.service.domain.AuditTrailResponse;
import com.cathay.service.domain.AuthResult;
import com.cathay.service.domain.AuthenticationRequestBody;
import com.cathay.service.domain.BirthdayGreetingRequestBody;
import com.cathay.service.domain.Complaint;
import com.cathay.service.domain.Constants;
import com.cathay.service.domain.CustomerOracleResponse;
import com.cathay.service.domain.Header;
import com.cathay.service.domain.OracleAPIRequestObject;
import com.cathay.service.domain.ProfileMongoResponse;
import com.cathay.service.domain.RequestBodyBirthdayGreeting;
import com.cathay.service.domain.RequestBodyProfile;
import com.cathay.service.domain.ResponseBody;
import com.cathay.service.domain.UserAuditTrailRequest;
import com.cathay.service.service.AuthenticationService;
import com.cathay.service.utility.APIHelper;

@CrossOrigin
@RestController
@Validated
public class CustomerProfileController {

	@Autowired
	private AuthenticationService authService;
	@Value("${mongo.customer.profile}")
	private String tempMongoCustomerProfileUrl;
	@Value("${oracle.customer.profile}")
	private String tempOracleCustomerProfileUrl;
	@Value("${oracle.birthday.greeting}")
	private String birthdayGreetingUrl;
	@Value("${mongo.customer.complaints}")
	private String customerComplaintsUrl;
	@Value("${url.audit-trail-api}")
	private String saveAuditTrailUrl;

	private static final Logger LOGGER = LogManager.getLogger(CustomerProfileController.class);
	public static final String LOGIN = "LI";
	
	AppAuditTrailRequest auditRequest;
	UserAuditTrailRequest userAuditRequest;
	RestTemplate restTemplate = new RestTemplate();

	@GetMapping("${mapping.get.customer.profile}")
	public ResponseBody<ProfileMongoResponse> getCustomerProfile(@NotBlank @RequestParam(Constants.AP_ID) String apId,
			@NotBlank @RequestParam(Constants.TELLER_ID) String tellerId,
			@NotBlank @RequestParam(Constants.UNIQUE_NUMBER) String uniqueNumber,
			@NotBlank @RequestParam(Constants.BRANCH) String branch,
			@NotBlank @RequestParam(Constants.TOKEN) String token, HttpServletRequest request) {
		LOGGER.info(Constants.LOGGER_START, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		LOGGER.info(Constants.GET_CUSTOMER_PROFILE_REQUEST, apId, tellerId, uniqueNumber, branch, token);

		ResponseBody<ProfileMongoResponse> response = new ResponseBody<>();
		Header header = new Header(apId, branch, tellerId, request.getRemoteAddr());
		String url = "";
		

		try {
			AuthenticationRequestBody authenticationRequestBody = new AuthenticationRequestBody(header, uniqueNumber,
					token);
			ResponseBody<AuthResult> authResponse = authService.authenticateUniqueNumber(authenticationRequestBody);

			if (authResponse.getCode().equals(Constants.SUCCESS_CODE)) {
				UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(tempMongoCustomerProfileUrl)
						.queryParam(Constants.AP_ID, apId).queryParam(Constants.TELLER_ID, tellerId)
						.queryParam(Constants.CUSTOMER_ID, authResponse.getResult().getCustomerId())
						.queryParam(Constants.BRANCH, branch).queryParam(Constants.TOKEN, token);
				url = builder.toUriString();
				HttpEntity<?> entity = new HttpEntity<>(new HttpHeaders());
				ParameterizedTypeReference<ResponseBody<ProfileMongoResponse>> responseType = new ParameterizedTypeReference<ResponseBody<ProfileMongoResponse>>() {
				};
				ResponseEntity<ResponseBody<ProfileMongoResponse>> profileResponse = restTemplate.exchange(url,
						HttpMethod.GET, entity, responseType);

				if (profileResponse.getStatusCodeValue() == Constants.HTTP_SUCCESS_CODE) {
					response.setCode(profileResponse.getBody().getCode());
					response.setMessage(profileResponse.getBody().getMessage());
					response.setDescription(profileResponse.getBody().getDescription());
					response.setSource(profileResponse.getBody().getSource());
				} else {
					response.setCode(String.valueOf(profileResponse.getStatusCodeValue()));
					response.setMessage(profileResponse.getStatusCode().getReasonPhrase());
					response.setDescription(profileResponse.getBody().getDescription());
					response.setSource(Constants.SOURCE);
				}
			} else {
				response.setCode(authResponse.getCode());
				response.setMessage(authResponse.getMessage());
				response.setDescription(authResponse.getDescription());
				response.setSource(authResponse.getSource());
			}
		} catch (ResourceAccessException e) {
			String description = String.format(Constants.RESOURCE_ACCESS_ERROR, url);
			LOGGER.error(description, e);
			response.setCode(Constants.INTERNAL_SERVER_CODE);
			response.setMessage(Constants.ERROR_MESSAGE);
			response.setDescription(description);
			response.setSource(Constants.SOURCE);
		} catch (HttpClientErrorException e) {
			String description = String.format(Constants.HTTP_ERROR, url);
			LOGGER.error(description, e);
			response.setCode(e.getStatusCode().toString());
			response.setMessage(e.getStatusText());
			response.setDescription(description);
			response.setSource(Constants.SOURCE);
		} catch (Exception e) {
			LOGGER.error(Constants.GENERIC_ERROR, e);
			response.setCode(Constants.ERROR_CODE);
			response.setMessage(Constants.ERROR_MESSAGE);
			response.setDescription(Constants.GENERIC_ERROR);
			response.setSource(Constants.SOURCE);
		}
		
		LOGGER.info(Constants.GET_CUSTOMER_PROFILE_RESPONSE, response);
		LOGGER.info(Constants.LOGGER_END, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());

		return response;
	}

	@PostMapping("${mapping.query.customer.profile}")
	public ResponseBody<CustomerOracleResponse> queryCustomerProfile(@Valid @RequestBody RequestBodyProfile requestBody,
			HttpServletRequest request) {
		LOGGER.info(Constants.LOGGER_START, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		LOGGER.info(Constants.QUERY_CUSTOMER_PROFILE_REQUEST, requestBody);

		ResponseBody<CustomerOracleResponse> profileResponse = new ResponseBody<>();
		Header header = new Header(requestBody.getApId(), requestBody.getBranchNo(), requestBody.getTellerId(),
				request.getRemoteAddr());
		
		userAuditRequest = new UserAuditTrailRequest();
		userAuditRequest.setApId(header.getApId());
		userAuditRequest.setClientIp(header.getClientIp());
		userAuditRequest.setBranchId(header.getBranchId());
		userAuditRequest.setEmployeeId(header.getEmployeeId());
		userAuditRequest.setAction(LOGIN);
		userAuditRequest.setUserLoginAccount(header.getEmployeeId());
		userAuditRequest.setLoginServerName(header.getClientIp());
		userAuditRequest.setTxnDateTime(header.getTxnDateTime());

		try {
			AuthenticationRequestBody authenticationRequestBody = new AuthenticationRequestBody(header,
					requestBody.getUniqueNumber(), requestBody.getTrustKey());
			ResponseBody<AuthResult> authResponse = authService.authenticateUniqueNumber(authenticationRequestBody);

			if (authResponse.getCode().equals(Constants.SUCCESS_CODE)) {
				OracleAPIRequestObject requestObj = new OracleAPIRequestObject(header,
						authResponse.getResult().getCustomerId(), requestBody.getTrustKey());
				HttpEntity<OracleAPIRequestObject> entity = new HttpEntity<>(requestObj, new HttpHeaders());
				ParameterizedTypeReference<ResponseBody<CustomerOracleResponse>> responseType = new ParameterizedTypeReference<ResponseBody<CustomerOracleResponse>>() {
				};
				ResponseEntity<ResponseBody<CustomerOracleResponse>> response = restTemplate
						.exchange(tempOracleCustomerProfileUrl, HttpMethod.POST, entity, responseType);

				if (response.getStatusCodeValue() == Constants.HTTP_SUCCESS_CODE) {
					if (response.getBody().getCode().equals(Constants.SUCCESS_CODE)) {
						boolean hasGreeted = APIHelper
								.checkIfYearGreetedIsCurrentYear(response.getBody().getResult().getLastDateGreeted());
						response.getBody().getResult().setHasGreeted(hasGreeted);
						profileResponse.setResult(response.getBody().getResult());
						userAuditRequest.setDataAccess(Constants.SUCCESS_MESSAGE);
					} else {
						userAuditRequest.setDataAccess(Constants.FAILURE_MESSAGE);
					}

					profileResponse.setCode(response.getBody().getCode());
					profileResponse.setMessage(response.getBody().getMessage());
					profileResponse.setDescription(response.getBody().getDescription());
					profileResponse.setSource(response.getBody().getSource());
				} else {
					profileResponse.setCode(String.valueOf(response.getStatusCodeValue()));
					profileResponse.setMessage(response.getStatusCode().getReasonPhrase());
					profileResponse.setDescription(response.getBody().getDescription());
					profileResponse.setSource(Constants.SOURCE);
					userAuditRequest.setDataAccess(Constants.FAILURE_MESSAGE);
				}
			} else {
				profileResponse.setCode(authResponse.getCode());
				profileResponse.setMessage(authResponse.getMessage());
				profileResponse.setDescription(authResponse.getDescription());
				profileResponse.setSource(authResponse.getSource());
				userAuditRequest.setDataAccess(Constants.FAILURE_MESSAGE);
			}
		} catch (ResourceAccessException e) {
			String description = String.format(Constants.RESOURCE_ACCESS_ERROR, tempOracleCustomerProfileUrl);
			LOGGER.error(description, e);
			userAuditRequest.setDataAccess(Constants.FAILURE_MESSAGE);
			profileResponse.setCode(Constants.INTERNAL_SERVER_CODE);
			profileResponse.setMessage(Constants.ERROR_MESSAGE);
			profileResponse.setDescription(description);
			profileResponse.setSource(Constants.SOURCE);
		} catch (HttpClientErrorException e) {
			String description = String.format(Constants.HTTP_ERROR, tempOracleCustomerProfileUrl);
			LOGGER.error(description, e);
			userAuditRequest.setDataAccess(Constants.FAILURE_MESSAGE);
			profileResponse.setCode(e.getStatusCode().toString());
			profileResponse.setMessage(e.getStatusText());
			profileResponse.setDescription(description);
			profileResponse.setSource(Constants.SOURCE);
		} catch (ParseException e) {
			LOGGER.error(Constants.PARSE_ERROR, e);
			userAuditRequest.setDataAccess(Constants.FAILURE_MESSAGE);
			profileResponse.setCode(Constants.INTERNAL_SERVER_CODE);
			profileResponse.setMessage(Constants.ERROR_MESSAGE);
			profileResponse.setDescription(Constants.PARSE_ERROR);
			profileResponse.setSource(Constants.SOURCE);
		} catch (Exception e) {
			LOGGER.error(Constants.GENERIC_ERROR, e);
			userAuditRequest.setDataAccess(Constants.FAILURE_MESSAGE);
			profileResponse.setCode(Constants.ERROR_CODE);
			profileResponse.setMessage(Constants.ERROR_MESSAGE);
			profileResponse.setDescription(Constants.GENERIC_ERROR);
			profileResponse.setSource(Constants.SOURCE);
		}

		saveAuditTrail(userAuditRequest);
		LOGGER.info(Constants.QUERY_CUSTOMER_PROFILE_RESPONSE, profileResponse);
		LOGGER.info(Constants.LOGGER_END, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());

		return profileResponse;
	}

	@PostMapping("${mapping.greet.customer}")
	public ResponseBody<Object> greetCustomerOnBirthMonth(@Valid @RequestBody BirthdayGreetingRequestBody requestBody,
			HttpServletRequest request) {
		LOGGER.info(Constants.LOGGER_START, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		LOGGER.info(Constants.GREET_CUSTOMER_REQUEST, requestBody);

		ResponseBody<Object> response = new ResponseBody<>();
		Header header = new Header(requestBody.getApId(), requestBody.getBranchNo(), requestBody.getTellerId(),
				request.getRemoteAddr());

		try {
			AuthenticationRequestBody authenticationRequestBody = new AuthenticationRequestBody(header,
					requestBody.getUniqueNumber(), requestBody.getTrustKey());
			ResponseBody<AuthResult> authResponse = authService.authenticateUniqueNumber(authenticationRequestBody);

			if (authResponse.getCode().equals(Constants.SUCCESS_CODE)) {
				RequestBodyBirthdayGreeting reqBody = new RequestBodyBirthdayGreeting(header,
						authResponse.getResult().getCustomerId(), requestBody);
				HttpEntity<RequestBodyBirthdayGreeting> entity = new HttpEntity<>(reqBody, new HttpHeaders());
				ParameterizedTypeReference<ResponseBody<?>> responseType = new ParameterizedTypeReference<ResponseBody<?>>() {
				};
				ResponseEntity<ResponseBody<?>> responseEntity = restTemplate.exchange(birthdayGreetingUrl,
						HttpMethod.POST, entity, responseType);

				if (responseEntity.getStatusCodeValue() == Constants.HTTP_SUCCESS_CODE) {
					response.setCode(responseEntity.getBody().getCode());
					response.setMessage(responseEntity.getBody().getMessage());
					response.setDescription(responseEntity.getBody().getDescription());
					response.setSource(responseEntity.getBody().getSource());
				} else {
					response.setCode(String.valueOf(responseEntity.getStatusCodeValue()));
					response.setMessage(responseEntity.getStatusCode().getReasonPhrase());
					response.setDescription(responseEntity.getBody().getDescription());
					response.setSource(Constants.SOURCE);
				}
			} else {
				response.setCode(authResponse.getCode());
				response.setMessage(authResponse.getMessage());
				response.setDescription(authResponse.getDescription());
				response.setSource(authResponse.getSource());
			}
		} catch (ResourceAccessException e) {
			String description = String.format(Constants.RESOURCE_ACCESS_ERROR, birthdayGreetingUrl);
			LOGGER.error(description, e);
			response.setCode(Constants.INTERNAL_SERVER_CODE);
			response.setMessage(Constants.ERROR_MESSAGE);
			response.setDescription(description);
			response.setSource(Constants.SOURCE);
		} catch (HttpClientErrorException e) {
			String description = String.format(Constants.HTTP_ERROR, birthdayGreetingUrl);
			LOGGER.error(description, e);
			response.setCode(e.getStatusCode().toString());
			response.setMessage(e.getStatusText());
			response.setDescription(description);
			response.setSource(Constants.SOURCE);
		} catch (Exception e) {
			LOGGER.error(Constants.GENERIC_ERROR, e);
			response.setCode(Constants.ERROR_CODE);
			response.setMessage(Constants.ERROR_MESSAGE);
			response.setDescription(Constants.GENERIC_ERROR);
			response.setSource(Constants.SOURCE);
		}
		
		LOGGER.info(Constants.GREET_CUSTOMER_RESPONSE, response);
		LOGGER.info(Constants.LOGGER_END, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());

		return response;
	}

	@GetMapping("${mapping.profile.complaint}")
	public ResponseBody<List<Complaint>> getComplaintRecords(@RequestParam(Constants.AP_ID) @NotBlank String apId,
			@RequestParam(Constants.TELLER_ID) @NotBlank String tellerId,
			@RequestParam(Constants.UNIQUE_NUMBER) @NotBlank String uniqueNumber,
			@RequestParam(Constants.BRANCH) @NotBlank String branch,
			@RequestParam(Constants.TOKEN) @NotBlank String token, HttpServletRequest request) {
		LOGGER.info(Constants.LOGGER_START, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		LOGGER.info(Constants.GREET_CUSTOMER_REQUEST, apId, tellerId, uniqueNumber, branch, token);

		ResponseBody<List<Complaint>> response = new ResponseBody<>();
		Header header = new Header(apId, branch, tellerId, request.getRemoteAddr());
		String url = "";

		try {
			AuthenticationRequestBody authenticationRequestBody = new AuthenticationRequestBody(header, uniqueNumber,
					token);
			ResponseBody<AuthResult> authResponse = authService.authenticateUniqueNumber(authenticationRequestBody);

			if (authResponse.getCode().equals(Constants.SUCCESS_CODE)) {
				UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(customerComplaintsUrl)
						.queryParam(Constants.AP_ID, apId).queryParam(Constants.TELLER_ID, tellerId)
						.queryParam(Constants.CUSTOMER_ID, authResponse.getResult().getCustomerId())
						.queryParam(Constants.BRANCH, branch).queryParam(Constants.TOKEN, token);
				url = builder.toUriString();
				HttpEntity<?> entity = new HttpEntity<>(new HttpHeaders());
				ParameterizedTypeReference<ResponseBody<List<Complaint>>> responseType = new ParameterizedTypeReference<ResponseBody<List<Complaint>>>() {
				};
				ResponseEntity<ResponseBody<List<Complaint>>> profileResponse = restTemplate.exchange(url,
						HttpMethod.GET, entity, responseType);

				if (profileResponse.getStatusCodeValue() == Constants.HTTP_SUCCESS_CODE) {
					response.setCode(profileResponse.getBody().getCode());
					response.setMessage(profileResponse.getBody().getMessage());
					response.setDescription(profileResponse.getBody().getDescription());
					response.setSource(profileResponse.getBody().getSource());
				} else {
					response.setCode(String.valueOf(profileResponse.getStatusCodeValue()));
					response.setMessage(profileResponse.getStatusCode().getReasonPhrase());
					response.setDescription(profileResponse.getBody().getDescription());
					response.setSource(Constants.SOURCE);
				}
			} else {
				response.setCode(authResponse.getCode());
				response.setMessage(authResponse.getMessage());
				response.setDescription(authResponse.getDescription());
				response.setSource(authResponse.getSource());
			}
		} catch (ResourceAccessException e) {
			String description = String.format(Constants.RESOURCE_ACCESS_ERROR, url);
			LOGGER.error(description, e);
			response.setCode(Constants.INTERNAL_SERVER_CODE);
			response.setMessage(Constants.ERROR_MESSAGE);
			response.setDescription(description);
			response.setSource(Constants.SOURCE);
		} catch (HttpClientErrorException e) {
			String description = String.format(Constants.HTTP_ERROR, url);
			LOGGER.error(description, e);
			response.setCode(e.getStatusCode().toString());
			response.setMessage(e.getStatusText());
			response.setDescription(description);
			response.setSource(Constants.SOURCE);
		} catch (Exception e) {
			LOGGER.error(Constants.GENERIC_ERROR, e);
			response.setCode(Constants.ERROR_CODE);
			response.setMessage(Constants.ERROR_MESSAGE);
			response.setDescription(Constants.GENERIC_ERROR);
			response.setSource(Constants.SOURCE);
		}
		
		LOGGER.info(Constants.GREET_CUSTOMER_RESPONSE, response);
		LOGGER.info(Constants.LOGGER_END, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());

		return response;
	}
	
	private void saveAuditTrail(UserAuditTrailRequest request) {
		LOGGER.info(Constants.AUDIT_TRAIL_START);
		
		try {
			if (request != null) {
				restTemplate.postForObject(saveAuditTrailUrl, request, AuditTrailResponse.class);
				LOGGER.info(request.toString());
				LOGGER.info(Constants.AUDIT_TRAIL_SAVED);
			} else {
				LOGGER.error(Constants.AUDIT_TRAIL_REQUEST_NULL);
				LOGGER.error(Constants.AUDIT_TRAIL_NOT_SAVED);
			}
		} catch (ResourceAccessException e) {
			LOGGER.error(Constants.RESOURCE_ACCESS_ERROR, saveAuditTrailUrl);
			LOGGER.error(e);
			LOGGER.error(Constants.AUDIT_TRAIL_NOT_SAVED);
		} catch (HttpClientErrorException e) {
			LOGGER.info(request.toString());
			LOGGER.error(Constants.HTTP_ERROR, saveAuditTrailUrl);
			LOGGER.error(e);
			LOGGER.error(Constants.AUDIT_TRAIL_NOT_SAVED);
		} catch (Exception e) {
			LOGGER.error(Constants.GENERIC_ERROR, e);
			LOGGER.error(Constants.AUDIT_TRAIL_NOT_SAVED);
		}

		LOGGER.info(Constants.AUDIT_TRAIL_END);
	}
}
