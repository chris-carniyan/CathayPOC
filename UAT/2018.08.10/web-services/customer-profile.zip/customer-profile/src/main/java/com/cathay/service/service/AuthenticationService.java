package com.cathay.service.service;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

import com.cathay.service.domain.AuthResult;
import com.cathay.service.domain.AuthenticationRequestBody;
import com.cathay.service.domain.Constants;
import com.cathay.service.domain.ResponseBody;

@Service
public class AuthenticationService {

	private static final Logger LOGGER = LogManager.getLogger(AuthenticationService.class);

	@Value("${authentication.uri}")
	private String authURL;

	public ResponseBody<AuthResult> authenticateUniqueNumber(AuthenticationRequestBody request) {
		LOGGER.info(Constants.AUTHENTICATE_UNIQUE_NUMBER_REQUEST, request);
		ResponseBody<AuthResult> auth = new ResponseBody<>();

		try {
			RestTemplate restTemplate = new RestTemplate();
			HttpEntity<AuthenticationRequestBody> entity = new HttpEntity<>(request, new HttpHeaders());
			ParameterizedTypeReference<ResponseBody<AuthResult>> responseType = new ParameterizedTypeReference<ResponseBody<AuthResult>>() {
			};
			ResponseEntity<ResponseBody<AuthResult>> authResponse = restTemplate.exchange(authURL, HttpMethod.POST,
					entity, responseType);

			if (authResponse.getStatusCodeValue() == Constants.HTTP_SUCCESS_CODE) {
				if (authResponse.getBody().getCode().equals(Constants.SUCCESS_CODE)) {
					auth.setResult(authResponse.getBody().getResult());
				}

				auth.setCode(authResponse.getBody().getCode());
				auth.setDescription(authResponse.getBody().getDescription());
				auth.setMessage(authResponse.getBody().getMessage());
				auth.setSource(authResponse.getBody().getSource());
			} else {
				auth.setCode(String.valueOf(authResponse.getStatusCodeValue()));
				auth.setMessage(authResponse.getStatusCode().getReasonPhrase());
				auth.setDescription(authResponse.getBody().getDescription());
				auth.setSource(Constants.SOURCE);
			}
		} catch (ResourceAccessException e) {
			String description = String.format(Constants.RESOURCE_ACCESS_ERROR, authURL);
			LOGGER.error(description, e);
			auth.setCode(Constants.INTERNAL_SERVER_CODE);
			auth.setMessage(Constants.ERROR_MESSAGE);
			auth.setDescription(description);
			auth.setSource(Constants.SOURCE);
		} catch (HttpClientErrorException e) {
			String description = String.format(Constants.HTTP_ERROR, authURL);
			LOGGER.error(description, e);
			auth.setCode(e.getStatusCode().toString());
			auth.setMessage(e.getStatusText());
			auth.setDescription(description);
			auth.setSource(Constants.SOURCE);
		} catch (Exception e) {
			LOGGER.error(Constants.GENERIC_ERROR, e);
			auth.setCode(Constants.ERROR_CODE);
			auth.setMessage(Constants.ERROR_MESSAGE);
			auth.setDescription(Constants.GENERIC_ERROR);
			auth.setSource(Constants.SOURCE);
		}

		LOGGER.info(Constants.AUTHENTICATE_UNIQUE_NUMBER_RESPONSE, auth);
		return auth;
	}

}
