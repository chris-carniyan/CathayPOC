package com.cathay.service.controller;

import java.util.List;

import javax.validation.ConstraintViolationException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.validator.internal.engine.path.PathImpl;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.cathay.service.domain.Constants;
import com.cathay.service.domain.ResponseBody;

@ControllerAdvice
@RestController
public class ExceptionController extends ResponseEntityExceptionHandler {

	private static final Logger _LOGGER = LogManager.getLogger(ExceptionController.class);

	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {
		_LOGGER.error(Constants.BAD_REQUEST_ERROR, ex);
		ResponseBody<?> response = new ResponseBody<>(String.valueOf(status.value()), status.getReasonPhrase(),
				getInvalidArguments(ex.getBindingResult()), Constants.SOURCE);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@Override
	protected ResponseEntity<Object> handleHttpMessageNotReadable(HttpMessageNotReadableException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {
		_LOGGER.error(Constants.TYPE_MISMATCH_ERROR, ex);
		ResponseBody<?> response = new ResponseBody<>(String.valueOf(status.value()), status.getReasonPhrase(),
				Constants.TYPE_MISMATCH_ERROR, Constants.SOURCE);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@ExceptionHandler(value = { ConstraintViolationException.class })
	public ResponseEntity<Object> handleConstraintViolationException(ConstraintViolationException ex) {
		StringBuilder messages = new StringBuilder();
		messages.append("{");
		ex.getConstraintViolations().forEach(entry -> messages.append(
				" " + ((PathImpl) entry.getPropertyPath()).getLeafNode().getName() + ":" + entry.getMessage() + " "));
		messages.append("}");

		ResponseBody<Object> response = new ResponseBody<>(Constants.BAD_REQUEST_CODE,
				HttpStatus.BAD_REQUEST.getReasonPhrase(), messages.toString(), Constants.SOURCE);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	private String getInvalidArguments(BindingResult result) {
		StringBuilder builder = new StringBuilder();
		List<FieldError> errors = result.getFieldErrors();
		builder.append("Invalid Argument or Request parameters {");
		for (FieldError error : errors) {
			builder.append(" " + error.getField() + ": " + error.getDefaultMessage() + " ");
		}
		builder.append("}");
		return builder.toString();
	}

}
