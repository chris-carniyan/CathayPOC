package com.cathay.service.domain;

import java.text.SimpleDateFormat;
import java.util.Date;

public class RequestBodyBirthdayGreeting {

	private Header header;
	private String customerId;
	private String trustKey;
	private String customerName;
	private String ccVipInd;
	private String bankVipInd;
	private String recordDate;
	private String recordTime;

	public RequestBodyBirthdayGreeting() {
	}

	public RequestBodyBirthdayGreeting(Header header, String customerId,
			BirthdayGreetingRequestBody birthdayGreetingRequestBody) {
		this.header = header;
		this.customerId = customerId;
		trustKey = birthdayGreetingRequestBody.getTrustKey();
		customerName = birthdayGreetingRequestBody.getCustomerName();
		ccVipInd = birthdayGreetingRequestBody.getCcVipInd();
		bankVipInd = birthdayGreetingRequestBody.getBankVipInd();

		Date dateToday = new Date();
		String date = new SimpleDateFormat("MM/dd/yyyy").format(dateToday);
		String time = new SimpleDateFormat("HH:mm:ss").format(dateToday);

		recordDate = date;
		recordTime = time;
	}

	public Header getHeader() {
		return header;
	}

	public void setHeader(Header header) {
		this.header = header;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getTrustKey() {
		return trustKey;
	}

	public void setTrustKey(String trustKey) {
		this.trustKey = trustKey;
	}

	public String getCcVipInd() {
		return ccVipInd;
	}

	public void setCcVipInd(String ccVipInd) {
		this.ccVipInd = ccVipInd;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getBankVipInd() {
		return bankVipInd;
	}

	public void setBankVipInd(String bankVipInd) {
		this.bankVipInd = bankVipInd;
	}

	public String getRecordDate() {
		return recordDate;
	}

	public void setRecordDate(String recordDate) {
		this.recordDate = recordDate;
	}

	public String getRecordTime() {
		return recordTime;
	}

	public void setRecordTime(String recordTime) {
		this.recordTime = recordTime;
	}

	@Override
	public String toString() {
		return new StringBuilder("{header=" + header + ", customerId=" + customerId + ", trustKey=" + trustKey
				+ ", customerName=" + customerName + ", ccVipInd=" + ccVipInd + ", bankVipInd=" + bankVipInd
				+ ", recordDate=" + recordDate + ", recordTime=" + recordTime + "}").toString();
	}
}
