package com.cathay.service.domain;

public class CreditCardRecord {

	private Integer cardType;
	private String cardName;
	private String cardNo;
	private String relatedAcctNo;
	private String primaryCardInd;
	private String cardholderName;
	private String acctOpenDate;
	private Long cardExpiredDate;

	public Integer getCardType() {
		return cardType;
	}

	public void setCardType(Integer cardType) {
		this.cardType = cardType;
	}

	public String getCardName() {
		return cardName;
	}

	public void setCardName(String cardName) {
		this.cardName = cardName;
	}

	public String getCardNo() {
		return cardNo;
	}

	public void setCardNo(String cardNo) {
		this.cardNo = cardNo;
	}

	public String getRelatedAcctNo() {
		return relatedAcctNo;
	}

	public void setRelatedAcctNo(String relatedAcctNo) {
		this.relatedAcctNo = relatedAcctNo;
	}

	public String getPrimaryCardInd() {
		return primaryCardInd;
	}

	public void setPrimaryCardInd(String primaryCardInd) {
		this.primaryCardInd = primaryCardInd;
	}

	public String getCardholderName() {
		return cardholderName;
	}

	public void setCardholderName(String cardholderName) {
		this.cardholderName = cardholderName;
	}

	public String getAcctOpenDate() {
		return acctOpenDate;
	}

	public void setAcctOpenDate(String acctOpenDate) {
		this.acctOpenDate = acctOpenDate;
	}

	public Long getCardExpiredDate() {
		return cardExpiredDate;
	}

	public void setCardExpiredDate(Long cardExpiredDate) {
		this.cardExpiredDate = cardExpiredDate;
	}

	@Override
	public String toString() {
		return new StringBuilder("{cardType=" + cardType + ", cardName=" + cardName + ", cardNo=" + cardNo
				+ ", relatedAcctNo=" + relatedAcctNo + ", primaryCardInd=" + primaryCardInd + ", cardholderName="
				+ cardholderName + ", acctOpenDate=" + acctOpenDate + ", cardExpiredDate=" + cardExpiredDate + "}")
						.toString();
	}
}
