package com.cathay.service.bean;

import java.util.List;

public class TimeSlot {

	private int timeStamp;
	private List<EventsJourney> events;
	
	public TimeSlot(int timeStamp, List<EventsJourney> events) {
		super();
		this.timeStamp = timeStamp;
		this.events = events;
	}

	public int getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(int timeStamp) {
		this.timeStamp = timeStamp;
	}

	public List<EventsJourney> getEvents() {
		return events;
	}

	public void setEvents(List<EventsJourney> events) {
		this.events = events;
	}
}
