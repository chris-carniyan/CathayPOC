package com.cathay.service.bean;

import java.util.List;

public class JourneyDetail {

	private String apiCode;
	private String message;
	private List<EventsJourneyDetail> result;
	
	public JourneyDetail(String apiCode, String message, List<EventsJourneyDetail> customerJourneyDetailList) {
		super();
		this.apiCode = apiCode;
		this.message = message;
		this.result = customerJourneyDetailList;
	}

	public String getApiCode() {
		return apiCode;
	}

	public void setApiCode(String apiCode) {
		this.apiCode = apiCode;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public List<EventsJourneyDetail> getResult() {
		return result;
	}

	public void setResult(List<EventsJourneyDetail> result) {
		this.result = result;
	}
}
