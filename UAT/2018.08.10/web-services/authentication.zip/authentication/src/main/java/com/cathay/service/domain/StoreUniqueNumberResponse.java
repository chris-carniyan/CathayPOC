package com.cathay.service.domain;

public class StoreUniqueNumberResponse {

	private String code;
	private String message;
	private String description;
	private String source;
	private StoreUniqueNumberResult result;

	public StoreUniqueNumberResponse() {
		super();
	}

	public StoreUniqueNumberResponse(String code, String description) {
		super();
		this.code = code;
		message = Constants.ERROR_MESSAGE;
		this.description = description;
		source = Constants.SOURCE;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public StoreUniqueNumberResult getResult() {
		return result;
	}

	public void setResult(StoreUniqueNumberResult result) {
		this.result = result;
	}

	@Override
	public String toString() {
		return new StringBuilder("{code=" + code + ", message=" + message + ", description=" + description + ", source="
				+ source + ", result=" + result + "}").toString();
	}

}
