package com.cathay.service.domain;

public class GetTrustKeyApiRequest {

	private Header header;

	public GetTrustKeyApiRequest() {
	}

	public GetTrustKeyApiRequest(Header header) {
		this.header = header;
	}

	public Header getHeader() {
		return header;
	}

	public void setHeader(Header header) {
		this.header = header;
	}

	@Override
	public String toString() {
		return new StringBuilder("{header=" + header + "}").toString();
	}

}
