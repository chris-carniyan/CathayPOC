package com.cathay.service.domain;

import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotBlank;

public class UserAuditTrailRequest {

	@NotBlank
	private String apId;
	
	@NotBlank
	private String branchId;
	
	@NotBlank
	@Size(max = 5)
	private String employeeId;
	
	@NotBlank
	private String clientIp;
	
	@NotBlank
	private String txnDateTime;
	
	@NotBlank
	private String userLoginAccount;
	
	private String action;
	
	private String loginServerName;
	
	private String dataAccess;
	
	public UserAuditTrailRequest() {
		super();
	}

	public String getUserLoginAccount() {
		return userLoginAccount;
	}

	public void setUserLoginAccount(String userLoginAccount) {
		this.userLoginAccount = userLoginAccount;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getLoginServerName() {
		return loginServerName;
	}

	public void setLoginServerName(String loginServerName) {
		this.loginServerName = loginServerName;
	}

	public String getDataAccess() {
		return dataAccess;
	}

	public void setDataAccess(String dataAccess) {
		this.dataAccess = dataAccess;
	}

	public String getApId() {
		return apId;
	}

	public void setApId(String apId) {
		this.apId = apId;
	}

	public String getBranchId() {
		return branchId;
	}

	public void setBranchId(String branchId) {
		this.branchId = branchId;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getClientIp() {
		return clientIp;
	}

	public void setClientIp(String clientIp) {
		this.clientIp = clientIp;
	}

	public String getTxnDateTime() {
		return txnDateTime;
	}

	public void setTxnDateTime(String txnDateTime) {
		this.txnDateTime = txnDateTime;
	}

	@Override
	public String toString() {
		return "UserAuditTrailRequest [apId=" + apId + ", branchId=" + branchId + ", employeeId=" + employeeId
				+ ", clientIp=" + clientIp + ", txnDateTime=" + txnDateTime + ", userLoginAccount=" + userLoginAccount
				+ ", action=" + action + ", loginServerName=" + loginServerName + ", dataAccess=" + dataAccess + "]";
	}
	

}
