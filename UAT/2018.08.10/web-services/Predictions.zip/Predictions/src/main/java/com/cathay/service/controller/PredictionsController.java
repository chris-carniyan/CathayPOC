package com.cathay.service.controller;

import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.cathay.service.domain.AppAuditTrailRequest;
import com.cathay.service.domain.AuditTrailResponse;
import com.cathay.service.domain.BaseRequest;
import com.cathay.service.domain.Constants;
import com.cathay.service.domain.GetProblemPredictResponse;
import com.cathay.service.domain.RetrieveCustomerIdResponse;

@CrossOrigin
@RestController
public class PredictionsController {

	private static final Logger LOGGER = LogManager.getLogger(PredictionsController.class);

	@Value("${url.retrieve-customer-id-api}")
	private String retrieveCustomerIdApiUrl;

	@Value("${url.problem-predict-api}")
	private String problemPredictApiUrl;

	@Value("${url.audit-trail-api}")
	private String saveAuditTrailUrl;

	AppAuditTrailRequest auditRequest;

	@PostMapping
	public GetProblemPredictResponse getProblemPredict(@Valid @RequestBody BaseRequest request) {
		LOGGER.info(Constants.LOGGER_START, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		LOGGER.info(Constants.GET_PROBLEM_PREDICT_REQUEST, request);
		GetProblemPredictResponse response = null;
		String finalUrl = "";

		RetrieveCustomerIdResponse retrieveCustomerIdResponse = retrieveCustomerId(request);

		if (retrieveCustomerIdResponse.getCode().equals(Constants.SUCCESS_CODE)) {
			try {
				finalUrl = String.format(problemPredictApiUrl, request.getHeader().getApId(),
						request.getHeader().getEmployeeId(), retrieveCustomerIdResponse.getResult().getCustomerId(),
						request.getHeader().getBranchId(), request.getTrustKey());

				RestTemplate restTemplate = new RestTemplate();

				response = restTemplate.getForObject(finalUrl, GetProblemPredictResponse.class);
			} catch (HttpClientErrorException e) {
				String description = new StringBuilder(Constants.HTTP_CLIENT_ERROR + finalUrl).toString();
				LOGGER.error(description, e);
				response = new GetProblemPredictResponse(e.getStatusCode().toString(), description);
			} catch (Exception e) {
				LOGGER.error(Constants.GENERIC_ERROR, e);
				response = new GetProblemPredictResponse(Constants.ERROR_CODE, Constants.GENERIC_ERROR);
			}
		} else {
			response = new GetProblemPredictResponse(retrieveCustomerIdResponse);
		}

		LOGGER.info(Constants.GET_PROBLEM_PREDICT_RESPONSE, response);
		LOGGER.info(Constants.LOGGER_END, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		
		return response;
	}

	private RetrieveCustomerIdResponse retrieveCustomerId(BaseRequest request) {
		LOGGER.info(Constants.RETRIEVE_CUSTOMER_ID_REQUEST, request);
		RetrieveCustomerIdResponse response;

		try {
			RestTemplate restTemplate = new RestTemplate();
			response = restTemplate.postForObject(retrieveCustomerIdApiUrl, request, RetrieveCustomerIdResponse.class);
		} catch (HttpClientErrorException e) {
			String description = new StringBuilder(Constants.HTTP_CLIENT_ERROR + retrieveCustomerIdApiUrl).toString();
			LOGGER.error(description, e);
			response = new RetrieveCustomerIdResponse(e.getStatusCode().toString(), description);
		} catch (Exception e) {
			LOGGER.error(Constants.GENERIC_ERROR, e);
			response = new RetrieveCustomerIdResponse(Constants.ERROR_CODE, Constants.GENERIC_ERROR);
		}

		LOGGER.info(Constants.RETRIEVE_CUSTOMER_ID_RESPONSE, response);
		return response;
	}

	private void saveAuditTrail(AppAuditTrailRequest request) {
		LOGGER.info(Constants.LOGGER_START, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		try {
			if (request != null) {
				RestTemplate restTemplate = new RestTemplate();
				restTemplate.postForObject(saveAuditTrailUrl, request, AuditTrailResponse.class);
				LOGGER.info(Constants.SAVING_AUDIT_TRAIL);
			} else {
				LOGGER.error("Audit Trail Request is null");
				LOGGER.info(Constants.AUDIT_TRAIL_NOT_SAVED);
			}
		} catch (RestClientException e) {
			LOGGER.error(Constants.RESTCLIENT_EXCEPTION_OCCURED);
			LOGGER.error(Constants.URL_SOURCE, saveAuditTrailUrl);
			LOGGER.error(e);
			LOGGER.info(Constants.AUDIT_TRAIL_NOT_SAVED);
		} catch (Exception e) {
			LOGGER.error(Constants.GENERIC_ERROR, e);
			LOGGER.info(Constants.AUDIT_TRAIL_NOT_SAVED);
		}

		LOGGER.info(Constants.LOGGER_END, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
	}
}
