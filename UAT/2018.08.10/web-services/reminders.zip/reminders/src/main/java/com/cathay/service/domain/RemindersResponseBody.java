package com.cathay.service.domain;

public class RemindersResponseBody{
	private boolean anyActivities;
	private String fflag;
	private String customerId;
	private int autoPayFailCnt;
    private int autoPayRmbFailCnt;
    private int autoPayUsaFailCnt;
    private int generalNextMonExpirePs;
    private int platinumNextMonExpirePs;
    private int clearedCostcoBonusBal;
    private int y1AsianExpireMiles;
    private int y1EvaExpireMiles;
	
	public boolean isAnyActivities() {
		return anyActivities;
	}
	public void setAnyActivities(boolean anyActivities) {
		this.anyActivities = anyActivities;
	}
	public String getFflag() {
		return fflag;
	}
	public void setFflag(String fflag) {
		this.fflag = fflag;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public int getAutoPayFailCnt() {
		return autoPayFailCnt;
	}
	public void setAutoPayFailCnt(int autoPayFailCnt) {
		this.autoPayFailCnt = autoPayFailCnt;
	}
	public int getAutoPayRmbFailCnt() {
		return autoPayRmbFailCnt;
	}
	public void setAutoPayRmbFailCnt(int autoPayRmbFailCnt) {
		this.autoPayRmbFailCnt = autoPayRmbFailCnt;
	}
	public int getAutoPayUsaFailCnt() {
		return autoPayUsaFailCnt;
	}
	public void setAutoPayUsaFailCnt(int autoPayUsaFailCnt) {
		this.autoPayUsaFailCnt = autoPayUsaFailCnt;
	}
	public int getGeneralNextMonExpirePs() {
		return generalNextMonExpirePs;
	}
	public void setGeneralNextMonExpirePs(int generalNextMonExpirePs) {
		this.generalNextMonExpirePs = generalNextMonExpirePs;
	}
	public int getPlatinumNextMonExpirePs() {
		return platinumNextMonExpirePs;
	}
	public void setPlatinumNextMonExpirePs(int platinumNextMonExpirePs) {
		this.platinumNextMonExpirePs = platinumNextMonExpirePs;
	}
	public int getClearedCostcoBonusBal() {
		return clearedCostcoBonusBal;
	}
	public void setClearedCostcoBonusBal(int clearedCostcoBonusBal) {
		this.clearedCostcoBonusBal = clearedCostcoBonusBal;
	}
	public int getY1AsianExpireMiles() {
		return y1AsianExpireMiles;
	}
	public void setY1AsianExpireMiles(int y1AsianExpireMiles) {
		this.y1AsianExpireMiles = y1AsianExpireMiles;
	}
	public int getY1EvaExpireMiles() {
		return y1EvaExpireMiles;
	}
	public void setY1EvaExpireMiles(int y1EvaExpireMiles) {
		this.y1EvaExpireMiles = y1EvaExpireMiles;
	}
	@Override
	public String toString() {
		return "RemindersResponseBody [anyActivities=" + anyActivities + ", fflag=" + fflag + ", customerId="
				+ customerId + ", autoPayFailCnt=" + autoPayFailCnt + ", autoPayRmbFailCnt=" + autoPayRmbFailCnt
				+ ", autoPayUsaFailCnt=" + autoPayUsaFailCnt + ", generalNextMonExpirePs=" + generalNextMonExpirePs
				+ ", platinumNextMonExpirePs=" + platinumNextMonExpirePs + ", clearedCostcoBonusBal="
				+ clearedCostcoBonusBal + ", y1AsianExpireMiles=" + y1AsianExpireMiles + ", y1EvaExpireMiles="
				+ y1EvaExpireMiles + "]";
	}
}
