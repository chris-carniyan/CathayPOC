package com.cathay.service.domain;

public class MongoResponseBody {
	private boolean anyActivities;

	public boolean isAnyActivities() {
		return anyActivities;
	}

	public void setAnyActivities(boolean anyActivities) {
		this.anyActivities = anyActivities;
	}

	@Override
	public String toString() {
		return "MongoResponseBody [anyActivities=" + anyActivities + "]";
	}
}
