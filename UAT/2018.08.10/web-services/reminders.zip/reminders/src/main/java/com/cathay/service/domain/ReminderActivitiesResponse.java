package com.cathay.service.domain;

import java.util.List;

public class ReminderActivitiesResponse extends BaseResponse{
	private List<ReminderActivitiesResponseBody> result;

	public List<ReminderActivitiesResponseBody> getResult() {
		return result;
	}

	public void setResult(List<ReminderActivitiesResponseBody> result) {
		this.result = result;
	}

	@Override
	public String toString() {
		return "ReminderActivitiesResponse [result=" + result + "]";
	}

	
}
