package com.cathay.service.domain;

public class ODSResponseBody {
	private String fflag;
	private String customerId;
	public String getFflag() {
		return fflag;
	}
	public void setFflag(String fflag) {
		this.fflag = fflag;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	@Override
	public String toString() {
		return "ODSResponseBody [fflag=" + fflag + ", customerId=" + customerId + "]";
	}
}
