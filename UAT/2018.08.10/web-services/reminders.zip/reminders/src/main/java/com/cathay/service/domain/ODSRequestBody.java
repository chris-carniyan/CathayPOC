package com.cathay.service.domain;

public class ODSRequestBody {
	private Header header;
	private String customerId;
	private String trustKey;
	public Header getHeader() {
		return header;
	}
	public void setHeader(Header header) {
		this.header = header;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getTrustKey() {
		return trustKey;
	}
	public void setTrustKey(String trustKey) {
		this.trustKey = trustKey;
	}
	@Override
	public String toString() {
		return "ODSRequestBody [header=" + header + ", customerId=" + customerId + ", trustKey=" + trustKey + "]";
	}
	
}
