package com.cathay.audit.api.service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cathay.audit.api.domain.CommonResponse;
import com.cathay.audit.api.domain.Constants;
import com.cathay.audit.api.domain.UserAuditTrail;
import com.cathay.audit.api.repository.UserAuditTrailRepository;

@Service
public class UserAuditTrailService {

	
	private static final Logger LOGGER = LogManager.getLogger(UserAuditTrailService.class);

	@Autowired
	UserAuditTrailRepository userAuditTrailRepository;
	
	public CommonResponse insertUserAuditTrail(UserAuditTrail userAuditTrail) {
		LOGGER.info(Constants.LOGGER_START, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		
		CommonResponse responseBody = new CommonResponse();
		
		try {
			
			DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
			Date date = new Date();
			date = sdf.parse(userAuditTrail.getDateTime());
			String txnDateTime = sdf.format(date);
			userAuditTrail.setDateTime(txnDateTime);
			UserAuditTrail returnedUserAuditTrail = userAuditTrailRepository.save(userAuditTrail);
						
			if (returnedUserAuditTrail == null) {
				LOGGER.error(Constants.USER_AUDIT_TRAIL_SAVE_UNSUCCESSFUL);
				return new CommonResponse(Constants.ERROR_CODE, Constants.ERROR_MESSAGE,
						Constants.USER_AUDIT_TRAIL_SAVE_UNSUCCESSFUL, Constants.SOURCE);
			}
			
			responseBody = new CommonResponse(Constants.SUCCESS_CODE, Constants.SUCCESS_MESSAGE);
			
		} catch (Exception e) {
			LOGGER.error(Constants.GENERIC_ERROR, e);
			responseBody = new CommonResponse(Constants.ERROR_CODE, Constants.ERROR_MESSAGE, Constants.GENERIC_ERROR,
					Constants.SOURCE);
		}
		
		
		LOGGER.info(Constants.LOGGER_END, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		return responseBody;
	}
}
