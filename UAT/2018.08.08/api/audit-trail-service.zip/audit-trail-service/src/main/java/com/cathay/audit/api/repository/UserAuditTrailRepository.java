package com.cathay.audit.api.repository;

import org.springframework.data.repository.CrudRepository;

import com.cathay.audit.api.domain.UserAuditTrail;

public interface UserAuditTrailRepository extends CrudRepository<UserAuditTrail, Long> {

}
