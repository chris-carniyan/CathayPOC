package com.cathay.audit.api.receiver;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

import com.cathay.audit.api.domain.AppAuditTrail;
import com.cathay.audit.api.domain.AppAuditTrailRequest;
import com.cathay.audit.api.domain.CommonResponse;
import com.cathay.audit.api.domain.Constants;
import com.cathay.audit.api.domain.UserAuditTrail;
import com.cathay.audit.api.domain.UserAuditTrailRequest;
import com.cathay.audit.api.receiver.QueueMessageReceiver;
import com.cathay.audit.api.service.AppAuditTrailService;
import com.cathay.audit.api.service.UserAuditTrailService;

@Component
public class QueueMessageReceiver {

	private static final Logger LOGGER = LogManager.getLogger(QueueMessageReceiver.class);

	@Autowired
	AppAuditTrailService appAuditTrailService;

	@Autowired
	UserAuditTrailService userAuditTrailService;

	@JmsListener(destination = Constants.APP_AUDIT_TRAIL_DESTINATION, containerFactory = "myFactory")
	public void receiveMessage(AppAuditTrailRequest request) {
		LOGGER.info(Constants.LOGGER_START, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());

		LOGGER.info("Queue message received: " + request.toString());

		CommonResponse appResponseBody = appAuditTrailService.insertAppAuditTrail(new AppAuditTrail(request));

		if (appResponseBody.getCode().equals(Constants.SUCCESS_CODE)) {
			LOGGER.info(Constants.SAVE_APP_AUDIT_TRAIL_RESPONSE, appResponseBody);
		} else {
			LOGGER.error(Constants.ERROR_CODE);
		}

		LOGGER.info(Constants.LOGGER_END, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
	}

	@JmsListener(destination = Constants.USER_AUDIT_TRAIL_DESTINATION, containerFactory = "myFactory")
	public void receiveMessage(UserAuditTrailRequest request) {
		LOGGER.info(Constants.LOGGER_START, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());

		LOGGER.info("Queue user audit trail message received: " + request.toString());

		CommonResponse userResponseBody = userAuditTrailService.insertUserAuditTrail(new UserAuditTrail(request));

		if (userResponseBody.getCode().equals(Constants.SUCCESS_CODE)) {
			LOGGER.info(Constants.SAVE_USER_AUDIT_TRAIL_RESPONSE, userResponseBody);
		}

		LOGGER.info(Constants.LOGGER_END, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
	}

}
