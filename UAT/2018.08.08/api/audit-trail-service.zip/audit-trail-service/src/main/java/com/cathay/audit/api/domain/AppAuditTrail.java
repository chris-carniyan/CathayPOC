package com.cathay.audit.api.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.cathay.audit.api.domain.AppAuditTrailRequest;

@Entity
@Table(name="APP_AUDIT_LOG")
public class AppAuditTrail {

	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "crm_app_audit_trail_seq")
	@SequenceGenerator(sequenceName = "crm_app_audit_trail_seq", initialValue = 1, allocationSize = 1, name = "crm_app_audit_trail_seq")
	@Column(name="SEQ_NO")
	private Long seq_no;
	
	@Column(name="USER_LOGIN_ACCOUNT")
	private String userLoginAccount;
	
	@Column(name="SOURCE_IP")
	private String sourceIp;
	
	@Column(name="DATE_TIME")
	private String dateTime;
	
	@Column(name="APPLICATION_NAME")
	private String appName;
	
	@Column(name="ACTION_TYPE")
	private String actionType;
	
	@Column(name="PROGRAM_NAME")
	private String programName;
	
	@Column(name="ACCESS_OBJECT_TYPE")
	private String accessObjectType;

	@Column(name="KEY_FIELD")
	private String keyField;
	
	@Column(name="COMPANY_TYPE")
	private String companyType;
	
	@Column(name="BRANCH_NO")
	private String branchNo;
	
	@Column(name="EMPLOYEE_ID")
	private String employeeId;
	
	@Column(name="ROLE")
	private String role;
	
	@Column(name="RECORD_COUNT")
	private int recordCount;
	
	@Column(name="DATA_ACCESS")
	private String dataAccess;
	
	@Column(name="OLD_VALUE")
	private String oldValue;
	
	@Column(name="NEW_VALUE")
	private String newValue;
	
	@Column(name="SQL_STATEMENT")
	private String sqlStatement;
	
	public AppAuditTrail() {
		super();
	}
	
	public AppAuditTrail(AppAuditTrailRequest auditTrailRequest) {
		super();
		userLoginAccount = auditTrailRequest.getUserLoginAccount();
//		sourceIp = auditTrailRequest.getSourceIp();
		sourceIp = auditTrailRequest.getHeader().getClientIp();
//		dateTime = auditTrailRequest.getDateTime();
		dateTime = auditTrailRequest.getHeader().getTxnDateTime();
		appName = auditTrailRequest.getHeader().getApId();
		actionType = auditTrailRequest.getActionType();
		programName = auditTrailRequest.getProgramName();
		accessObjectType = auditTrailRequest.getAccessObjectType();
		keyField = auditTrailRequest.getKeyField();
		companyType = auditTrailRequest.getCompanyType();
//		branchNo = auditTrailRequest.getBranchNo();
		branchNo = auditTrailRequest.getHeader().getBranchId();
//		employeeId = auditTrailRequest.getEmployeeId();
		employeeId = auditTrailRequest.getHeader().getEmployeeId();
		role = auditTrailRequest.getRole();
		recordCount = auditTrailRequest.getRecordCount();
		dataAccess = auditTrailRequest.getDataAccess();
		oldValue = auditTrailRequest.getOldValue();
		newValue = auditTrailRequest.getNewValue();
		sqlStatement = auditTrailRequest.getSqlStatement();
	}

	public String getUserLoginAccount() {
		return userLoginAccount;
	}

	public void setUserLoginAccount(String userLoginAccount) {
		this.userLoginAccount = userLoginAccount;
	}

	public String getSourceIp() {
		return sourceIp;
	}

	public void setSourceIp(String sourceIp) {
		this.sourceIp = sourceIp;
	}

	public String getDateTime() {
		return dateTime;
	}

	public void setDateTime(String dateTime) {
		this.dateTime = dateTime;
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public String getActionType() {
		return actionType;
	}

	public void setActionType(String actionType) {
		this.actionType = actionType;
	}

	public String getProgramName() {
		return programName;
	}

	public void setProgramName(String programName) {
		this.programName = programName;
	}

	public String getAccessObjectType() {
		return accessObjectType;
	}

	public void setAccessObjectType(String accessObjectType) {
		this.accessObjectType = accessObjectType;
	}

	public String getKeyField() {
		return keyField;
	}

	public void setKeyField(String keyField) {
		this.keyField = keyField;
	}

	public String getCompanyType() {
		return companyType;
	}

	public void setCompanyType(String companyType) {
		this.companyType = companyType;
	}

	public String getBranchNo() {
		return branchNo;
	}

	public void setBranchNo(String branchNo) {
		this.branchNo = branchNo;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public int getRecordCount() {
		return recordCount;
	}

	public void setRecordCount(int recordCount) {
		this.recordCount = recordCount;
	}

	public String getDataAccess() {
		return dataAccess;
	}

	public void setDataAccess(String dataAccess) {
		this.dataAccess = dataAccess;
	}

	public String getOldValue() {
		return oldValue;
	}

	public void setOldValue(String oldValue) {
		this.oldValue = oldValue;
	}

	public String getNewValue() {
		return newValue;
	}

	public void setNewValue(String newValue) {
		this.newValue = newValue;
	}

	public String getSqlStatement() {
		return sqlStatement;
	}

	public void setSqlStatement(String sqlStatement) {
		this.sqlStatement = sqlStatement;
	}

	public Long getSeq_no() {
		return seq_no;
	}

	public void setSeq_no(Long seq_no) {
		this.seq_no = seq_no;
	}

	@Override
	public String toString() {
		return "AppAuditTrail [seq_no=" + seq_no + ", userLoginAccount=" + userLoginAccount + ", sourceIp=" + sourceIp
				+ ", dateTime=" + dateTime + ", appName=" + appName + ", actionType=" + actionType + ", programName="
				+ programName + ", accessObjectType=" + accessObjectType + ", keyField=" + keyField + ", companyType="
				+ companyType + ", branchNo=" + branchNo + ", employeeId=" + employeeId + ", role=" + role
				+ ", recordCount=" + recordCount + ", dataAccess=" + dataAccess + ", oldValue=" + oldValue
				+ ", newValue=" + newValue + ", sqlStatement=" + sqlStatement + "]";
	}
	
	
	

}
