package com.cathay.audit.api.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="USER_AUDIT_LOG")
public class UserAuditTrail {

	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "crm_user_audit_trail_seq")
	@SequenceGenerator(sequenceName = "crm_user_audit_trail_seq", initialValue = 1, allocationSize = 1, name = "crm_user_audit_trail_seq")
	@Column(name="SEQ_NO")
	private Long seq_no;
	
	@Column(name = "USER_LOGIN_ACCOUNT")
	private String userLoginAccount;
	
	@Column(name = "SOURCE_IP")
	private String sourceIp;
	
	@Column(name = "ACTION")
	private String action;
	
	@Column(name = "DATE_TIME")
	private String dateTime;
	
	@Column(name="AP_ID")
	private String ap_id;
	
	@Column(name = "LOGIN_SERVER_NAME")
	private String loginServerName;
	
	@Column(name = "DATA_ACCESS")
	private String dataAccess;
	
	public UserAuditTrail() {
		super();
	}
	
	public UserAuditTrail(UserAuditTrailRequest auditTrailRequest) {
		super();
		userLoginAccount = auditTrailRequest.getEmployeeId();
		sourceIp = auditTrailRequest.getClientIp();
		action = auditTrailRequest.getAction();
		dateTime = auditTrailRequest.getTxnDateTime();
		ap_id = auditTrailRequest.getApId();
		loginServerName = auditTrailRequest.getLoginServerName();
		dataAccess = auditTrailRequest.getDataAccess();
	}

	public String getUserLoginAccount() {
		return userLoginAccount;
	}

	public void setUserLoginAccount(String userLoginAccount) {
		this.userLoginAccount = userLoginAccount;
	}

	public String getSourceIp() {
		return sourceIp;
	}

	public void setSourceIp(String sourceIp) {
		this.sourceIp = sourceIp;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getDateTime() {		
		return dateTime;
	}

	public void setDateTime(String dateTime) {
		this.dateTime = dateTime;
	}

	public String getAp_id() {
		return ap_id;
	}

	public void setAp_id(String ap_id) {
		this.ap_id = ap_id;
	}

	public String getLoginServerName() {
		return loginServerName;
	}

	public void setLoginServerName(String loginServerName) {
		this.loginServerName = loginServerName;
	}

	public String getDataAccess() {
		return dataAccess;
	}

	public void setDataAccess(String dataAccess) {
		this.dataAccess = dataAccess;
	}

	public Long getSeq_no() {
		return seq_no;
	}

	public void setSeq_no(Long seq_no) {
		this.seq_no = seq_no;
	}

	@Override
	public String toString() {
		return "UserAuditTrail [seq_no=" + seq_no + ", userLoginAccount=" + userLoginAccount + ", sourceIp=" + sourceIp
				+ ", action=" + action + ", dateTime=" + dateTime + ", ap_id=" + ap_id + ", loginServerName="
				+ loginServerName + ", dataAccess=" + dataAccess + "]";
	}
	
	
	

}
