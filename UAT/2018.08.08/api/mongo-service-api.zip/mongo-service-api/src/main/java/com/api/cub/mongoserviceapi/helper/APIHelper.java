package com.api.cub.mongoserviceapi.helper;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.api.cub.mongoserviceapi.domain.EncryptDataRequest;
import com.api.cub.mongoserviceapi.domain.Header;
import com.api.cub.mongoserviceapi.domain.RequestTokenObject;
import com.api.cub.mongoserviceapi.domain.Timeline;

public class APIHelper {
	private APIHelper() {
		throw new IllegalStateException("APIHelper class");
	}

	private static final Logger logger = LogManager.getLogger(APIHelper.class);

	/**
	 * Method that converts date to epoch format
	 * 
	 * @param date
	 * @return long
	 */
	public static long dateToEpoch(Date date) {
		long epochDate = 0;
		if (date != null) {
			epochDate = date.getTime() / 1000;
		} else {
			// do something
		}
		return epochDate;
	}

	/**
	 * Returns an object that specifies the timespan scope which is two(2) weeks by
	 * default.
	 * 
	 * @param date
	 * @return Timeline
	 */
	public static Timeline getTimelineScope(Date date) {
		Timeline timeline = new Timeline();
		Calendar calendar = Calendar.getInstance();
		if (date != null) {
			calendar.setTime(date);
			calendar.add(Calendar.DATE, -13);
			long currentDate = dateToEpoch(date);
			long lastTwoWeeksDate = dateToEpoch(calendar.getTime());
			timeline.setLastTwoWeeksDate(lastTwoWeeksDate);
			timeline.setCurrentDate(currentDate);
		}
		return timeline;
	}

	public static RequestTokenObject requestObjectTokenBuilder(String apiId, String tellerId, String branch,
			String token) {

		logger.info("parameters: [ap_id:{}, teller_id:{}, branch:{}, token:{}]", apiId, tellerId, branch, token);
		RequestTokenObject requestTokenObject = new RequestTokenObject();
		Header headerObj = new Header();
		headerObj.setApId(apiId);
		headerObj.setBranchId(branch);
		headerObj.setEmployeeId(tellerId);
		headerObj.setClientIp("127.0.0.1");
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		String txnDateTime = sdf.format(date);
		headerObj.setTxnDateTime(txnDateTime);

		requestTokenObject.setTrustKey(token);
		requestTokenObject.setHeader(headerObj);

		return requestTokenObject;
	}

	public static long convertStringDateTimeToEpoch(long date, String time) throws ParseException {
		long dateTimeEpoch = 0;
		SimpleDateFormat dateFormatter = new SimpleDateFormat("MM/dd/yyyy");
		String dateTimeString = dateFormatter.format(new Date(date * 1000)) + " " + time;
		logger.info("dateTimeString: " + dateTimeString);
		SimpleDateFormat epochFormatter = new SimpleDateFormat("MM/dd/yyyy HH:mm");
		Date dateTime = epochFormatter.parse(dateTimeString);
		dateTimeEpoch = dateToEpoch(dateTime);
		return dateTimeEpoch;
	}

	public static Boolean getFlag(String flag) {
		Boolean isFlag = false;
		if (flag != null && flag.equalsIgnoreCase("Y")) {
			isFlag = true;
		} else if (flag == null) {
			isFlag = null;
		}
		return isFlag;
	}

	public static EncryptDataRequest encryptDataRequestBuilder(String apId, String branch, String tellerId,
			String clientIp, String customerId, String plainDataType, String token) {
		logger.info(
				"parameters: [ap_id: {},branch: {}, teller_id: {}, client_ip: {}, plain_data: {}, plain_data_type: {}, token: {}]",
				apId, branch, tellerId, clientIp, customerId, plainDataType, token);
		EncryptDataRequest encryptDataRequest = new EncryptDataRequest();
		Header headerObj = new Header();
		headerObj.setApId(apId);
		headerObj.setBranchId(branch);
		headerObj.setEmployeeId(tellerId);
		headerObj.setClientIp(clientIp);
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		String txnDateTime = sdf.format(date);
		headerObj.setTxnDateTime(txnDateTime);
		encryptDataRequest.setHeader(headerObj);
		encryptDataRequest.setPlainData(customerId);
		encryptDataRequest.setPlainDataType(plainDataType);
		encryptDataRequest.setTrustKey(token);
		return encryptDataRequest;
	}

}
