package com.api.cub.mongoserviceapi.service;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import com.api.cub.mongoserviceapi.domain.ProblemPrediction;
import com.api.cub.mongoserviceapi.domain.ResponseObject;
import com.api.cub.mongoserviceapi.helper.ExceptionDetails;
import com.api.cub.mongoserviceapi.repository.ProblemPredictionMongoRepository;

@Service
public class ProblemPredictionService {
	private static final Logger logger = LogManager.getLogger(ProblemPredictionService.class);
	private static final String LOGGER_START = "[START @{} ({})]";
	private static final String LOGGER_END = "[END @{} ({})]";
	private static final String CODE_SUCCESS = "0000";
	private static final String CODE_ERROR = "1111";
	private static final String CODE_NO_DATA = "1001";
	private static final String MESSAGE_SUCCESS = "SUCCESS";
	private static final String MESSAGE_ERROR = "ERROR";
	private static final String DESC_NO_DATA = "No records found";
	
	@Autowired
	ProblemPredictionMongoRepository problemPredictionMongoRepository;
	
	public ResponseObject<ProblemPrediction> getProblemPrediction(String customerId) {
		ResponseObject<ProblemPrediction> problemPredictionResponse = new ResponseObject<>();
		ProblemPrediction problemPrediction = new ProblemPrediction();
		
		logger.info(LOGGER_START, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		
		try {
			problemPrediction = problemPredictionMongoRepository.showProblemPredictionByCustomerId(customerId);
			if(problemPrediction != null) {
				logger.info("problemPrediction is: " + problemPrediction.toString());
				problemPredictionResponse.setCode(CODE_SUCCESS);
				problemPredictionResponse.setMessage(MESSAGE_SUCCESS);
				problemPredictionResponse.setDescription("");
				problemPredictionResponse.setSource("");
				problemPredictionResponse.setResult(problemPrediction.getQuestions());
			} else {
				problemPredictionResponse.setCode(CODE_NO_DATA);
				problemPredictionResponse.setMessage(MESSAGE_ERROR);
				problemPredictionResponse.setDescription(DESC_NO_DATA);
				problemPredictionResponse.setSource("Mongo-API ProblemPredictionService.java [method]getProblemPrediction()");
			}
		} catch (DataAccessException e) {
			ExceptionDetails exceptionDetails = new ExceptionDetails(e);
			problemPredictionResponse.setCode(CODE_ERROR);
			problemPredictionResponse.setMessage(MESSAGE_ERROR);
			problemPredictionResponse.setDescription(exceptionDetails.getMessage());
			problemPredictionResponse.setSource("Mongo-API ProblemPredictionService.java [method]getProblemPrediction()");
			logger.error(exceptionDetails.toString());
		}
		
		logger.info(LOGGER_END, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		
		return problemPredictionResponse;
	}
}
