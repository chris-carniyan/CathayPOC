package com.api.cub.mongoserviceapi.domain;

public class ParameterValidationResponse {
	private String errorMessage;
	private boolean validParams;
	private String code;
	
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public boolean isValidParams() {
		return validParams;
	}
	public void setValidParams(boolean validParams) {
		this.validParams = validParams;
	}
	@Override
	public String toString() {
		return "ParameterValidationResponse [errorMessage=" + errorMessage + ", validParams=" + validParams + ", code="
				+ code + "]";
	}
}
