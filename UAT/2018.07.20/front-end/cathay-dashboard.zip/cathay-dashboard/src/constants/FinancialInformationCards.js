export default {
  financialInformationCards: [
    {
      name: "primaryCcCount",
      value: "正卡",
      subValue: ""
    },
    {
      name: "primarySecondCcCount",
      value: "附卡",
      subValue: "(給家人)"
    },

    {
      name: "businessCcCount",
      value: "商務卡",
      subValue: ""
    },
    {
      name: "secondaryCcCount",
      value: "附卡",
      subValue: ""
    }
  ]
};
