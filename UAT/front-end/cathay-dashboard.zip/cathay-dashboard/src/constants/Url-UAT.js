/* UAT */
export default {
  CUSTOMER_JOURNEY_CALENDAR: (
    ap_id,
    teller_id,
    unique_number,
    branch,
    token
  ) => {
    return `https://twrhcrm:8443/customer-journey/journey?ap_id=${ap_id}&teller_id=${teller_id}&unique_number=${unique_number}&branch=${branch}&token=${token}`;
  },

  CUSTOMER_JOURNEY_DETAIL: (
    channel,
    date,
    ap_id,
    teller_id,
    unique_number,
    branch,
    token
  ) => {
    return `https://twrhcrm:8443/customer-journey/journey/detail?channel=${channel}&date=${date}&ap_id=${ap_id}&teller_id=${teller_id}&unique_number=${unique_number}&branch=${branch}&token=${token}`;
  },

  STORE_PRODUCT_RECOMMENDATION:
    "https://twrhcrm:8443/product-recommendation/storeRecommendation",

  CUSTOMER_PROFILE_ORACLE:
    "https://twrhcrm:8443/customer-profile/getCustomerProfile",

  GET_PRODUCT_RECOMMENDATION:
    "https://twrhcrm:8443/product-recommendation/getRecommendationAndCPIN",

  CUSTOMER_PROFILE_MONGO: (ap_id, teller_id, unique_number, branch, token) => {
    return `https://twrhcrm:8443/customer-profile/profile?ap_id=${ap_id}&teller_id=${teller_id}&unique_number=${unique_number}&branch=${branch}&token=${token}`;
  },

  CUSTOMER_PROFILE_GREET_CUSTOMER_ORACLE:
    "https://twrhcrm:8443/customer-profile/greetCustomerBirthday",

  FINANCIAL_PRODUCTS:
    "https://twrhcrm:8443/financial-product/getCustomerFinancialProducts",

  GET_CARDS: `https://twrhcrm:8443/financial-product/getCards`,

  GET_PAYMENT_HABITS: `https://twrhcrm:8443/financial-product/getPaymentHabits`,

  GET_AUTO_ACCOUNT_DEBITING: `https://twrhcrm:8443/financial-product/getAutoAccountDebiting`,

  GET_UTILITY_PAYMENTS: `https://twrhcrm:8443/financial-product/getUtilityBillsPayments`,

  GET_SAVINGS: `https://twrhcrm:8443/financial-product/getSavings`,

  CUSTOMER_PROFILE_COMPLAINTS_MONGO: (
    apId,
    employeeId,
    uniqueNumber,
    branchId,
    trustKey
  ) =>
    `https://twrhcrm:8443/customer-profile/profile/complaint?ap_id=${apId}&teller_id=${employeeId}&unique_number=${uniqueNumber}&branch=${branchId}&token=${trustKey}`,

  RETRIEVE_PRODUCT_PITCH:
    "https://twrhcrm:8443/product-recommendation/retrieveProductPitch",

  GET_PROBLEM_PREDICTIONS: "https://twrhcrm:8443/predictions/problem-predict",

  VALIDATE_TOKEN: "https://twrhcrm:8443/auth/validateTrustKey",

  GET_REMINDER_GIFT_CAMPAIGN:
    "https://twrhcrm:8443/reminders/getReminderActivitiesOrGiftDetails",

  GET_REMINDER_ANY_ACTIVITIES:
    "https://twrhcrm:8443/reminders/getRemindersAnyActivities",

  GET_REMINDER_POINTS: "https://twrhcrm:8443/reminders/getRemindersPoints",

  GET_REMINDER_FLAG: "https://twrhcrm:8443/reminders/getRemindersFlag"
};
