export default {
  getQueryParameters: () => {
    const queryParameter = {};
    const queryString = window.location.search.substring(1).split("&");

    queryString.forEach(params => {
      let temp = params.split("=");
      queryParameter[temp[0]] = temp[1];
    });

    const {
      apId,
      branchId,
      employeeId,
      clientIp,
      uniqueNumber,
      trustKey
    } = queryParameter;

    return {
      header: {
        apId,
        branchId,
        employeeId,
        clientIp,
        txnDateTime: +new Date()
      },
      uniqueNumber,
      trustKey
    };
  }
};
