import React, { Component, Fragment } from "react";
import { Icon, Modal, Table, Dimmer, Loader } from "semantic-ui-react";
import classes from "../../../assets/css/FinancialInformation.css";
import Constants from "../../../constants/Common";
import moment from "moment";
import Helper from "../../../utility/Helper";

class PaymentsHabitsModal extends Component {
  constructor(props) {
    super(props);
    this.state = {
      modalOpen: false,
      loading: false
    };
  }

  handleOpen = async () => {
    this.setState({ loading: true, modalOpen: true });
    setTimeout(() => {
      this.setState({ loading: false });
    }, Constants.MODAL_LOADING);
  };

  handleClose = () => this.setState({ modalOpen: false });

  render() {
    let { loading } = this.state;
    const { hasPaymentHabits } = this.props;
    let records = hasPaymentHabits.records;
    let content = (
      <Fragment>
        <div className="modalHeader">繳款明細</div>
        <div className={classes.watermarkPaymentHabits}>
          {Helper.getQueryParameters().header.employeeId}
        </div>
        <Table basic="very" textAlign="left" className={classes.tableStyle}>
          <Table.Header>
            <Table.Row>
              <Table.HeaderCell>帳單月份</Table.HeaderCell>
              <Table.HeaderCell>繳款日期</Table.HeaderCell>
              <Table.HeaderCell>繳款方式</Table.HeaderCell>
              <Table.HeaderCell>繳款金額</Table.HeaderCell>
            </Table.Row>
          </Table.Header>
          <Table.Body>
            {records.map((d, i) => (
              <Table.Row key={i}>
                <Table.Cell>
                  {d.stmtYearMonth.match(/\d+/g)
                    ? moment(d.stmtYearMonth, "YYYYDD").format("YYYY/DD")
                    : d.stmtYearMonth}
                </Table.Cell>
                <Table.Cell>
                  {moment(d.txnDate).format("YYYY/MM/DD")}
                </Table.Cell>
                <Table.Cell>{d.payChannelTypeDesc}</Table.Cell>
                <Table.Cell>
                  {d.payAmt.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}
                </Table.Cell>
              </Table.Row>
            ))}
          </Table.Body>
        </Table>
      </Fragment>
    );

    return (
      <span>
        <Modal
          size="small"
          trigger={
            <span
              className={classes.paymentHabits}
              onClick={this.handleOpen}
              open={this.state.modalOpen}
              onClose={this.handleClose}
            >
              <span className={classes.paymentTitle}>繳款 習慣</span>
              <Icon
                className={classes.chevronRight}
                style={{
                  color: "#11a847"
                }}
                name="chevron right"
                basic="true"
              />
            </span>
          }
          closeIcon
        >
          <Modal.Content scrolling>
            {loading ? (
              <div className="modalLoaderDimmer">
                <Dimmer active>
                  <Loader content="Loading" />
                </Dimmer>
              </div>
            ) : null}
            {!loading ? content : null}
          </Modal.Content>
        </Modal>
      </span>
    );
  }
}

export default PaymentsHabitsModal;
