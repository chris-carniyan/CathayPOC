package com.cathay.api.domain;

import java.sql.Timestamp;
import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "crm_cust_uniquenum")
public class CustUniqueNumber {

	@Id
	@Column(name = "unique_no")
	private String uniqueNumber;

	@Column(name = "customer_id")
	private String customerId;

	@Column(name = "apid")
	private String apId;

	@Column(name = "date_time")
	private Timestamp dateTime;

	@Column(name = "expire_time")
	private Timestamp expireTime;

	public CustUniqueNumber() {
	}

	public CustUniqueNumber(String uniqueNumber, String customerId, String apId, int expireHours) {
		this.uniqueNumber = uniqueNumber;
		this.customerId = customerId;
		this.apId = apId;

		Timestamp original = new Timestamp(System.currentTimeMillis());
		Calendar cal = Calendar.getInstance();
		cal.setTimeInMillis(original.getTime());
		cal.add(Calendar.HOUR_OF_DAY, expireHours);

		dateTime = original;
		expireTime = new Timestamp(cal.getTime().getTime());
	}

	public String getUniqueNumber() {
		return uniqueNumber;
	}

	public void setUniqueNumber(String uniqueNumber) {
		this.uniqueNumber = uniqueNumber;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getApId() {
		return apId;
	}

	public void setApId(String apId) {
		this.apId = apId;
	}

	public Timestamp getDateTime() {
		return dateTime;
	}

	public void setDateTime(Timestamp dateTime) {
		this.dateTime = dateTime;
	}

	public Timestamp getExpireTime() {
		return expireTime;
	}

	public void setExpireTime(Timestamp expireTime) {
		this.expireTime = expireTime;
	}

	@Override
	public String toString() {
		return new StringBuilder("{uniqueNumber=" + uniqueNumber + ", customerId=" + customerId + ", apId=" + apId
				+ ", dateTime=" + dateTime + ", expireTime=" + expireTime + "}").toString();
	}

}