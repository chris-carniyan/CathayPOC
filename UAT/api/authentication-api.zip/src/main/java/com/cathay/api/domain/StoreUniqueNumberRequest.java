package com.cathay.api.domain;

import javax.validation.Valid;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotBlank;

public class StoreUniqueNumberRequest {

	@Valid
	private Header header;
	@NotBlank
	@Size(max = 36)
	private String uniqueNumber;
	@NotBlank
	@Size(max = 18)
	private String customerId;
	@NotBlank
	private String trustKey;

	public void setHeader(Header header) {
		this.header = header;
	}

	public Header getHeader() {
		return header;
	}

	public void setUniqueNumber(String uniqueNumber) {
		this.uniqueNumber = uniqueNumber;
	}

	public String getUniqueNumber() {
		return uniqueNumber;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setTrustKey(String trustKey) {
		this.trustKey = trustKey;
	}

	public String getTrustKey() {
		return trustKey;
	}

	@Override
	public String toString() {
		return new StringBuilder("{header=" + header + ", uniqueNumber=" + uniqueNumber + ", customerId=" + customerId
				+ ", trustKey=" + trustKey + "}").toString();
	}

}
