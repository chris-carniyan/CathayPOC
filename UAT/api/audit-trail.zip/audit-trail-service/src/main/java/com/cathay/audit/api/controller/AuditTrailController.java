package com.cathay.audit.api.controller;

import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.cathay.audit.api.domain.AppAuditTrailRequest;
import com.cathay.audit.api.domain.CommonResponse;
import com.cathay.audit.api.domain.Constants;
import com.cathay.audit.api.domain.UserAuditTrailRequest;

@CrossOrigin
@RestController
public class AuditTrailController {

	private static final Logger LOGGER = LogManager.getLogger(AuditTrailController.class);
	
	@Autowired private JmsTemplate jmsTemplate;
	
	@CrossOrigin
	@ResponseBody
	@PostMapping("/saveAppAuditTrail")
	public CommonResponse insertAppAuditTrail(@RequestBody @Valid AppAuditTrailRequest request) {
		LOGGER.info(Constants.LOGGER_START, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		LOGGER.info(Constants.SAVE_AUDIT_TRAIL_REQUEST, request);
		
		CommonResponse responseBody = new CommonResponse();
		
		try {
			LOGGER.info("Send audit trail transaction.");
			jmsTemplate.convertAndSend(Constants.APP_AUDIT_TRAIL_DESTINATION, request);
		} catch (Exception e) {
			responseBody = new CommonResponse(Constants.ERROR_CODE, Constants.AUDIT_TRAIL_GENERIC_ERROR);
		}
		

		LOGGER.info(Constants.LOGGER_END, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		return responseBody;
	}
	
	@CrossOrigin
	@ResponseBody
	@PostMapping("/saveUserAuditTrail")
	public CommonResponse insertUserAuditTrail(@RequestBody @Valid UserAuditTrailRequest request) {
		LOGGER.info(Constants.LOGGER_START, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		
		CommonResponse responseBody = new CommonResponse();
		
		try {
			LOGGER.info("Send audit trail transaction.");
			jmsTemplate.convertAndSend(Constants.USER_AUDIT_TRAIL_DESTINATION, request);
		} catch (Exception e) {
			responseBody = new CommonResponse(Constants.ERROR_CODE, Constants.AUDIT_TRAIL_GENERIC_ERROR);
		}
		

		LOGGER.info(Constants.LOGGER_END, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		return responseBody;
	}
}
