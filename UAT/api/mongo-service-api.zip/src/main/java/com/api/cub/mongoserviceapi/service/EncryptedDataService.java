package com.api.cub.mongoserviceapi.service;

import java.util.Collections;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.api.cub.mongoserviceapi.domain.EncryptDataRequest;
import com.api.cub.mongoserviceapi.domain.EncryptDataResponse;
import com.api.cub.mongoserviceapi.helper.LogServiceHelper;

@Service
public class EncryptedDataService {
	private static final Logger logger = LogManager.getLogger(EncryptedDataService.class);
	
	@Value("${encrypted.data.url}")
	private String encryptedDataUrl;
	
	public EncryptDataResponse encryptData(EncryptDataRequest encryptDataRequest) {
		logger.info("*START* {}", LogServiceHelper.getCurrentClassAndMethodName());
		EncryptDataResponse encryptDataResponse = new EncryptDataResponse();
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		
		try {
			headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<Object> requestBody = new HttpEntity<>(encryptDataRequest, headers);
			encryptDataResponse = restTemplate.postForObject(encryptedDataUrl, requestBody, EncryptDataResponse.class);
			logger.info("encryptDataResponse is: " + encryptDataResponse.toString());
			
		} catch (HttpClientErrorException e) {
			encryptDataResponse.setCode("1111");
			encryptDataResponse.setDesc("RestClientException occured in EncryptedDataService.java [method] encryptData()");
		}
		logger.info("*END* {}", LogServiceHelper.getCurrentClassAndMethodName());
		return encryptDataResponse;
	}
	
	public String getPlainDataType(String customerId) {
		String plainDataType;
		if(Character.isLetter(customerId.charAt(0))) {
			plainDataType = "A01";
			logger.info("plainDataType: {}", plainDataType);
			return plainDataType;
		} else {
			plainDataType = "A02";
			logger.info("plainDataType: {}", plainDataType);
			return plainDataType;
		}
	}
}
