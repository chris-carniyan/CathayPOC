package com.api.cub.mongoserviceapi.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.api.cub.mongoserviceapi.domain.Reminder;

public interface ReminderMongoRepository extends MongoRepository<Reminder, String> {
	@Query(value="{'_id' : ?0}")
	Reminder showReminderByCustomerId(String customerId);
}
