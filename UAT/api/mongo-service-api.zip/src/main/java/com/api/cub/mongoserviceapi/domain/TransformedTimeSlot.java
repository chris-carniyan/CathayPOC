package com.api.cub.mongoserviceapi.domain;

import java.util.List;

public class TransformedTimeSlot {
	private long timestamp;
	private List<TransformedEvent> events;
	
	public long getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(long timestamp) {
		this.timestamp = timestamp;
	}
	public List<TransformedEvent> getEvents() {
		return events;
	}
	public void setEvents(List<TransformedEvent> events) {
		this.events = events;
	}
}
