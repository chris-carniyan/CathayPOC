package com.api.cub.mongoserviceapi.config;

import java.util.Arrays;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.config.AbstractMongoConfiguration;

import com.cathaybk.encrypt.Decrypter;
import com.mongodb.Mongo;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.MongoCredential;
import com.mongodb.ServerAddress;

@Configuration
public class DbConfig extends AbstractMongoConfiguration {

	private static final Logger LOGGER = LogManager.getLogger(DbConfig.class);

	@Value("${db.fileName}")
	private String fileName;

	@Value("${db.key}")
	private String dbKey;

	@Value("${spring.data.mongodb.host}")
	private String mongoHost;

	@Value("${spring.data.mongodb.port}")
	private Integer mongoPort;

	@Value("${spring.data.mongodb.database}")
	private String mongoDB;

	@Value("${spring.profiles.active}")
	private String activeProfile;

	@Value("${spring.data.mongodb.username}")
	private String username;

	@Value("${spring.data.mongodb.password}")
	private String password;
	
	@Value("${spring.data.mongodb.uri}")
	private String uri;

	@Override
	@Bean
	@ConfigurationProperties(prefix = "spring.data")
	public Mongo mongo() throws Exception {
		LOGGER.warn("Loading " + activeProfile.toUpperCase() + " database config...");
		MongoCredential credential = null;
		String[] dbInfo = {};

		if (activeProfile.equals("dev")) {
			credential = MongoCredential.createCredential(username, mongoDB, password.toCharArray());
		} else {
			dbInfo = Decrypter.getPassword(fileName, dbKey);
			credential = MongoCredential.createCredential(dbInfo[0], mongoDB, dbInfo[1].toCharArray());
		}
		
		if (activeProfile.equals("prod")) {
			String finalUri = String.format(uri, dbInfo[0], dbInfo[1]);
			LOGGER.warn("Final uri: ", finalUri);
			return new MongoClient(new MongoClientURI(finalUri));
		} else {
			return new MongoClient(new ServerAddress(mongoHost, mongoPort), Arrays.asList(credential));
		}
	}

	@Override
	protected String getDatabaseName() {
		return mongoDB;
	}
}
