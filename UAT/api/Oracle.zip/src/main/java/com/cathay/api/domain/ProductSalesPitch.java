package com.cathay.api.domain;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "v_crm_pitch")
public class ProductSalesPitch {

	@Id
	@JsonIgnore
	@Column(name = "seq_no")
	private Long seqNo;

	@Column(name = "pitch_classify")
	@JsonIgnore
	private String pitchClassify;

	@Column(name = "product_pitch")
	private String productPitch;

	@Column(name = "start_date")
	@JsonIgnore
	private Date startDate;

	@Column(name = "end_date")
	@JsonIgnore
	private Date endDate;

	public Long getSeqNo() {
		return seqNo;
	}

	public void setSeqNo(Long seqNo) {
		this.seqNo = seqNo;
	}

	public String getPitchClassify() {
		return pitchClassify;
	}

	public void setPitchClassify(String pitchClassify) {
		this.pitchClassify = pitchClassify;
	}

	public String getProductPitch() {
		return productPitch;
	}

	public void setProductPitch(String productPitch) {
		this.productPitch = productPitch;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	@Override
	public String toString() {
		return new StringBuilder("{seqNo=" + seqNo + ", pitchClassify=" + pitchClassify + ", productPitch="
				+ productPitch + ", startDate=" + startDate + ", endDate=" + endDate + "}").toString();
	}

}
