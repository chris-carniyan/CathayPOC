package com.cathay.api.service;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import com.cathay.api.domain.Constants;
import com.cathay.api.domain.GiftDetails;
import com.cathay.api.domain.GiftFile;
import com.cathay.api.domain.TransactionSequence;
import com.cathay.api.domain.CommonResponse;
import com.cathay.api.repository.GiftDetailsRepository;
import com.cathay.api.repository.GiftFileRepository;

@Service
public class ReminderService {

	private static final Logger LOGGER = LogManager.getLogger(ReminderService.class);

	@Autowired
	GiftDetailsRepository giftDetailsRepository;

	@Autowired
	GiftFileRepository giftFileRepository;

	public CommonResponse getGiftDetails(String campaignCode) {
		CommonResponse response = null;

		try {
			GiftFile giftFile = giftFileRepository.findFirstByOrderByDateCreatedDesc();

			if (giftFile != null) {
				GiftDetails giftDetails = giftDetailsRepository.findOneByPidAndFileSeqNo(campaignCode,
						giftFile.getSeqNo());

				if (giftDetails != null) {
					response = new CommonResponse(giftDetails);
				} else {
					response = new CommonResponse(Constants.NO_DATA_CODE, Constants.ERROR_MESSAGE,
							Constants.NO_DATA_ERROR, Constants.SOURCE);
				}
			} else {
				response = new CommonResponse(Constants.NO_DATA_CODE, Constants.ERROR_MESSAGE,
						Constants.CAMPAIGN_NOT_FOUND, Constants.SOURCE);
			}
		} catch (DataAccessException e) {
			LOGGER.error(Constants.DATA_ACCESS_ERROR, e);
			response = new CommonResponse(Constants.DATA_ACCESS_CODE, Constants.ERROR_MESSAGE,
					Constants.DATA_ACCESS_ERROR, Constants.SOURCE);
		} catch (Exception e) {
			LOGGER.error(Constants.GENERIC_ERROR, e);
			response = new CommonResponse(Constants.ERROR_CODE, Constants.ERROR_MESSAGE, Constants.GENERIC_ERROR,
					Constants.SOURCE);
		}

		return response;
	}

	public CommonResponse getTransactionSequence() {
		CommonResponse response = null;

		try {
			Long transactionSequence = giftFileRepository.getCurrentTransaction();

			if (transactionSequence != null) {
				response = new CommonResponse(new TransactionSequence(transactionSequence));
			} else {
				response = new CommonResponse(Constants.NO_DATA_CODE, Constants.ERROR_MESSAGE, Constants.NO_DATA_ERROR,
						Constants.SOURCE);
			}
		} catch (DataAccessException e) {
			LOGGER.error(Constants.DATA_ACCESS_ERROR, e);
			response = new CommonResponse(Constants.DATA_ACCESS_CODE, Constants.ERROR_MESSAGE,
					Constants.DATA_ACCESS_ERROR, Constants.SOURCE);
		} catch (Exception e) {
			LOGGER.error(Constants.GENERIC_ERROR, e);
			response = new CommonResponse(Constants.ERROR_CODE, Constants.ERROR_MESSAGE, Constants.GENERIC_ERROR,
					Constants.SOURCE);
		}

		return response;
	}

}
