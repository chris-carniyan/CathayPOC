package com.cathay.api.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "crm_bir_rpt")
public class CustomerGreetings {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "crm_bir_rpt_sequence")
	@SequenceGenerator(sequenceName = "crm_bir_rpt_sequence", initialValue = 1, allocationSize = 1, name = "crm_bir_rpt_sequence")
	@Column(name = "seq_no")
	private Long seqNo;

	@Column(name = "customer_id")
	private String customerId;

	@Column(name = "record_date")
	private String recordDate;

	@Column(name = "record_time")
	private String recordTime;

	@Column(name = "customer_name")
	private String customerName;

	@Column(name = "cc_vip_ind")
	private String ccVipInd;

	@Column(name = "bank_vip_ind")
	private String bankVipind;

	@Column(name = "cti_employee_no")
	private String ctiEmployeeNo;

	public CustomerGreetings() {
		super();
	}
	
	public CustomerGreetings(CustomerGreetingsRequest request) {
		super();
		customerId = request.getCustomerId();
		customerName = request.getCustomerName();
		bankVipind = request.getBankVipInd();
		recordDate = request.getRecordDate();
		recordTime = request.getRecordTime();
		ctiEmployeeNo = request.getHeader().getEmployeeId();
		ccVipInd = request.getCcVipInd();
	}


	public CustomerGreetings(String customerId, String dateGreeted) {
		super();
		this.customerId = customerId;
		this.recordDate = dateGreeted;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCcVipInd() {
		return ccVipInd;
	}

	public void setCcVipInd(String ccVipInd) {
		this.ccVipInd = ccVipInd;
	}

	public String getBankVipind() {
		return bankVipind;
	}

	public void setBankVipind(String bankVipind) {
		this.bankVipind = bankVipind;
	}

	public String getCtiEmployeeNo() {
		return ctiEmployeeNo;
	}

	public void setCtiEmployeeNo(String ctiEmployeeNo) {
		this.ctiEmployeeNo = ctiEmployeeNo;
	}

	public Long getSeqNo() {
		return seqNo;
	}

	public void setSeqNo(Long seqNo) {
		this.seqNo = seqNo;
	}

	public String getRecordDate() {
		return recordDate;
	}

	public void setRecordDate(String recordDate) {
		this.recordDate = recordDate;
	}

	public String getRecordTime() {
		return recordTime;
	}

	public void setRecordTime(String recordTime) {
		this.recordTime = recordTime;
	}

	@Override
	public String toString() {
		return new StringBuilder("{seqNo=" + seqNo + ", customerId=" + customerId + ", recordDate=" + recordDate
				+ ", recordTime=" + recordTime + ", customerName=" + customerName + ", ccVipInd=" + ccVipInd
				+ ", bankVipind=" + bankVipind + ", ctiEmployeeNo=" + ctiEmployeeNo + "}").toString();
	}

}
