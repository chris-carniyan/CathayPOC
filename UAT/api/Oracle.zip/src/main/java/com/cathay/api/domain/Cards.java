package com.cathay.api.domain;

import java.util.List;

public class Cards {

	private String customerId;
	private int countNo;
	private List<CardsRecords> records;
	
	public Cards(String customerId, List<CardsRecords> records, int countNo) {
		super();
		this.customerId = customerId;
		this.countNo = countNo;
		this.records = records;
	}

	public Cards() {
		super();
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public int getCountNo() {
		return countNo;
	}

	public void setCountNo(int countNo) {
		this.countNo = countNo;
	}

	public List<CardsRecords> getRecords() {
		return records;
	}

	public void setRecords(List<CardsRecords> records) {
		this.records = records;
	}

	@Override
	public String toString() {
		return "Cards [customerId=" + customerId + ", countNo=" + countNo + ", records=" + records + "]";
	}
}
