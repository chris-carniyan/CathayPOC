package com.cathay.api.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.cathay.api.domain.ProductSalesPitch;

public interface ProductSalesPitchRepository extends CrudRepository<ProductSalesPitch, Long> {

	@Query(nativeQuery = true)
	ProductSalesPitch findByPitchClassifyAndStartDateIsNullAndEndDateIsNull(String pitchClassify);

	@Query(nativeQuery = true)
	ProductSalesPitch findByPitchClassifyAndStartDateNotNullAndEndDateNotNull(String pitchClassify);

}
