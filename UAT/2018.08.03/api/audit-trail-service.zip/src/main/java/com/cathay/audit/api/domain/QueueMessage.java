package com.cathay.audit.api.domain;

public class QueueMessage {

	private String queueTimestamp;
	
	public QueueMessage() {
		
	}
	
	public QueueMessage(String queueTimestamp) {
        this.queueTimestamp = queueTimestamp;
    }

	public String getQueueTimestamp() {
		return queueTimestamp;
	}

	public void setQueueTimestamp(String queueTimestamp) {
		this.queueTimestamp = queueTimestamp;
	}

	@Override
	public String toString() {
		return "QueueMessage [queueTimestamp=" + queueTimestamp + "]";
	}

}
