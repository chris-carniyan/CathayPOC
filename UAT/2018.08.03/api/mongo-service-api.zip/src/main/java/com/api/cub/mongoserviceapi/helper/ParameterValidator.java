package com.api.cub.mongoserviceapi.helper;

import com.api.cub.mongoserviceapi.domain.ParameterValidationResponse;

public class ParameterValidator {
	
	private static final String CODE_INVALID_PARAMETERS = "400";
	
	private ParameterValidator() {
	    throw new IllegalStateException("ParameterValidator class");
	  }
	public static ParameterValidationResponse validateParameters(String apID, String tellerId, String customerId, String branch, String token) {
		ParameterValidationResponse validResponse = new ParameterValidationResponse();
		validResponse.setValidParams(false);
		
		if(!checkIfStringIsNotNullOrEmpty(apID)) {
			validResponse.setCode(CODE_INVALID_PARAMETERS);
			validResponse.setErrorMessage("Query ap_id is empty.");
		}else if(!checkIfStringIsNotNullOrEmpty(tellerId)) {
			validResponse.setCode(CODE_INVALID_PARAMETERS);
			validResponse.setErrorMessage("Query teller_id is empty.");
		}else if(!checkIfStringIsNotNullOrEmpty(customerId)) {
			validResponse.setCode(CODE_INVALID_PARAMETERS);
			validResponse.setErrorMessage("Query customer_id is empty.");
		}else if(!checkIfStringIsNotNullOrEmpty(branch)) {
			validResponse.setCode(CODE_INVALID_PARAMETERS);
			validResponse.setErrorMessage("Query branch is empty.");
		}else if(!checkIfStringIsNotNullOrEmpty(token)) {
			validResponse.setCode(CODE_INVALID_PARAMETERS);
			validResponse.setErrorMessage("Query token is empty.");
		}else {
			validResponse.setCode("0000");
			validResponse.setValidParams(true);
		}
		return validResponse;
	}
	
	public static ParameterValidationResponse validateCustomerJourneyDetailsParams(String channel, long date, String apID, String tellerId, String customerId, String branch, String token) {
		ParameterValidationResponse validResponse = new ParameterValidationResponse();
		validResponse.setValidParams(false);
		
		if(!checkIfStringIsNotNullOrEmpty(channel)) {
			validResponse.setCode(CODE_INVALID_PARAMETERS);
			validResponse.setErrorMessage("Query channel is empty.");
		}else if(date <= 0) {
			validResponse.setCode(CODE_INVALID_PARAMETERS);
			validResponse.setErrorMessage("Query date is empty.");
		}else if(!checkIfStringIsNotNullOrEmpty(apID)) {
			validResponse.setCode(CODE_INVALID_PARAMETERS);
			validResponse.setErrorMessage("Query ap_id is empty.");
		}else if(!checkIfStringIsNotNullOrEmpty(tellerId)) {
			validResponse.setCode(CODE_INVALID_PARAMETERS);
			validResponse.setErrorMessage("Query teller_id is empty.");
		}else if(!checkIfStringIsNotNullOrEmpty(customerId)) {
			validResponse.setCode(CODE_INVALID_PARAMETERS);
			validResponse.setErrorMessage("Query customer_id is empty.");
		}else if(!checkIfStringIsNotNullOrEmpty(branch)) {
			validResponse.setCode(CODE_INVALID_PARAMETERS);
			validResponse.setErrorMessage("Query branch is empty.");
		}else if(!checkIfStringIsNotNullOrEmpty(token)) {
			validResponse.setCode(CODE_INVALID_PARAMETERS);
			validResponse.setErrorMessage("Query token is empty.");
		}else {
			validResponse.setCode("0000");
			validResponse.setValidParams(true);
		}
		return validResponse;
	}
	private static boolean checkIfStringIsNotNullOrEmpty(String stringToBeValidated) {
		boolean isNotNull = false;
		if(!stringToBeValidated.equals("".trim()) && stringToBeValidated != null) {
			isNotNull = true;
		}
		return isNotNull;
	}
}
