package com.api.cub.mongoserviceapi.domain;

public class RequestTokenObject {
	private Header header;
	private String trustKey;

	public Header getHeader() {
		return header;
	}

	public void setHeader(Header header) {
		this.header = header;
	}

	public String getTrustKey() {
		return trustKey;
	}

	public void setTrustKey(String trustKey) {
		this.trustKey = trustKey;
	}

	@Override
	public String toString() {
		return "RequestTokenObject [header=" + header + ", trustKey=" + trustKey + "]";
	}
}
