package com.cathay.api.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "v_crm_acct_cc")
public class CardsRecords {

	@JsonIgnore
	@Column(name = "customer_id")
	private String customerId;

	@Column(name = "card_type_code")
	private String cardType;

	@Column(name = "card_name")
	private String cardName;

	@Id
	@Column(name = "card_nbr")
	private String cardNo;

	@Column(name = "related_acct_nbr")
	private String relatedAcctNo;

	@Column(name = "primary_card_ind")
	private String primaryCardInd;

	@JsonIgnore
	@Column(name = "cardholder_cust_id")
	private String cardholderId;

	@Column(name = "cardholder_cust_name")
	private String cardholderName;

	@Column(name = "acct_open_date")
	private String acctOpenDate;

	@Column(name = "card_expire_date")
	private String cardExpiredDate;

	public CardsRecords() {
		super();
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getCardType() {
		return cardType;
	}

	public void setCardType(String cardType) {
		this.cardType = cardType;
	}

	public String getCardName() {
		return cardName;
	}

	public void setCardName(String cardName) {
		this.cardName = cardName;
	}

	public String getCardNo() {
		return cardNo;
	}

	public void setCardNo(String cardNo) {
		this.cardNo = cardNo;
	}

	public String getRelatedAcctNo() {
		return relatedAcctNo;
	}

	public void setRelatedAcctNo(String relatedAcctNo) {
		this.relatedAcctNo = relatedAcctNo;
	}

	public String getPrimaryCardInd() {
		return primaryCardInd;
	}

	public void setPrimaryCardInd(String primaryCardInd) {
		this.primaryCardInd = primaryCardInd;
	}

	public String getCardholderName() {
		return cardholderName;
	}

	public void setCardholderName(String cardholderName) {
		this.cardholderName = cardholderName;
	}

	public String getAcctOpenDate() {
		return acctOpenDate;
	}

	public void setAcctOpenDate(String acctOpenDate) {
		this.acctOpenDate = acctOpenDate;
	}

	public String getCardExpiredDate() {
		return cardExpiredDate;
	}

	public void setCardExpiredDate(String cardExpiredDate) {
		this.cardExpiredDate = cardExpiredDate;
	}

	@Override
	public String toString() {
		return "CardRecords [customerId=" + customerId + ", cardType=" + cardType + ", cardName=" + cardName
				+ ", cardNo=" + cardNo + ", relatedAcctNo=" + relatedAcctNo + ", primaryCardInd=" + primaryCardInd
				+ ", cardholderName=" + cardholderName + ", acctOpenDate=" + acctOpenDate + ", cardExpiredDate="
				+ cardExpiredDate + "]";
	}

}
