package com.cathay.api.service;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import com.cathay.api.domain.CommonResponse;
import com.cathay.api.domain.Constants;
import com.cathay.api.domain.CustomerGreetings;
import com.cathay.api.domain.CustomerProfile;
import com.cathay.api.repository.CustomerGreetingsRepository;
import com.cathay.api.repository.CustomerProfileRepository;

@Service
public class CustomerProfileService {

	private static final Logger LOGGER = LogManager.getLogger(CustomerProfileService.class);

	@Autowired
	CustomerProfileRepository customerProfileRepository;

	@Autowired
	CustomerGreetingsRepository customerGreetingsRepository;

	public CommonResponse getCustomerProfile(String customerId) {
		CommonResponse response = null;

		try {
			CustomerProfile customerProfile = customerProfileRepository.findByCustomerId(customerId);

			if (customerProfile != null) {
				CustomerGreetings customerGreetings = customerGreetingsRepository
						.findTopByCustomerIdOrderBySeqNoDesc(customerId);

				if (customerGreetings != null) {
					customerProfile.setLastDateGreeted(customerGreetings.getRecordDate());
				}

				response = new CommonResponse(Constants.SUCCESS_CODE, Constants.SUCCESS_MESSAGE, customerProfile);
			} else {
				response = new CommonResponse(Constants.NO_DATA_CODE, Constants.ERROR_MESSAGE, Constants.NO_DATA_ERROR,
						Constants.SOURCE);
			}
		} catch (DataAccessException e) {
			LOGGER.error(Constants.DATA_ACCESS_ERROR, e);
			response = new CommonResponse(Constants.DATA_ACCESS_CODE, Constants.ERROR_MESSAGE,
					Constants.DATA_ACCESS_ERROR, Constants.SOURCE);
		} catch (Exception e) {
			LOGGER.error(Constants.GENERIC_ERROR, e);
			response = new CommonResponse(Constants.ERROR_CODE, Constants.ERROR_MESSAGE, Constants.GENERIC_ERROR,
					Constants.SOURCE);
		}

		return response;
	}

	public CommonResponse customerGreetings(CustomerGreetings customerGreetings) {
		CommonResponse response = null;

		try {
			CustomerGreetings returnedCustomerGreetings = customerGreetingsRepository.save(customerGreetings);

			if (returnedCustomerGreetings == null) {
				response = new CommonResponse(Constants.INSERT_ERROR_CODE, Constants.ERROR_MESSAGE,
						Constants.CUSTOMER_GREETINGS_SAVE_UNSUCCESSFUL, Constants.SOURCE);
			} else {
				response = new CommonResponse(Constants.SUCCESS_CODE, Constants.SUCCESS_MESSAGE);
			}
		} catch (DataAccessException e) {
			LOGGER.error(Constants.DATA_ACCESS_ERROR, e);
			response = new CommonResponse(Constants.DATA_ACCESS_CODE, Constants.ERROR_MESSAGE,
					Constants.DATA_ACCESS_ERROR, Constants.SOURCE);
		} catch (Exception e) {
			LOGGER.error(Constants.GENERIC_ERROR, e);
			response = new CommonResponse(Constants.ERROR_CODE, Constants.ERROR_MESSAGE, Constants.GENERIC_ERROR,
					Constants.SOURCE);
		}

		return response;
	}

}
