package com.cathay.api.domain;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "v_crm_event_cc_auto_pay")
public class AutoAccountDebitingRecords {
	
	@JsonIgnore
	@Column(name = "customer_id")
	private String customerId;
	
	@Column(name = "bank_desc")
	private String bankDesc;
	
	@Id
	@Column(name = "acct_nbr")
	private String acctNbr;
	
	@Column(name = "autopay_percent")
	private double autopayPercent;
	
	@Column(name = "valid_date")
	private Date validDate;
	
	public AutoAccountDebitingRecords() {
		super();
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getBankDesc() {
		return bankDesc;
	}

	public void setBankDesc(String bankDesc) {
		this.bankDesc = bankDesc;
	}

	public String getAcctNbr() {
		return acctNbr;
	}

	public void setAcctNbr(String acctNbr) {
		this.acctNbr = acctNbr;
	}

	public double getAutopayPercent() {
		return autopayPercent;
	}

	public void setAutopayPercent(double autopayPercent) {
		this.autopayPercent = autopayPercent;
	}

	public Date getValidDate() {
		return validDate;
	}

	public void setValidDate(Date validDate) {
		this.validDate = validDate;
	}

	@Override
	public String toString() {
		return "AutoAccountDebitingRecords [customerId=" + customerId + ", bankDesc=" + bankDesc + ", acctNbr="
				+ acctNbr + ", autopayPercent=" + autopayPercent + ", validDate=" + validDate + "]";
	}
}
