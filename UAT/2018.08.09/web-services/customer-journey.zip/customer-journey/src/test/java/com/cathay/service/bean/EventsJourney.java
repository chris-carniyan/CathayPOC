package com.cathay.service.bean;

public class EventsJourney {

	private String channel;

	public EventsJourney(String channel) {
		super();
		this.channel = channel;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}
}
