package com.cathay.service.domain;

public class ValidateTrustKeyResponse {

	private Header header;
	private String code;
	private String desc;
	private String trustKey;

	public ValidateTrustKeyResponse() {
		super();
	}

	public ValidateTrustKeyResponse(Header header, String code, String desc, String trustKey) {
		super();
		this.header = header;
		this.code = code;
		this.desc = desc;
		this.trustKey = trustKey;
	}

	public Header getHeader() {
		return header;
	}

	public void setHeader(Header header) {
		this.header = header;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public String getTrustKey() {
		return trustKey;
	}

	public void setTrustKey(String trustKey) {
		this.trustKey = trustKey;
	}

	@Override
	public String toString() {
		return new StringBuilder(
				"{header=" + header + ", code=" + code + ", desc=" + desc + ", trustKey=" + trustKey + "}").toString();
	}

}
