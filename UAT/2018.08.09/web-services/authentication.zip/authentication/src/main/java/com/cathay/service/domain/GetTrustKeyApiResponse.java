package com.cathay.service.domain;

import java.sql.Timestamp;

public class GetTrustKeyApiResponse {

	private Header header;
	private String code;
	private String desc;
	private String trustKey;

	private Timestamp expiredTime;
	public GetTrustKeyApiResponse() {
		super();
	}

	public GetTrustKeyApiResponse(String code, String desc) {
		super();
		this.code = code;
		this.desc = desc;
	}

	public GetTrustKeyApiResponse(Header header, String code, String desc) {
		super();
		this.header = header;
		this.code = code;
		this.desc = desc;
	}

	public Header getHeader() {
		return header;
	}

	public void setHeader(Header header) {
		this.header = header;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public String getTrustKey() {
		return trustKey;
	}

	public void setTrustKey(String trustKey) {
		this.trustKey = trustKey;
	}

	public Timestamp getExpiredTime() {
		return expiredTime;
	}

	public void setExpiredTime(Timestamp expiredTime) {
		this.expiredTime = expiredTime;
	}

	@Override
	public String toString() {
		return new StringBuilder("{header=" + header + ", code=" + code + ", desc=" + desc + ", trustKey=" + trustKey
				+ ", expiredTime=" + expiredTime + "}").toString();
	}

}
