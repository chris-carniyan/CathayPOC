package com.cathay.service.domain;

import org.hibernate.validator.constraints.NotBlank;

public class FinancialProduct2ndLayerRequest extends FinancialProductRequest {

	@NotBlank
	private String queryCardInd;

	public String getQueryCardInd() {
		return queryCardInd;
	}

	public void setQueryCardInd(String queryCardInd) {
		this.queryCardInd = queryCardInd;
	}

	@Override
	public String toString() {
		return new StringBuilder("{header=" + getHeader() + ", trustKey=" + getTrustKey() + ", uniqueNumber="
				+ getUniqueNumber() + ", queryCardInd=" + queryCardInd + "}").toString();
	}

}
