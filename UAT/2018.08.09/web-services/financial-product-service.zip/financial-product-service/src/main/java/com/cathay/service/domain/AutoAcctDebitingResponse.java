package com.cathay.service.domain;

public class AutoAcctDebitingResponse extends BaseResponse {

	private AutoAcctDebiting result;

	public AutoAcctDebitingResponse() {
		super();
	}

	public AutoAcctDebitingResponse(String code, String description) {
		super(code, description);
	}

	public AutoAcctDebitingResponse(String code, String message, String description, String source) {
		super(code, message, description, source);
	}

	public AutoAcctDebiting getResult() {
		return result;
	}

	public void setResult(AutoAcctDebiting result) {
		this.result = result;
	}

	@Override
	public String toString() {
		return new StringBuilder("{code=" + getCode() + ", message=" + getMessage() + ", description="
				+ getDescription() + ", source=" + getSource() + ", result=" + result + "}").toString();
	}

}
