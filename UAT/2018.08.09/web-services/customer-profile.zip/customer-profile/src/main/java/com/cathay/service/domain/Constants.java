package com.cathay.service.domain;

public class Constants {

	// Logging scope format
	public static final String LOGGER_START = "[START @{} ({})]";
	public static final String LOGGER_END = "[END @{} ({})]";

	// Request Parameters
	public static final String AP_ID = "ap_id";
	public static final String TELLER_ID = "teller_id";
	public static final String UNIQUE_NUMBER = "unique_number";
	public static final String CUSTOMER_ID = "customer_id";
	public static final String BRANCH = "branch";
	public static final String TOKEN = "token";

	// Response Code
	public static final String SUCCESS_CODE = "0000";
	public static final String ERROR_CODE = "1111";
	public static final String NO_DATA_CODE = "1001";
	public static final int HTTP_SUCCESS_CODE = 200;
	public static final String BAD_REQUEST_CODE = "400";
	public static final String INTERNAL_SERVER_CODE = "500";

	// Response Message
	public static final String SUCCESS_MESSAGE = "Success";
	public static final String ERROR_MESSAGE = "Error";
	public static final String FAILURE_MESSAGE = "Failure";

	// Origin or Source
	public static final String SOURCE = "Customer Profile Service";

	/** Error Description **/
	public static final String GENERIC_ERROR = "An error occured, please see log details";
	public static final String DATA_ACCESS_ERROR = "Data access error, there is a problem encountered with the database";
	public static final String BAD_REQUEST_ERROR = "Invalid argument or request parameters";
	public static final String TYPE_MISMATCH_ERROR = "Type mismatch error, please check your request parameters";
	public static final String NO_DATA_ERROR = "No records found";
	public static final String PARSE_ERROR = "Parse error, could not parse date please check your data";

	public static final String RESOURCE_ACCESS_ERROR = "Resource access error, could not established a connection to this url {}";
	public static final String HTTP_ERROR = "Error connecting to this url {}";
	/** Error Description **/

	/** Info Message **/
	public static final String AUTHENTICATE_UNIQUE_NUMBER_REQUEST = "Authenticate unique number request {}";
	public static final String AUTHENTICATE_UNIQUE_NUMBER_RESPONSE = "Authenticate unique number response {}";

	public static final String GET_CUSTOMER_PROFILE_REQUEST = "Get customer profile request [apId={}, tellerId={}, uniqueNumber={}, branch={}, token={}]";
	public static final String GET_CUSTOMER_PROFILE_RESPONSE = "Get customer profile response {}";

	public static final String QUERY_CUSTOMER_PROFILE_REQUEST = "Query customer profile request {}";
	public static final String QUERY_CUSTOMER_PROFILE_RESPONSE = "Query customer profile response {}";

	public static final String GREET_CUSTOMER_REQUEST = "Greet customer request {}";
	public static final String GREET_CUSTOMER_RESPONSE = "Greet customer response {}";

	public static final String GET_CUSTOMER_COMPLAINTS_REQUEST = "Get customer complaints request [apId={}, tellerId={}, uniqueNumber={}, branch={}, token={}]";
	public static final String GET_CUSTOMER_COMPLAINTS_RESPONSE = "Get customer complaints response {}";
	
	public static final String AUDIT_TRAIL_START = "Audit trail START";
	public static final String AUDIT_TRAIL_END = "Audit trail END";
	public static final String AUDIT_TRAIL_SAVED = "Audit trail saved";
	public static final String AUDIT_TRAIL_NOT_SAVED = "Audit trail not saved";
	public static final String AUDIT_TRAIL_REQUEST_NULL = "Audit Trail Request is null";
	/** Info Message **/

	private Constants() {
	}

}
