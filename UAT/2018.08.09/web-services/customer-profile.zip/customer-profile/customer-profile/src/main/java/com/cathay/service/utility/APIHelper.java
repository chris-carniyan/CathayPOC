package com.cathay.service.utility;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Calendar;
import java.util.Date;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


public class APIHelper {
	private APIHelper() {
	    throw new IllegalStateException("APIHelper class");
	}
	private static final Logger logger = LogManager.getLogger(APIHelper.class);
	/**Method that converts date to epoch format
	 * @param date
	 * @return long
	 */
	public static long dateToEpoch(Date date) {
		long epochDate= 0;
		if(date != null) {
			epochDate = date.getTime() / 1000;
		}else {
			//do something
		}
		return epochDate;
	}
	
	public static int getCurrentMonthInt() {
		Date date = new Date();
		LocalDate localDate = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		return localDate.getMonthValue();
	}
	
	
	public static boolean checkIfYearGreetedIsCurrentYear(String  dateGreeted) throws ParseException {
		boolean greeted = false;
		
		if(dateGreeted != null) {
			DateFormat f = new SimpleDateFormat("MM/dd/yyyy");
		    Date recordDate = f.parse(dateGreeted);
	
			Calendar cal = Calendar.getInstance();
			cal.setTime(recordDate);
			
			int yearGreeted = cal.get(Calendar.YEAR);
			Date current = new Date();
			cal.setTime(new Date(current.getTime()));
			int currentYear = cal.get(Calendar.YEAR);
			
			if(currentYear == yearGreeted) {
				greeted = true;
			}
		}

		return greeted;
		
	}
}
