package com.cathay.service.domain;

public class RequestBodyBirthdayGreeting {
	private Header header;
	private String customerId;
	private String trustKey;
	private String customerName;
	private String ccVipInd;
	private String bankVipInd;
	private String recordDate;
	private String recordTime;
	
	public Header getHeader() {
		return header;
	}
	public void setHeader(Header header) {
		this.header = header;
	}
	@Override
	public String toString() {
		return "RequestBodyBirthdayGreeting [header=" + header + ", customerId=" + customerId + ", trustKey=" + trustKey
				+ ", customerName=" + customerName + ", ccVipInd=" + ccVipInd + ", bankVipInd=" + bankVipInd
				+ ", recordDate=" + recordDate + ", recordTime=" + recordTime + "]";
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getTrustKey() {
		return trustKey;
	}
	public void setTrustKey(String trustKey) {
		this.trustKey = trustKey;
	}
	
	public String getCcVipInd() {
		return ccVipInd;
	}
	public void setCcVipInd(String ccVipInd) {
		this.ccVipInd = ccVipInd;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getBankVipInd() {
		return bankVipInd;
	}
	public void setBankVipInd(String bankVipInd) {
		this.bankVipInd = bankVipInd;
	}
	public String getRecordDate() {
		return recordDate;
	}
	public void setRecordDate(String recordDate) {
		this.recordDate = recordDate;
	}
	public String getRecordTime() {
		return recordTime;
	}
	public void setRecordTime(String recordTime) {
		this.recordTime = recordTime;
	}
}
