package com.cathay.service.domain;

public class AuthResult {
	private String customerId;

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	@Override
	public String toString() {
		return "AuthResult [customerId=" + customerId + "]";
	}
	
}
