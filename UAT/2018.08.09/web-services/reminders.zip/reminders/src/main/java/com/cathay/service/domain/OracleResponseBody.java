package com.cathay.service.domain;

public class OracleResponseBody {
    private Integer autoPayFailCnt;
    private Integer autoPayRmbFailCnt;
    private Integer autoPayUsaFailCnt;
    private Integer generalNextMonExpirePs;
    private Integer platinumNextMonExpirePs;
    private Integer clearedCostcoBonusBal;
    private Integer y1AsianExpireMiles;
    private Integer y1EvaExpireMiles;
    
	public Integer getY1EvaExpireMiles() {
		return y1EvaExpireMiles;
	}
	public void setY1EvaExpireMiles(Integer y1EvaExpireMiles) {
		this.y1EvaExpireMiles = y1EvaExpireMiles;
	}

	public Integer getAutoPayFailCnt() {
		return autoPayFailCnt;
	}
	public void setAutoPayFailCnt(Integer autoPayFailCnt) {
		this.autoPayFailCnt = autoPayFailCnt;
	}
	public Integer getAutoPayRmbFailCnt() {
		return autoPayRmbFailCnt;
	}
	public void setAutoPayRmbFailCnt(Integer autoPayRmbFailCnt) {
		this.autoPayRmbFailCnt = autoPayRmbFailCnt;
	}
	public Integer getAutoPayUsaFailCnt() {
		return autoPayUsaFailCnt;
	}
	public void setAutoPayUsaFailCnt(Integer autoPayUsaFailCnt) {
		this.autoPayUsaFailCnt = autoPayUsaFailCnt;
	}
	public Integer getGeneralNextMonExpirePs() {
		return generalNextMonExpirePs;
	}
	public void setGeneralNextMonExpirePs(Integer generalNextMonExpirePs) {
		this.generalNextMonExpirePs = generalNextMonExpirePs;
	}
	public Integer getPlatinumNextMonExpirePs() {
		return platinumNextMonExpirePs;
	}
	public void setPlatinumNextMonExpirePs(Integer platinumNextMonExpirePs) {
		this.platinumNextMonExpirePs = platinumNextMonExpirePs;
	}
	public Integer getClearedCostcoBonusBal() {
		return clearedCostcoBonusBal;
	}
	public void setClearedCostcoBonusBal(Integer clearedCostcoBonusBal) {
		this.clearedCostcoBonusBal = clearedCostcoBonusBal;
	}
	public Integer getY1AsianExpireMiles() {
		return y1AsianExpireMiles;
	}
	public void setY1AsianExpireMiles(Integer y1AsianExpireMiles) {
		this.y1AsianExpireMiles = y1AsianExpireMiles;
	}
	@Override
	public String toString() {
		return "OracleResponseBody [autoPayFailCnt=" + autoPayFailCnt + ", autoPayRmbFailCnt=" + autoPayRmbFailCnt
				+ ", autoPayUsaFailCnt=" + autoPayUsaFailCnt + ", generalNextMonExpirePs=" + generalNextMonExpirePs
				+ ", platinumNextMonExpirePs=" + platinumNextMonExpirePs + ", clearedCostcoBonusBal="
				+ clearedCostcoBonusBal + ", y1AsianExpireMiles=" + y1AsianExpireMiles + ", y1EvaExpireMiles="
				+ y1EvaExpireMiles + "]";
	}
	
}
