package com.cathay.service.domain;

public class RetrieveProductPitchResult {

	private String productPitch;
	private Boolean bkcEmail;
	private Boolean bkcComTel;
	private Boolean bkcHomeTel;
	private Boolean bkcPhone;
	private Boolean bkcPermanentAddress;
	private Boolean bkcResidentialAddress;
	private Boolean ccEmail;
	private Boolean ccComTel;
	private Boolean ccHomeTel;
	private Boolean ccPhone;
	private Boolean ccPermanentAddress;
	private Boolean ccResidentialAddress;

	public void setContactInfo(ContactInfoResult contactInfoResult) {
		bkcEmail = contactInfoResult.getBkcEmail();
		bkcComTel = contactInfoResult.getBkcComTel();
		bkcHomeTel = contactInfoResult.getBkcHomeTel();
		bkcPhone = contactInfoResult.getBkcPhone();
		bkcPermanentAddress = contactInfoResult.getBkcPermanentAddress();
		bkcResidentialAddress = contactInfoResult.getBkcResidentialAddress();
		ccEmail = contactInfoResult.getCcEmail();
		ccComTel = contactInfoResult.getCcComTel();
		ccHomeTel = contactInfoResult.getCcHomeTel();
		ccPhone = contactInfoResult.getCcPhone();
		ccPermanentAddress = contactInfoResult.getCcPermanentAddress();
		ccResidentialAddress = contactInfoResult.getCcResidentialAddress();
	}

	public String getProductPitch() {
		return productPitch;
	}

	public void setProductPitch(String productPitch) {
		this.productPitch = productPitch;
	}

	public Boolean getBkcEmail() {
		return bkcEmail;
	}

	public Boolean getBkcComTel() {
		return bkcComTel;
	}

	public Boolean getBkcHomeTel() {
		return bkcHomeTel;
	}

	public Boolean getBkcPhone() {
		return bkcPhone;
	}

	public Boolean getBkcPermanentAddress() {
		return bkcPermanentAddress;
	}

	public Boolean getBkcResidentialAddress() {
		return bkcResidentialAddress;
	}

	public Boolean getCcEmail() {
		return ccEmail;
	}

	public Boolean getCcComTel() {
		return ccComTel;
	}

	public Boolean getCcHomeTel() {
		return ccHomeTel;
	}

	public Boolean getCcPhone() {
		return ccPhone;
	}

	public Boolean getCcPermanentAddress() {
		return ccPermanentAddress;
	}

	public Boolean getCcResidentialAddress() {
		return ccResidentialAddress;
	}

	@Override
	public String toString() {
		return new StringBuilder("{productPitch=" + productPitch + "}").toString();
	}

}
