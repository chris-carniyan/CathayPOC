package com.cathay.service.domain;

public class RetrieveCustomerIdResponse extends BaseResponse {

	private RetrieveCustomerIdResult result;

	public RetrieveCustomerIdResponse() {
	}

	public RetrieveCustomerIdResponse(String code, String description) {
		super(code, description);
	}

	@Override
	public RetrieveCustomerIdResult getResult() {
		return result;
	}

	public void setResult(RetrieveCustomerIdResult result) {
		this.result = result;
	}

}
