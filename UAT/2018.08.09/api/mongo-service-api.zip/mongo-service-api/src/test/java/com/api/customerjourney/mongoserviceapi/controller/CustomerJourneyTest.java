package com.api.customerjourney.mongoserviceapi.controller;


import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.api.cub.mongoserviceapi.controller.CustomerJourneyController;
import com.api.cub.mongoserviceapi.domain.ResponseObject;
import com.api.cub.mongoserviceapi.domain.TransformedCustomerJourney;
import com.api.cub.mongoserviceapi.domain.TransformedEvent;
import com.api.cub.mongoserviceapi.domain.TransformedTimeSlot;
import com.fasterxml.jackson.databind.ObjectMapper;


@RunWith(SpringRunner.class)
@ContextConfiguration(classes=CustomerJourneyTest.class)
@WebMvcTest(value = CustomerJourneyController.class, secure = false)
public class CustomerJourneyTest {

	@Autowired
	private MockMvc mockMvc;
	
	@MockBean
	private CustomerJourneyController mockCustomerJourneyController;
	

	
	@Test
	public void testGetCustomerJourneyResponse() throws Exception{

		
	Mockito.when(mockCustomerJourneyController.getCustomerJourney(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(getMockCustomerJourneyData());
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/journey")
				.accept(MediaType.APPLICATION_JSON).param("ap_id", "crm_0000").param("teller_id", "sd").param("token", "token")
				.param("branch", "branch1").param("customer_id", "ASDASDAS");
		MvcResult mvcResult = mockMvc.perform(requestBuilder).andReturn();
		
		ObjectMapper mapper =  new ObjectMapper();
		String expectedResult = mapper.writeValueAsString(getMockCustomerJourneyData());
		String actualResult = mvcResult.getResponse().getContentAsString();
		JSONAssert.assertEquals(expectedResult, actualResult, false);
	}
	
	public ResponseObject<TransformedCustomerJourney> getMockCustomerJourneyData(){
		ResponseObject<TransformedCustomerJourney> customerJourneyResponse = new ResponseObject<>();
		customerJourneyResponse.setCode("0000");
		customerJourneyResponse.setMessage("Success");
		TransformedCustomerJourney mockCustomerJourney = new TransformedCustomerJourney();
		List<TransformedTimeSlot> timeslots = new ArrayList<>();
		mockCustomerJourney.setCurrentDate(1523664000);
		mockCustomerJourney.setUpdateDate(1524723762);
		
		customerJourneyResponse.setResult(mockCustomerJourney);
		
		TransformedTimeSlot slot1 = new TransformedTimeSlot();
		List<TransformedEvent> events = new ArrayList<>();
		slot1.setTimestamp(1522540800);
			
				TransformedEvent event1 = new TransformedEvent();
				event1.setChannel("ATM");
				events.add(event1);
				
				TransformedEvent event2 = new TransformedEvent();
				event2.setChannel("MyBank");
				events.add(event2);
		slot1.setEvents(events);
		timeslots.add(slot1);
		
		TransformedTimeSlot slot2 = new TransformedTimeSlot();
		List<TransformedEvent> events2 = new ArrayList<>();
		slot2.setTimestamp(1522627200);
			
				TransformedEvent event1a = new TransformedEvent();
				event1a.setChannel("MMB");
				events2.add(event1a);
		slot2.setEvents(events2);
		timeslots.add(slot2);
		mockCustomerJourney.setTimeSlots(timeslots);
		return customerJourneyResponse;
	}

}
