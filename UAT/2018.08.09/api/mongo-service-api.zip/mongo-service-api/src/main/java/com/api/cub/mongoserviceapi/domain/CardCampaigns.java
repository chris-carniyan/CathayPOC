package com.api.cub.mongoserviceapi.domain;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document(collection="cti_crm")
public class CardCampaigns {
	
	@Id
	private String id;
	
	@Field("campaign_name")
	private String campaignName;
	
	@Field("campaign_url")
	private String campaignUrl;
	
	@Field("active_code")
	private String activeCode;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCampaignName() {
		return campaignName;
	}

	public void setCampaignName(String campaignName) {
		this.campaignName = campaignName;
	}

	public String getCampaignUrl() {
		return campaignUrl;
	}

	public void setCampaignUrl(String campaignUrl) {
		this.campaignUrl = campaignUrl;
	}

	public String getActiveCode() {
		return activeCode;
	}

	public void setActiveCode(String activeCode) {
		this.activeCode = activeCode;
	}

	@Override
	public String toString() {
		return "CardCampaigns [id=" + id + ", campaignName=" + campaignName + ", campaignUrl=" + campaignUrl
				+ ", activeCode=" + activeCode + "]";
	}
}
