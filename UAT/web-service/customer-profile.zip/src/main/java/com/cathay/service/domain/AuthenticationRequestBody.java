package com.cathay.service.domain;

public class AuthenticationRequestBody {

	private Header header;
	private String uniqueNumber;
	private String trustKey;

	public AuthenticationRequestBody() {
	}

	public AuthenticationRequestBody(Header header, String uniqueNumber, String trustKey) {
		super();
		this.header = header;
		this.uniqueNumber = uniqueNumber;
		this.trustKey = trustKey;
	}

	public Header getHeader() {
		return header;
	}

	public void setHeader(Header header) {
		this.header = header;
	}

	public String getUniqueNumber() {
		return uniqueNumber;
	}

	public void setUniqueNumber(String uniqueNumber) {
		this.uniqueNumber = uniqueNumber;
	}

	public String getTrustKey() {
		return trustKey;
	}

	public void setTrustKey(String trustKey) {
		this.trustKey = trustKey;
	}

	@Override
	public String toString() {
		return new StringBuilder(
				"{header=" + header + ", uniqueNumber=" + uniqueNumber + ", trustKey=" + trustKey + "}").toString();
	}
}
