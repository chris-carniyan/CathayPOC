package com.cathay.service.domain;

public class OracleAPIRequestObject {

	private Header header;
	private String customerId;
	private String trustKey;

	public OracleAPIRequestObject() {
	}

	public OracleAPIRequestObject(Header header, String customerId, String trustKey) {
		this.header = header;
		this.customerId = customerId;
		this.trustKey = trustKey;
	}

	public Header getHeader() {
		return header;
	}

	public void setHeader(Header header) {
		this.header = header;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getTrustKey() {
		return trustKey;
	}

	public void setTrustKey(String trustKey) {
		this.trustKey = trustKey;
	}

	@Override
	public String toString() {
		return new StringBuilder("{header=" + header + ", customerId=" + customerId + ", trustKey=" + trustKey + "}")
				.toString();
	}
}
