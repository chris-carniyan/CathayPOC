package com.cathay.service.controller;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.cathay.service.CustomerProfileApplication;
import com.cathay.service.domain.CustomerOracleResponse;
import com.cathay.service.domain.ProfileMongoResponse;
import com.cathay.service.domain.ResponseBody;

@RunWith(SpringRunner.class)
@WebMvcTest(value = CustomerProfileApplication.class, secure = false)
public class CustomerProfileTestController {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private CustomerProfileController customerProfileController;

	@Value("${mongo.customer.profile.test}")
	private String tempMongoCustomerProfileUrl;
	@Value("${mongo.customer.complaints.test}")
	private String tempMongoCustomerProfileComplaintUrl;
	@Value("${oracle.customer.profile.test}")
	private String tempOracleCustomerProfileUrl;

	@Test
	public void getCustomerProfileTest() throws Exception {
		Mockito.when(customerProfileController.getCustomerProfile(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyObject()))
				.thenReturn(getCustomerProfile());

		RequestBuilder requestBuilder = MockMvcRequestBuilders.get(tempMongoCustomerProfileUrl)
				.accept(MediaType.APPLICATION_JSON).param("ap_id", "crm_0000").param("teller_id", "sd")
				.param("token", "token").param("branch", "branch1").param("customer_id", "ASDASDAS");

		MvcResult mvcResult = mockMvc.perform(requestBuilder).andReturn();

		String expectedResult = "{\r\n" + "  \"code\": \"0\",\r\n" + "  \"message\": \"Success\",\r\n"
				+ "  \"description\": \"Success\",\r\n" + "  \"source\": \"string\",\r\n" + "  \"result\": {\r\n"
				+ "    \"age\": 19,\r\n" + "    \"birthMonth\": 3,\r\n" + "    \"bankVip\": null,\r\n"
				+ "    \"complaintCount\": 2\r\n" + "  }\r\n" + "}";
		String actualResult = mvcResult.getResponse().getContentAsString();
		JSONAssert.assertEquals(expectedResult, actualResult, false);
	}

	// @Test
	// public void queryCustomerProfileTest() throws Exception {
	// Mockito.when(customerProfileController.queryCustomerProfile(Mockito.anyObject(),
	// Mockito.anyObject())).thenReturn(queryCustomerProfile());
	//
	// RequestBuilder requestBuilder =
	// MockMvcRequestBuilders.post(tempOracleCustomerProfileUrl).accept(MediaType.APPLICATION_JSON)
	// .contentType(MediaType.APPLICATION_JSON).content(content);
	// MvcResult mvcResult = mockMvc.perform(requestBuilder).andReturn();
	// String exptectedResult = "{\r\n" +
	// " \"code\": \"string\",\r\n" +
	// " \"message\": \"string\",\r\n" +
	// " \"description\": \"Success\",\r\n" +
	// " \"source\": \"string\",\r\n" +
	// " \"result\": {\r\n" +
	// " \"customerId\": \"A123456789\",\r\n" +
	// " \"customerName\": \"First Middle Last\",\r\n" +
	// " \"ccVip\": \"y\",\r\n" +
	// " \"specialIdentity\": \"IS_AML_GOV_IND\"\r\n" +
	// " }\r\n" +
	// "}";
	// String actualResult = mvcResult.getResponse().getContentAsString();
	// JSONAssert.assertEquals(exptectedResult, actualResult, false);
	// }

	public void getCustomerProfileComplaintsTest() throws Exception {
		Mockito.when(customerProfileController.getCustomerProfile(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyObject()))
				.thenReturn(getCustomerProfile());

		RequestBuilder requestBuilder = MockMvcRequestBuilders.get(tempMongoCustomerProfileComplaintUrl)
				.accept(MediaType.APPLICATION_JSON).param("ap_id", "crm_0000").param("teller_id", "sd")
				.param("token", "token").param("branch", "branch1").param("customer_id", "ASDASDAS");

		MvcResult mvcResult = mockMvc.perform(requestBuilder).andReturn();

		String expectedResult = "{\r\n" + "  \"code\": \"0\",\r\n" + "  \"message\": \"Success\",\r\n"
				+ "  \"description\": \"Success\",\r\n" + "  \"source\": \"string\",\r\n" + "  \"result\": {\r\n"
				+ "    \"age\": 19,\r\n" + "    \"birthMonth\": 3,\r\n" + "    \"bankVip\": null,\r\n"
				+ "    \"complaintCount\": 2\r\n" + "  }\r\n" + "}";
		String actualResult = mvcResult.getResponse().getContentAsString();
		JSONAssert.assertEquals(expectedResult, actualResult, false);
	}

	public ResponseBody<CustomerOracleResponse> queryCustomerProfile() {
		ResponseBody<CustomerOracleResponse> response = new ResponseBody<>();
		CustomerOracleResponse profile = new CustomerOracleResponse();
		profile.setCcVip("y");
		profile.setCustomerId("A123456789");
		profile.setCustomerName("First Middle Last");
		profile.setSpecialIdentity("IS_AML_GOV_IND");
		response.setCode("string");
		response.setMessage("string");
		response.setDescription("Success");
		response.setSource("string");
		response.setResult(profile);
		return response;
	}

	public ResponseBody<ProfileMongoResponse> getCustomerProfile() {
		ResponseBody<ProfileMongoResponse> response = new ResponseBody<>();
		ProfileMongoResponse profile = new ProfileMongoResponse();
		profile.setAge(19);
		profile.setBirthMonth(3);
		profile.setComplaintCount(2);
		response.setCode("0");
		response.setMessage("Success");
		response.setDescription("Success");
		response.setSource("string");
		response.setResult(profile);
		return response;
	}
}
