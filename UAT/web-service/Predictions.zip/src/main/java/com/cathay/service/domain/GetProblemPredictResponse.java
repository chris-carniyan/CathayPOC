package com.cathay.service.domain;

public class GetProblemPredictResponse extends BaseResponse {

	private String[] result;

	public GetProblemPredictResponse() {
	}

	public GetProblemPredictResponse(RetrieveCustomerIdResponse retrieveCustomerIdResponse) {
		super(retrieveCustomerIdResponse.getCode(), retrieveCustomerIdResponse.getMessage(),
				retrieveCustomerIdResponse.getDescription(), retrieveCustomerIdResponse.getSource());
	}

	public GetProblemPredictResponse(String code, String description) {
		super(code, description);
	}

	@Override
	public String[] getResult() {
		return result;
	}

	public void setResult(String[] result) {
		this.result = result;
	}

}
