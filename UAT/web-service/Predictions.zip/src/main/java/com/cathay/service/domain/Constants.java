package com.cathay.service.domain;

public class Constants {

	// Logging scope format
	public static final String LOGGER_START = "[START @{} ({})]";
	public static final String LOGGER_END = "[END @{} ({})]";
	public static final String LOGGER_ERROR = "[ERROR @{} ({})]";

	// Response Code
	public static final String SUCCESS_CODE = "0000";
	public static final String ERROR_CODE = "1111";

	// Response Message
	public static final String SUCCESS_MESSAGE = "Success";
	public static final String ERROR_MESSAGE = "Error";
	public static final String FAILURE_MESSAGE = "Failure";

	// Origin or Source
	public static final String SOURCE = "Predictions Service";

	/** Error Description **/
	public static final String GENERIC_ERROR = "An error occured, please see log details";
	public static final String BAD_REQUEST = "Invalid argument / request parameters";
	public static final String MISSING_REQUEST_PARAMETERS = "Missing request parameters";
	public static final String HTTP_CLIENT_ERROR = "Error encountered while connecting to ";

	// Customer profile and Financial products
	public static final String CUSTOMER_NOT_FOUND = "Customer not found";
	/** Error Description **/

	/** Info Message **/
	// Get Problem Predict
	public static final String GET_PROBLEM_PREDICT_REQUEST = "Get problem predict request: {}";
	public static final String GET_PROBLEM_PREDICT_RESPONSE = "Get problem predict response: {}";
	public static final String URL_SOURCE = "Data Source URL: {}";
	
	// Retrieve Customer Id
	public static final String RETRIEVE_CUSTOMER_ID_REQUEST = "Retrieve customer id request: {}";
	public static final String RETRIEVE_CUSTOMER_ID_RESPONSE = "Retrieve customer id response: {}";

	
	// Audit Trail
	public static final String SAVING_AUDIT_TRAIL = "Saving audit trail";
	public static final String RESTCLIENT_EXCEPTION_OCCURED = "RestClientException occured in saving audit trail";
	public static final String AUDIT_TRAIL_NOT_SAVED = "Audit trail not saved";
	
	// Exception Message
	public static final String EXCEPTION_BAD_REQUEST = "400 Bad Request";
	public static final String EXCEPTION_NOT_FOUND = "404 Not Found";
	public static final String EXCEPTION_INTERNAL_SERVER = "500 Internal Server Error";
	/** Info Message **/

	private Constants() {
	}

}
