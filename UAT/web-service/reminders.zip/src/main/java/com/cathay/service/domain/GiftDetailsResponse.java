package com.cathay.service.domain;

public class GiftDetailsResponse extends BaseResponse{
	
	private GiftDetailsResponseBody result;

	public GiftDetailsResponseBody getResult() {
		return result;
	}

	public void setResult(GiftDetailsResponseBody result) {
		this.result = result;
	}

	@Override
	public String toString() {
		return "GiftDetailsResponse [result=" + result + "]";
	}
}
