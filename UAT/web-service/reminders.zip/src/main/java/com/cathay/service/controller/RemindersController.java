package com.cathay.service.controller;

import java.util.Collections;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import com.cathay.service.domain.BaseResponse;
import com.cathay.service.domain.CampaignCardCountResponse;
import com.cathay.service.domain.CampaignCountRequest;
import com.cathay.service.domain.GiftDetailsResponse;
import com.cathay.service.domain.GiftODSRequestBody;
import com.cathay.service.domain.Header;
import com.cathay.service.domain.MongoResponse;
import com.cathay.service.domain.ODSRequestBody;
import com.cathay.service.domain.ODSResponse;
import com.cathay.service.domain.OracleResponse;
import com.cathay.service.domain.ParameterValidationResponse;
import com.cathay.service.domain.Reminder2ndLayerRequestBody;
import com.cathay.service.domain.ReminderActivitiesResponse;
import com.cathay.service.domain.ReminderRequestBody;
import com.cathay.service.domain.RetrieveCustomerIdRequest;
import com.cathay.service.domain.RetrieveCustomerIdResponse;
import com.cathay.service.domain.TransactionSequenceResponse;
import com.cathay.service.exception.CustomerIdRetrievalException;
import com.cathay.service.utility.ParamsValidator;
import com.cathay.service.utility.TransactionSequenceFormatUtility;

@CrossOrigin
@RestController
public class RemindersController {
	private static final Logger logger = LogManager.getLogger(RemindersController.class);
	private static final String LOGGER_START = "[START @{} ({})]";
	private static final String LOGGER_END = "[END @{} ({})]";

	private static final String AP_ID = "ap_id";
	private static final String TELLER_ID = "teller_id";
	private static final String CUSTOMER_ID = "customer_id";
	private static final String BRANCH = "branch";
	private static final String TOKEN = "token";
	private static final String CATEG_ACTIV = "ACTIVITIES";
	private static final String CATEG_GIFT = "GIFT-DETAILS";
	private static final String SUCCESS_CODE = "0000";
	private static final String ERROR_CODE = "1111";
	private static final String ERROR_MESSAGE = "Error";
	private static final String ERROR_OCCURED = "Error Occurred";
	private static final String SERVICE_UNAVAILABLE = "Service Unavailable.";
	private static final String BAD_PARAMETERS = "Bad Parameters";
	private static final String MISSING_PARAMS_CODE = "0003";
	private static final String INVALID_PARAMS = "Invalid input parameter.";
	private static final String INV_CATEGORY = "Invalid query category input.";
	private static final String RESPONSE_IS = "response is : ";

	private RestTemplate restTemplate;

	@Autowired
	public RemindersController(RestTemplate restTemplate) {
		this.restTemplate = restTemplate;
	}

	@Value("${ms-source-name}")
	protected String sourceNameMS;

	@Value("${get-customerid-api}")
	protected String getCustomerIdApiUrl;

	@Value("${get-reminders-mongo-url}")
	protected String getRemindersMongoUrl;

	@Value("${get-reminders-oracle-url}")
	protected String getRemindersOracleUrl;

	@Value("${get-reminders-ods-url}")
	protected String getRemindersODSUrl;

	@Value("${get-reminders-activities-url}")
	protected String getReminderActivitiesUrl;

	@Value("${get-reminders-gift-details-url}")
	protected String getRemindersGiftDetailsUrl;

	@Value("${get-campaign-card-count-url}")
	protected String getCampaignCardCount;

	@Value("${get-transaction-sequence-url}")
	protected String getTransactionSequence;

	@PostMapping("/getRemindersAnyActivities")
	public MongoResponse getReminderPoints(@RequestBody ReminderRequestBody requestBody) {
		logger.info(LOGGER_START, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());

		MongoResponse mongoResponse = new MongoResponse();

		try {
			ParameterValidationResponse validResponse = ParamsValidator.validateRemindersParams(requestBody.getHeader(),
					requestBody.getTrustKey(), requestBody.getUniqueNumber());
			if (validResponse.isValidParams()) {
				RetrieveCustomerIdRequest retrieveCustomerIdRequest = customerIdRequestBodyBuilder(
						requestBody.getHeader(), requestBody.getTrustKey(), requestBody.getUniqueNumber());
				String customerId = getCustomerId(retrieveCustomerIdRequest);

				logger.info("Started retrieval of reminders data in MongoDB");
				UriComponents builder = UriComponentsBuilder.fromHttpUrl(getRemindersMongoUrl)
						.queryParam(AP_ID, requestBody.getHeader().getApId())
						.queryParam(TELLER_ID, requestBody.getHeader().getEmployeeId())
						.queryParam(CUSTOMER_ID, customerId).queryParam(BRANCH, requestBody.getHeader().getBranchId())
						.queryParam(TOKEN, requestBody.getTrustKey()).build();
				logger.info("RemindersMongoUrl : " + builder.toUriString());
				mongoResponse = restTemplate.getForObject(builder.toUriString(), MongoResponse.class);
				logger.info("Reminders Mongo response : " + mongoResponse.toString());

			} else {
				mongoResponse.setCode(MISSING_PARAMS_CODE);
				mongoResponse.setMessage(INVALID_PARAMS);
				mongoResponse.setDescription(validResponse.getErrorMessage());
				mongoResponse.setSource(sourceNameMS);
			}
		} catch (CustomerIdRetrievalException | RestClientException | NullPointerException e) {
			logger.error(ERROR_OCCURED, e);
			mongoResponse.setCode(ERROR_CODE);
			mongoResponse.setMessage(ERROR_MESSAGE);
			mongoResponse.setSource(sourceNameMS);
			mongoResponse.setDescription(e.getLocalizedMessage());
		}
		logger.info("Finished retrieval of reminders data in MongoDB");
		logger.info(LOGGER_END, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		return mongoResponse;
	}

	@PostMapping("/getRemindersPoints")
	public OracleResponse getRemindersOracle(@RequestBody ReminderRequestBody requestBody) {
		logger.info(LOGGER_START, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		logger.info("Started retrieval of reminders data in Oracle");
		OracleResponse response = new OracleResponse();
		try {
			ParameterValidationResponse validResponse = ParamsValidator.validateRemindersParams(requestBody.getHeader(),
					requestBody.getTrustKey(), requestBody.getUniqueNumber());
			if (validResponse.isValidParams()) {
				RetrieveCustomerIdRequest retrieveCustomerIdRequest = customerIdRequestBodyBuilder(
						requestBody.getHeader(), requestBody.getTrustKey(), requestBody.getUniqueNumber());
				String customerId = getCustomerId(retrieveCustomerIdRequest);
				ODSRequestBody body = new ODSRequestBody();
				body.setHeader(requestBody.getHeader());
				body.setCustomerId(customerId);
				body.setTrustKey(requestBody.getTrustKey());

				HttpHeaders httpHeaders = new HttpHeaders();
				httpHeaders.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
				httpHeaders.setContentType(MediaType.APPLICATION_JSON);
				HttpEntity<ODSRequestBody> entity = new HttpEntity<>(body, httpHeaders);
				response = restTemplate.postForObject(getRemindersOracleUrl, entity, OracleResponse.class);
			} else {
				response.setCode(MISSING_PARAMS_CODE);
				response.setMessage(INVALID_PARAMS);
				response.setDescription(validResponse.getErrorMessage());
				response.setSource(sourceNameMS);
			}

		} catch (RestClientException | CustomerIdRetrievalException e) {
			logger.error(ERROR_OCCURED, e);
			response.setCode(ERROR_CODE);
			response.setMessage(ERROR_MESSAGE);
			response.setSource(sourceNameMS);
			response.setDescription(e.getLocalizedMessage());
		}

		logger.info("Finished retrieval of reminders data in Oracle");
		logger.info(LOGGER_END, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		return response;

	}

	@PostMapping("/getRemindersFlag")
	public ODSResponse getRemindersODS(@RequestBody ReminderRequestBody requestBody) {
		logger.info(LOGGER_START, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		logger.info("Started retrieval of reminders data in ODS");
		ODSResponse response = new ODSResponse();
		try {
			ParameterValidationResponse validResponse = ParamsValidator.validateRemindersParams(requestBody.getHeader(),
					requestBody.getTrustKey(), requestBody.getUniqueNumber());
			if (validResponse.isValidParams()) {
				RetrieveCustomerIdRequest retrieveCustomerIdRequest = customerIdRequestBodyBuilder(
						requestBody.getHeader(), requestBody.getTrustKey(), requestBody.getUniqueNumber());
				String customerId = getCustomerId(retrieveCustomerIdRequest);
				GiftODSRequestBody body = new GiftODSRequestBody();
				body.setHeader(requestBody.getHeader());
				body.setCustomerId(customerId);
				body.setTrustKey(requestBody.getTrustKey());
				body.setTransactionSequence(
						getCurrentTransactionSequence(requestBody.getHeader(), customerId, requestBody.getTrustKey()));

				HttpHeaders httpHeaders = new HttpHeaders();
				httpHeaders.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
				httpHeaders.setContentType(MediaType.APPLICATION_JSON);
				HttpEntity<GiftODSRequestBody> entity = new HttpEntity<>(body, httpHeaders);
				response = restTemplate.postForObject(getRemindersODSUrl, entity, ODSResponse.class);
				logger.info("Reminders ODS response : " + response.toString());
			} else {
				response.setCode(MISSING_PARAMS_CODE);
				response.setMessage(INVALID_PARAMS);
				response.setDescription(validResponse.getErrorMessage());
				response.setSource(sourceNameMS);
			}

		} catch (RestClientException | CustomerIdRetrievalException | IllegalArgumentException e) {
			logger.error(ERROR_OCCURED, e);
			response.setCode(ERROR_CODE);
			response.setMessage(SERVICE_UNAVAILABLE);
			response.setDescription(e.getLocalizedMessage());
		}

		logger.info("Finished retrieval of reminders data in ODS");
		logger.info(LOGGER_END, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		return response;

	}

	@PostMapping("/getReminderActivitiesOrGiftDetails")
	public BaseResponse getRemindersSecondLayer(@RequestBody Reminder2ndLayerRequestBody requestBody) {
		logger.info(LOGGER_START, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		BaseResponse baseResponse = new BaseResponse();

		try {
			ParameterValidationResponse validResponse = ParamsValidator.validateReminders2ndLayerParams(
					requestBody.getHeader(), requestBody.getTrustKey(), requestBody.getUniqueNumber(),
					requestBody.getCategory());
			if (validResponse.isValidParams()) {

				RetrieveCustomerIdRequest retrieveCustomerIdRequest = customerIdRequestBodyBuilder(
						requestBody.getHeader(), requestBody.getTrustKey(), requestBody.getUniqueNumber());
				String customerId = getCustomerId(retrieveCustomerIdRequest);

				if (requestBody.getCategory().equals(CATEG_GIFT)) {
					GiftDetailsResponse giftResponse = getGiftDetails(requestBody.getHeader(), customerId,
							requestBody.getTrustKey());
					logger.info(LOGGER_END, this.getClass().getSimpleName(),
							Thread.currentThread().getStackTrace()[1].getMethodName());
					return giftResponse;
				} else if (requestBody.getCategory().equals(CATEG_ACTIV)) {
					ReminderActivitiesResponse activitiesResponse = getReminderActivities(
							requestBody.getHeader().getApId(), requestBody.getHeader().getEmployeeId(), customerId,
							requestBody.getHeader().getBranchId(), requestBody.getTrustKey());
					logger.info(LOGGER_END, this.getClass().getSimpleName(),
							Thread.currentThread().getStackTrace()[1].getMethodName());
					return activitiesResponse;
				} else {
					baseResponse.setCode(ERROR_CODE);
					baseResponse.setMessage(INV_CATEGORY);
					baseResponse.setDescription(INV_CATEGORY);
					baseResponse.setSource(sourceNameMS);
					logger.info(LOGGER_END, this.getClass().getSimpleName(),
							Thread.currentThread().getStackTrace()[1].getMethodName());
					return baseResponse;
				}

			} else {
				baseResponse.setCode(ERROR_CODE);
				baseResponse.setMessage(BAD_PARAMETERS);
				baseResponse.setDescription(validResponse.getErrorMessage());
				baseResponse.setSource(sourceNameMS);
				return baseResponse;
			}
		} catch (CustomerIdRetrievalException e) {
			logger.error(ERROR_OCCURED, e);
			baseResponse.setCode(ERROR_CODE);
			baseResponse.setMessage("Failed to retrieve customerId in authentication service.");
			baseResponse.setDescription(SERVICE_UNAVAILABLE);
			baseResponse.setSource("Authentication Web Service");
			return baseResponse;
		}
	}

	private ReminderActivitiesResponse getReminderActivities(String apId, String tellerId, String customerId,
			String branch, String token) {
		logger.info("Started retrieval of reminders activities data in MongoDB");
		ReminderActivitiesResponse response = new ReminderActivitiesResponse();
		try {
			UriComponents builder = UriComponentsBuilder.fromHttpUrl(getReminderActivitiesUrl).queryParam(AP_ID, apId)
					.queryParam(TELLER_ID, tellerId).queryParam(CUSTOMER_ID, customerId).queryParam(BRANCH, branch)
					.queryParam(TOKEN, token).build();
			logger.info("url is" + builder.toUriString());
			response = restTemplate.getForObject(builder.toUriString(), ReminderActivitiesResponse.class);
			if (response.getCode().equals(SUCCESS_CODE)) {
				response.setSource(sourceNameMS);
			} else {
				response.setSource("Mongo API");
			}
		} catch (RestClientException e) {
			logger.error(ERROR_OCCURED, e);
			response.setCode(ERROR_CODE);
			response.setMessage(SERVICE_UNAVAILABLE);
			response.setDescription(e.getLocalizedMessage());
		}
		logger.info("Finished retrieval of reminders activities data in MongoDB");
		return response;
	}

	private CampaignCardCountResponse getCampaignCardCount(Header header, String campaignCode, String trustKey) {
		logger.info("Started retrieval of reminders gift details data in Oracle");
		logger.info("****** campaignCode" + campaignCode);
		CampaignCardCountResponse response = new CampaignCardCountResponse();
		try {
			CampaignCountRequest body = new CampaignCountRequest();
			body.setHeader(header);
			body.setCampaignCode(campaignCode);
			body.setTrustKey(trustKey);

			HttpHeaders httpHeaders = new HttpHeaders();
			httpHeaders.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
			httpHeaders.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<CampaignCountRequest> entity = new HttpEntity<>(body, httpHeaders);
			response = restTemplate.postForObject(getCampaignCardCount, entity, CampaignCardCountResponse.class);
			logger.info(RESPONSE_IS + response.toString());
		} catch (RestClientException e) {
			logger.error(ERROR_OCCURED, e);
			response.setCode(ERROR_CODE);
			response.setMessage(SERVICE_UNAVAILABLE + " @getCampaignCardCount()");
			response.setDescription(e.getLocalizedMessage());
		}
		logger.info("Finished retrieval of reminders gift details data in Oracle");
		return response;
	}

	private GiftDetailsResponse getGiftDetails(Header header, String customerId, String trustKey) {
		logger.info("Started retrieval of reminders gift details data in ODS");
		GiftDetailsResponse response = new GiftDetailsResponse();
		CampaignCardCountResponse campaignCardCountResponse = new CampaignCardCountResponse();
		try {
			GiftODSRequestBody body = new GiftODSRequestBody();
			body.setHeader(header);
			body.setCustomerId(customerId);
			body.setTrustKey(trustKey);
			body.setTransactionSequence(getCurrentTransactionSequence(header, customerId, trustKey));

			HttpHeaders httpHeaders = new HttpHeaders();
			httpHeaders.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
			httpHeaders.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<GiftODSRequestBody> entity = new HttpEntity<>(body, httpHeaders);
			response = restTemplate.postForObject(getRemindersGiftDetailsUrl, entity, GiftDetailsResponse.class);
			logger.info(RESPONSE_IS + response.toString());
			if (response.getCode().equals(SUCCESS_CODE)) {
				response.setSource(sourceNameMS);
				campaignCardCountResponse = getCampaignCardCount(header, response.getResult().getCampaignCode(),
						trustKey);
				if (campaignCardCountResponse.getCode().equals(SUCCESS_CODE)) {
					int diff = campaignCardCountResponse.getResult().getfCnt() - response.getResult().getUsedCardCnt();
					response.getResult().setDiffCardCnt(diff);
				} else {
					logger.error(ERROR_OCCURED);
					response.setCode(campaignCardCountResponse.getCode());
					response.setMessage(campaignCardCountResponse.getMessage());
					response.setDescription(campaignCardCountResponse.getDescription());
					response.setSource("Oracle API");
					response.setResult(null);
				}
			} else {
				response.setSource("Mongo API");
			}
		} catch (RestClientException e) {
			logger.error(ERROR_OCCURED, e);
			response.setCode(ERROR_CODE);
			response.setMessage(SERVICE_UNAVAILABLE + " @getGiftDetails()");
			response.setDescription(e.getLocalizedMessage());
		}
		logger.info("Finished retrieval of reminders gift details data in ODS");
		return response;
	}

	private String getCustomerId(RetrieveCustomerIdRequest request) throws CustomerIdRetrievalException {

		logger.info("Started retrieval of customer id using unique number: {}", request.getUniqueNumber());

		RetrieveCustomerIdResponse response = new RetrieveCustomerIdResponse();
		HttpHeaders httpHeaders = null;
		HttpEntity<RetrieveCustomerIdRequest> entity = null;

		String customerId = null;

		try {

			httpHeaders = new HttpHeaders();
			httpHeaders.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
			httpHeaders.setContentType(MediaType.APPLICATION_JSON);
			entity = new HttpEntity<>(request, httpHeaders);
			response = restTemplate.postForObject(getCustomerIdApiUrl, entity, RetrieveCustomerIdResponse.class);

			customerId = response.getResult().getCustomerId();
			logger.info(customerId);

		} catch (Exception e) {

			logger.error(ERROR_OCCURED, e);
			throw new CustomerIdRetrievalException();

		}

		logger.info("Finished retrieval of customer id. Result: {}", customerId);

		return customerId;
	}

	private RetrieveCustomerIdRequest customerIdRequestBodyBuilder(Header header, String trustKey,
			String uniqueNumber) {
		RetrieveCustomerIdRequest request = new RetrieveCustomerIdRequest();
		request.setTrustKey(trustKey);
		request.setUniqueNumber(uniqueNumber);
		request.setHeader(header);
		return request;
	}

	private String getCurrentTransactionSequence(Header header, String customerId, String trustKey) {

		logger.info("Started retrieval of transaction sequence in Oracle");
		TransactionSequenceResponse response = new TransactionSequenceResponse();

		String transactionSequence = "C00000000000";
		try {
			ODSRequestBody body = new ODSRequestBody();
			body.setHeader(header);
			body.setCustomerId(customerId);
			body.setTrustKey(trustKey);

			HttpHeaders httpHeaders = new HttpHeaders();
			httpHeaders.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
			httpHeaders.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<ODSRequestBody> entity = new HttpEntity<>(body, httpHeaders);
			response = restTemplate.postForObject(getTransactionSequence, entity, TransactionSequenceResponse.class);
			logger.info(RESPONSE_IS + response.toString());

			if (response.getResult() != null) {
				transactionSequence = "C"
						+ TransactionSequenceFormatUtility.format(response.getResult().getCurrentSequence(), 11);
				logger.info("generated  transaction sequence : {} ", transactionSequence);
			} else {
				logger.error("Error during retrieval of current transaction sequence...");
				throw new IllegalArgumentException("Error during retrieval of current transaction sequence...");
			}

		} catch (RestClientException e) {
			logger.error(ERROR_OCCURED, e);
		}

		logger.info("Finished retrieval of transaction sequence data in Oracle");

		return transactionSequence;
	}
}
