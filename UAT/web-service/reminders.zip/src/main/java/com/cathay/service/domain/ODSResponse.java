package com.cathay.service.domain;

public class ODSResponse extends BaseResponse{
	private ODSResponseBody result;

	public ODSResponseBody getResult() {
		return result;
	}

	public void setResult(ODSResponseBody result) {
		this.result = result;
	}

	@Override
	public String toString() {
		return "ODSResponse [result=" + result + "]";
	}
}
