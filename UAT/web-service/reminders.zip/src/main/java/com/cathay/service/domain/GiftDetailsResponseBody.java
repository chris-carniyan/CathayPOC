package com.cathay.service.domain;

public class GiftDetailsResponseBody {
	private String customerId;
	private String campaignCode;
	private String campaignEndDate;
	private String cardNo;
	private int usedCardCnt;
	private int diffCardCnt;
	
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getCampaignCode() {
		return campaignCode;
	}
	public void setCampaignCode(String campaignCode) {
		this.campaignCode = campaignCode;
	}
	public String getCampaignEndDate() {
		return campaignEndDate;
	}
	public void setCampaignEndDate(String campaignEndDate) {
		this.campaignEndDate = campaignEndDate;
	}
	public String getCardNo() {
		return cardNo;
	}
	public void setCardNo(String cardNo) {
		this.cardNo = cardNo;
	}
	public int getUsedCardCnt() {
		return usedCardCnt;
	}
	public void setUsedCardCnt(int usedCardCnt) {
		this.usedCardCnt = usedCardCnt;
	}
	public int getDiffCardCnt() {
		return diffCardCnt;
	}
	public void setDiffCardCnt(int diffCardCnt) {
		this.diffCardCnt = diffCardCnt;
	}
	@Override
	public String toString() {
		return "GiftDetailsResponseBody [customerId=" + customerId + ", campaignCode=" + campaignCode
				+ ", campaignEndDate=" + campaignEndDate + ", cardNo=" + cardNo + ", usedCardCnt=" + usedCardCnt
				+ ", diffCardCnt=" + diffCardCnt + "]";
	}
	
}
