package com.cathay.service.domain;

public class ReminderRequestBody {
	private Header header;
	private String trustKey;
	private String uniqueNumber;
	public Header getHeader() {
		return header;
	}
	public void setHeader(Header header) {
		this.header = header;
	}
	public String getTrustKey() {
		return trustKey;
	}
	public void setTrustKey(String trustKey) {
		this.trustKey = trustKey;
	}
	public String getUniqueNumber() {
		return uniqueNumber;
	}
	public void setUniqueNumber(String uniqueNumber) {
		this.uniqueNumber = uniqueNumber;
	}
	@Override
	public String toString() {
		return "ReminderRequestBody [header=" + header + ", trustKey=" + trustKey + ", uniqueNumber=" + uniqueNumber
				+ "]";
	}
	
}
