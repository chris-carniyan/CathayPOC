package com.cathay.service.domain;

public class CampaignCardCountBody {
	private int fCnt;

	public int getfCnt() {
		return fCnt;
	}

	public void setfCnt(int fCnt) {
		this.fCnt = fCnt;
	}

	@Override
	public String toString() {
		return "CampaignCardCountBody [fCnt=" + fCnt + "]";
	}
	
}
