package com.cathay.service.domain;

import javax.validation.Valid;

import org.hibernate.validator.constraints.NotBlank;

public class RetrieveCustomerIdRequest {

	@Valid
	private Header header;
	@NotBlank
	private String uniqueNumber;
	@NotBlank
	private String trustKey;

	public RetrieveCustomerIdRequest() {
		super();
	}

	public Header getHeader() {
		return header;
	}

	public void setHeader(Header header) {
		this.header = header;
	}

	public String getUniqueNumber() {
		return uniqueNumber;
	}

	public void setUniqueNumber(String uniqueNumber) {
		this.uniqueNumber = uniqueNumber;
	}

	public String getTrustKey() {
		return trustKey;
	}

	public void setTrustKey(String trustKey) {
		this.trustKey = trustKey;
	}

	@Override
	public String toString() {
		return new StringBuilder(
				"{header=" + header + ", uniqueNumber=" + uniqueNumber + ", trustKey=" + trustKey + "}").toString();
	}

}
