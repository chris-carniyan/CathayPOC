package com.cathay.service.domain;

import org.hibernate.validator.constraints.NotBlank;

public class RetrieveCustomerIdResult {

	@NotBlank
	private String customerId;

	public RetrieveCustomerIdResult() {
		super();
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	@Override
	public String toString() {
		return new StringBuilder("{customerId=" + customerId + "}").toString();
	}

}
