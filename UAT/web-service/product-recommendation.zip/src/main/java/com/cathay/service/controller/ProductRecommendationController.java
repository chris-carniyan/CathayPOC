package com.cathay.service.controller;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

import com.cathay.service.domain.Constants;
import com.cathay.service.domain.ContactInfoResponse;
import com.cathay.service.domain.GetCPINResponse;
import com.cathay.service.domain.GetLowMarketingRequest;
import com.cathay.service.domain.GetLowMarketingResponse;
import com.cathay.service.domain.GetRecommendationAndCPINResponse;
import com.cathay.service.domain.GetRecommendationApiRequest;
import com.cathay.service.domain.GetRecommendationRequest;
import com.cathay.service.domain.RecommendationAndCTIResult;
import com.cathay.service.domain.RetrieveCustomerIdRequest;
import com.cathay.service.domain.RetrieveCustomerIdResponse;
import com.cathay.service.domain.RetrieveProductPitchRequest;
import com.cathay.service.domain.RetrieveProductPitchResponse;
import com.cathay.service.domain.StoreRecommendationApiRequest;
import com.cathay.service.domain.StoreRecommendationRequest;
import com.cathay.service.domain.StoreRecommendationResponse;

@CrossOrigin
@RestController
public class ProductRecommendationController {

	private static final Logger LOGGER = LogManager.getLogger(ProductRecommendationController.class);

	private RestTemplate restTemplate;

	@Value("${store-recomendation-api}")
	protected String storeRecommendationApiUrl;

	@Value("${get-recomendation-api}")
	protected String getRecommendationApiUrl;

	@Value("${get-customerid-api}")
	protected String getCustomerIdApiUrl;

	@Value("${get-cpin-api}")
	protected String getCPINUrl;

	@Value("${retrieve-product-pitch-api}")
	protected String retrieveProductPitchUrl;

	@Value("${contact-info-api}")
	protected String contactInfoUrl;

	@Value("${get-low-marketing-api}")
	protected String getLowMarketingUrl;

	@Autowired
	public ProductRecommendationController(RestTemplate restTemplate) {
		this.restTemplate = restTemplate;
	}

	@PostMapping(path = "${store-recommendation}")
	public StoreRecommendationResponse storeRecommendation(@Valid @RequestBody StoreRecommendationRequest request) {
		LOGGER.info(Constants.LOGGER_START, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		LOGGER.info(Constants.STORE_RECOMMENDATION_REQUEST, request);
		StoreRecommendationResponse response = null;

		try {
			RetrieveCustomerIdRequest retrieveCustomerIdRequest = new RetrieveCustomerIdRequest(request.getHeader(),
					request.getTrustKey(), request.getUniqueNumber());
			RetrieveCustomerIdResponse retrieveCustomerIdResponse = getCustomerId(retrieveCustomerIdRequest);

			if (retrieveCustomerIdResponse.getCode().equals(Constants.SUCCESS_CODE)) {
				String customerId = retrieveCustomerIdResponse.getResult().getCustomerId();
				Date dateToday = new Date();
				String date = new SimpleDateFormat("MM/dd/yyyy").format(dateToday);
				String time = new SimpleDateFormat("HH:mm:ss").format(dateToday);

				StoreRecommendationApiRequest apiRequest = new StoreRecommendationApiRequest(request, customerId, date,
						time);
				response = restTemplate.postForObject(storeRecommendationApiUrl, apiRequest,
						StoreRecommendationResponse.class);
			} else {
				response = new StoreRecommendationResponse(retrieveCustomerIdResponse.getCode(),
						retrieveCustomerIdResponse.getMessage(), retrieveCustomerIdResponse.getDescription(),
						retrieveCustomerIdResponse.getSource());
			}
		} catch (ResourceAccessException e) {
			String description = String.format(Constants.RESOURCE_ACCESS_ERROR, storeRecommendationApiUrl);
			LOGGER.error(description, e);
			response = new StoreRecommendationResponse(String.valueOf(HttpStatus.REQUEST_TIMEOUT.value()),
					HttpStatus.REQUEST_TIMEOUT.getReasonPhrase(), description, Constants.SOURCE);
		} catch (HttpClientErrorException e) {
			String description = String.format(Constants.STORE_RECOMMENDATION_HTTP_ERROR, storeRecommendationApiUrl);
			LOGGER.error(description, e);
			response = new StoreRecommendationResponse(e.getStatusCode().toString(),
					e.getStatusCode().getReasonPhrase(), description, Constants.SOURCE);
		} catch (Exception e) {
			LOGGER.error(Constants.GENERIC_ERROR, e);
			response = new StoreRecommendationResponse(Constants.ERROR_CODE, Constants.GENERIC_ERROR);
		}

		LOGGER.info(Constants.LOGGER_END, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());

		return response;
	}

	@PostMapping(path = "${get-recommendation}")
	public GetRecommendationAndCPINResponse getRecommendationAndCPIN(
			@Valid @RequestBody GetRecommendationRequest request) {
		LOGGER.info(Constants.LOGGER_START, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		LOGGER.info(request.toString());
		GetRecommendationAndCPINResponse response = null;

		RetrieveCustomerIdRequest retrieveCustomerIdRequest = new RetrieveCustomerIdRequest(request.getHeader(),
				request.getTrustKey(), request.getUniqueNumber());
		RetrieveCustomerIdResponse retrieveCustomerIdResponse = getCustomerId(retrieveCustomerIdRequest);

		if (retrieveCustomerIdResponse.getCode().equals(Constants.SUCCESS_CODE)) {
			String customerId = retrieveCustomerIdResponse.getResult().getCustomerId();

			GetRecommendationApiRequest apiRequest = new GetRecommendationApiRequest(request.getHeader(),
					request.getTrustKey(), customerId);

			GetRecommendationAndCPINResponse odsResponse = getProductRecommendation(apiRequest);

			if (odsResponse.getCode().equals(Constants.SUCCESS_CODE)
					|| odsResponse.getCode().equals(Constants.NO_DATA_CODE)) {
				RecommendationAndCTIResult recommendationAndCTIResult = new RecommendationAndCTIResult();

				if (odsResponse.getResult() != null) {
					recommendationAndCTIResult.setOdsResponse(odsResponse);
				}

				GetCPINResponse cpinResponse = getCPIN(request, customerId);

				if (cpinResponse.getCode().equals(Constants.SUCCESS_CODE)
						|| cpinResponse.getCode().equals(Constants.NO_DATA_CODE)) {
					if (cpinResponse.getResult() != null) {
						recommendationAndCTIResult.setCpinResponse(cpinResponse);
					}

					GetLowMarketingResponse getLowMarketingResponse = getLowMarketing(request, customerId);

					if (getLowMarketingResponse.getCode().equals(Constants.SUCCESS_CODE)
							|| getLowMarketingResponse.getCode().equals(Constants.NO_DATA_CODE)) {
						if (getLowMarketingResponse.getResult() != null) {
							recommendationAndCTIResult
									.setLowMarketingInd(getLowMarketingResponse.getResult().getLowMarketingInd());
						}
						response = new GetRecommendationAndCPINResponse(recommendationAndCTIResult);
					} else {
						response = new GetRecommendationAndCPINResponse(getLowMarketingResponse.getCode(),
								getLowMarketingResponse.getMessage(), getLowMarketingResponse.getDescription(),
								getLowMarketingResponse.getSource());
					}
				} else {
					response = new GetRecommendationAndCPINResponse(cpinResponse.getCode(), cpinResponse.getMessage(),
							cpinResponse.getDescription(), cpinResponse.getSource());
				}
			} else {
				response = new GetRecommendationAndCPINResponse(odsResponse.getCode(), odsResponse.getMessage(),
						odsResponse.getDescription(), odsResponse.getSource());
			}
		} else {
			response = new GetRecommendationAndCPINResponse(retrieveCustomerIdResponse.getCode(),
					retrieveCustomerIdResponse.getMessage(), retrieveCustomerIdResponse.getDescription(),
					retrieveCustomerIdResponse.getSource());
		}

		LOGGER.info(Constants.LOGGER_END, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());

		return response;
	}

	@PostMapping("${retrieve-product-pitch}")
	public RetrieveProductPitchResponse retrieveProductPitch(@RequestBody @Valid RetrieveProductPitchRequest request) {
		LOGGER.info(Constants.LOGGER_START, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		LOGGER.info(Constants.RETRIEVE_PRODUCT_PITCH_REQUEST, request);
		RetrieveProductPitchResponse response = null;
		String url = null;

		try {
			response = restTemplate.postForObject(retrieveProductPitchUrl, request, RetrieveProductPitchResponse.class);

			if (response.getCode().equals(Constants.SUCCESS_CODE) && request.getPitchClassify().equals(Constants.CDU)) {
				RetrieveCustomerIdResponse retrieveCustomerIdResponse = getCustomerId(new RetrieveCustomerIdRequest(
						request.getHeader(), request.getTrustKey(), request.getUniqueNumber()));

				if (retrieveCustomerIdResponse.getCode().equals(Constants.SUCCESS_CODE)) {
					String customerId = retrieveCustomerIdResponse.getResult().getCustomerId();
					url = String.format(contactInfoUrl, request.getHeader().getApId(),
							request.getHeader().getBranchId(), request.getHeader().getEmployeeId(), customerId,
							request.getTrustKey());

					ContactInfoResponse contactInfoResponse = restTemplate.getForObject(url, ContactInfoResponse.class);

					if (contactInfoResponse.getCode().equals(Constants.SUCCESS_CODE)) {
						response.getResult().setContactInfo(contactInfoResponse.getResult());
					} else {
						response = new RetrieveProductPitchResponse(contactInfoResponse);
					}
				} else {
					response = new RetrieveProductPitchResponse(retrieveCustomerIdResponse.getCode(),
							retrieveCustomerIdResponse.getMessage(), retrieveCustomerIdResponse.getDescription(),
							retrieveCustomerIdResponse.getSource());
				}
			}
		} catch (ResourceAccessException e) {
			String description = String.format(Constants.RESOURCE_ACCESS_ERROR, url);
			LOGGER.error(description, e);
			response = new RetrieveProductPitchResponse(String.valueOf(HttpStatus.REQUEST_TIMEOUT.value()),
					HttpStatus.REQUEST_TIMEOUT.getReasonPhrase(), description, Constants.SOURCE);
		} catch (HttpClientErrorException e) {
			String description = String.format(Constants.RETRIEVE_PRODUCT_PITCH_HTTP_ERROR, url);
			LOGGER.error(description, e);
			response = new RetrieveProductPitchResponse(e.getStatusCode().toString(),
					e.getStatusCode().getReasonPhrase(), description, Constants.SOURCE);
		} catch (Exception e) {
			LOGGER.error(e.getLocalizedMessage(), e);
			response = new RetrieveProductPitchResponse(Constants.ERROR_CODE, Constants.GENERIC_ERROR);
		}

		LOGGER.info(Constants.RETRIEVE_PRODUCT_PITCH_RESPONSE, response);
		LOGGER.info(Constants.LOGGER_END, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());

		return response;
	}

	private RetrieveCustomerIdResponse getCustomerId(RetrieveCustomerIdRequest request) {
		LOGGER.info(Constants.GET_CUSTOMER_ID_REQUEST, request);
		RetrieveCustomerIdResponse response = null;

		try {
			response = restTemplate.postForObject(getCustomerIdApiUrl, request, RetrieveCustomerIdResponse.class);
		} catch (ResourceAccessException e) {
			String description = String.format(Constants.RESOURCE_ACCESS_ERROR, getCustomerIdApiUrl);
			LOGGER.error(description, e);
			response = new RetrieveCustomerIdResponse(String.valueOf(HttpStatus.REQUEST_TIMEOUT.value()),
					HttpStatus.REQUEST_TIMEOUT.getReasonPhrase(), description, Constants.SOURCE);
		} catch (HttpClientErrorException e) {
			String description = String.format(Constants.RETRIEVE_CUSTOMER_ID_HTTP_ERROR, getCustomerIdApiUrl);
			LOGGER.error(description, e);
			response = new RetrieveCustomerIdResponse(e.getStatusCode().toString(), e.getStatusCode().getReasonPhrase(),
					description, Constants.SOURCE);
		} catch (Exception e) {
			LOGGER.error(Constants.GENERIC_ERROR, e);
			response = new RetrieveCustomerIdResponse(Constants.ERROR_CODE, Constants.GENERIC_ERROR);
		}

		LOGGER.info(Constants.GET_CUSTOMER_ID_RESPONSE, response);
		return response;
	}

	private GetRecommendationAndCPINResponse getProductRecommendation(GetRecommendationApiRequest request) {
		LOGGER.info(Constants.GET_RECOMMENDATION_REQUEST, request);
		GetRecommendationAndCPINResponse response = null;

		try {
			response = restTemplate.postForObject(getRecommendationApiUrl, request,
					GetRecommendationAndCPINResponse.class);
		} catch (ResourceAccessException e) {
			String description = String.format(Constants.RESOURCE_ACCESS_ERROR, getRecommendationApiUrl);
			LOGGER.error(description, e);
			response = new GetRecommendationAndCPINResponse(String.valueOf(HttpStatus.REQUEST_TIMEOUT.value()),
					HttpStatus.REQUEST_TIMEOUT.getReasonPhrase(), description, Constants.SOURCE);
		} catch (HttpClientErrorException e) {
			String description = String.format(Constants.GET_RECOMMENDATION_API_HTTP_ERROR, getRecommendationApiUrl);
			LOGGER.error(description, e);
			response = new GetRecommendationAndCPINResponse(e.getStatusCode().toString(),
					e.getStatusCode().getReasonPhrase(), description, Constants.SOURCE);
		} catch (Exception e) {
			LOGGER.error(Constants.GENERIC_ERROR, e);
			response = new GetRecommendationAndCPINResponse(Constants.ERROR_CODE, Constants.GENERIC_ERROR);
		}

		LOGGER.info(Constants.GET_RECOMMENDATION_RESPONSE, response);
		return response;
	}

	private GetCPINResponse getCPIN(GetRecommendationRequest request, String customerId) {
		LOGGER.info(Constants.GET_CPIN_REQUEST, request, customerId);
		GetCPINResponse response = null;

		String urlFormat = getCPINUrl + "?ap_id=%s&teller_id=%s&customer_id=%s&branch=%s&token=%s";
		String url = String.format(urlFormat, request.getHeader().getApId(), request.getHeader().getEmployeeId(),
				customerId, request.getHeader().getBranchId(), request.getTrustKey());

		try {
			response = restTemplate.getForObject(url, GetCPINResponse.class);
		} catch (ResourceAccessException e) {
			String description = String.format(Constants.RESOURCE_ACCESS_ERROR, url);
			LOGGER.error(description, e);
			response = new GetCPINResponse(String.valueOf(HttpStatus.REQUEST_TIMEOUT.value()),
					HttpStatus.REQUEST_TIMEOUT.getReasonPhrase(), description, Constants.SOURCE);
		} catch (HttpClientErrorException e) {
			String description = String.format(Constants.GET_CPIN_HTTP_ERROR, url);
			LOGGER.error(description, e);
			response = new GetCPINResponse(e.getStatusCode().toString(), e.getStatusCode().getReasonPhrase(),
					description, Constants.SOURCE);
		} catch (Exception e) {
			LOGGER.error(Constants.GENERIC_ERROR, e);
			response = new GetCPINResponse(Constants.ERROR_CODE, Constants.GENERIC_ERROR);
		}

		LOGGER.info(Constants.GET_CPIN_RESPONSE, response);
		return response;
	}

	private GetLowMarketingResponse getLowMarketing(GetRecommendationRequest request, String customerId) {
		GetLowMarketingRequest getLowMarketingRequest = new GetLowMarketingRequest(request.getHeader(), customerId,
				request.getTrustKey());
		LOGGER.info(Constants.GET_LOW_MARKETING_REQUEST, getLowMarketingRequest);
		GetLowMarketingResponse response = null;

		try {
			response = restTemplate.postForObject(getLowMarketingUrl, getLowMarketingRequest,
					GetLowMarketingResponse.class);
		} catch (ResourceAccessException e) {
			String description = String.format(Constants.RESOURCE_ACCESS_ERROR, getLowMarketingUrl);
			LOGGER.error(description, e);
			response = new GetLowMarketingResponse(String.valueOf(HttpStatus.REQUEST_TIMEOUT.value()),
					HttpStatus.REQUEST_TIMEOUT.getReasonPhrase(), description, Constants.SOURCE);
		} catch (HttpClientErrorException e) {
			String description = String.format(Constants.GET_LOW_MARKETING_HTTP_ERROR, getLowMarketingUrl);
			LOGGER.error(description, e);
			response = new GetLowMarketingResponse(e.getStatusCode().toString(), e.getStatusCode().getReasonPhrase(),
					description, Constants.SOURCE);
		} catch (Exception e) {
			LOGGER.error(Constants.GENERIC_ERROR, e);
			response = new GetLowMarketingResponse(Constants.ERROR_CODE, Constants.GENERIC_ERROR);
		}

		LOGGER.info(Constants.GET_LOW_MARKETING_RESPONSE, response);
		return response;
	}

}
