package com.cathay.service.domain;

public class RetrieveProductPitchResponse extends BaseResponse {

	private RetrieveProductPitchResult result;

	public RetrieveProductPitchResponse() {
		super();
	}

	public RetrieveProductPitchResponse(ContactInfoResponse contactInfoResponse) {
		super();
		setCode(contactInfoResponse.getCode());
		setMessage(contactInfoResponse.getMessage());
		setDescription(contactInfoResponse.getDescription());
		setSource(contactInfoResponse.getSource());
	}

	public RetrieveProductPitchResponse(String code, String description) {
		super();
		setCode(code);
		setMessage(Constants.ERROR_MESSAGE);
		setDescription(description);
		setSource(Constants.SOURCE);
	}

	public RetrieveProductPitchResponse(String code, String message, String description, String source) {
		super();
		setCode(code);
		setMessage(message);
		setDescription(description);
		setSource(source);
	}

	public RetrieveProductPitchResult getResult() {
		return result;
	}

	public void setResult(RetrieveProductPitchResult result) {
		this.result = result;
	}

	@Override
	public String toString() {
		return new StringBuilder("{code=" + getCode() + ", message=" + getMessage() + ", description="
				+ getDescription() + ", source=" + getSource() + ", result=" + result + "}").toString();
	}

}
