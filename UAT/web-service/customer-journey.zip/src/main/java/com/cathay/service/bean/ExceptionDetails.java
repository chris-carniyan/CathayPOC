package com.cathay.service.bean;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.http.HttpStatus;

public class ExceptionDetails {
	
	private static final String FORMAT = "MM-dd-yyyy hh:mm:ss";
	
	private String timestamp;
	private int code;
	private String status;
	private String error;
	private String message;
	
	public ExceptionDetails(Throwable e) {
		super();
		this.timestamp = new SimpleDateFormat(FORMAT).format(new Date());
		
		if (e.getMessage().equals("404 Not Found")) {
			this.code = HttpStatus.NOT_FOUND.value();
			this.status = HttpStatus.NOT_FOUND.getReasonPhrase();
		} else if(e.getMessage().equals("400 Bad Request")) {
			this.code = HttpStatus.BAD_REQUEST.value();
			this.status = HttpStatus.BAD_REQUEST.getReasonPhrase();
		} else {
			this.code = HttpStatus.INTERNAL_SERVER_ERROR.value();
			this.status = HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase();
		}
		
		this.error = e.getClass().getName();
		this.message = e.getMessage();
	}

	public String getTimestamp() {
		return timestamp;
	}

	public int getCode() {
		return code;
	}

	public String getStatus() {
		return status;
	}

	public String getError() {
		return error;
	}

	public String getMessage() {
		return message;
	}
	
	@Override
	public String toString() {
		return "ExceptionDetails [timestamp=" + timestamp + ", code=" + code + ", status="
				+ status + ", error=" + error + ", message=" + message + "]";
	}
}
