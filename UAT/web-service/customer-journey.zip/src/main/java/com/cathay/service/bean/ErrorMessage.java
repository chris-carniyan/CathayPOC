package com.cathay.service.bean;

import java.text.SimpleDateFormat;
import java.util.Date;

public class ErrorMessage {
	
	private static final String FORMAT = "MM-dd-yyyy hh:mm:ss";
	private String timestamp;
	private int code;
	private String status;
	private String error;
	private String message;
	
	public ErrorMessage(int code, String status, String error, String message) {
		super();
		this.timestamp = new SimpleDateFormat(FORMAT).format(new Date());
		this.code = code;
		this.status = status;
		this.error = error;
		this.message = message;
	}
	
	public String getTimestamp() {
		return timestamp;
	}
	
	public int getCode() {
		return code;
	}
	
	public String getStatus() {
		return status;
	}
	
	public String getError() {
		return error;
	}
	
	public String getMessage() {
		return message;
	}

}
