package com.cathay.service.bean;

import java.util.List;

public class CustomerJourneyResult {

	private List<TimeSlot> timeSlots;
	private int updateDate;
	private int currentDate;

	public CustomerJourneyResult(List<TimeSlot> timeSlots, int updateDate, int currentDate) {
		super();
		this.timeSlots = timeSlots;
		this.updateDate = updateDate;
		this.currentDate = currentDate;
	}

	public List<TimeSlot> getTimeSlots() {
		return timeSlots;
	}

	public void setTimeSlots(List<TimeSlot> timeSlots) {
		this.timeSlots = timeSlots;
	}

	public int getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(int updateDate) {
		this.updateDate = updateDate;
	}

	public int getCurrentDate() {
		return currentDate;
	}

	public void setCurrentDate(int currentDate) {
		this.currentDate = currentDate;
	}
}
