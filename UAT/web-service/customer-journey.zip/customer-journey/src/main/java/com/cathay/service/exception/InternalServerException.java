package com.cathay.service.exception;

import org.springframework.http.HttpStatus;

import com.cathay.service.bean.ErrorMessage;

public class InternalServerException extends Exception {
	
	private static final long serialVersionUID = -1402829952129489508L;
	private static final int CODE = HttpStatus.INTERNAL_SERVER_ERROR.value();
	private static final String STATUS = HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase();
	private final ErrorMessage errorMessage;
	
	public InternalServerException(String message, String error) {
		super();
		errorMessage = new ErrorMessage(CODE, STATUS, error, message);
	}
	
	public ErrorMessage getErrorMessage() {
		return errorMessage;
	}

}
