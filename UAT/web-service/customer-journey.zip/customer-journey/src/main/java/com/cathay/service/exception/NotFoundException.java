package com.cathay.service.exception;

import org.springframework.http.HttpStatus;

import com.cathay.service.bean.ErrorMessage;

public class NotFoundException extends Exception {

	private static final long serialVersionUID = -1402829952129489508L;
	private static final int CODE = HttpStatus.NOT_FOUND.value();
	private static final String STATUS = HttpStatus.NOT_FOUND.getReasonPhrase();
	private final ErrorMessage errorMessage;
	
	public NotFoundException(String message, String error) {
		super();
		errorMessage = new ErrorMessage(CODE, STATUS, error, message);
	}
	
	public ErrorMessage getErrorMessage() {
		return errorMessage;
	}
}
