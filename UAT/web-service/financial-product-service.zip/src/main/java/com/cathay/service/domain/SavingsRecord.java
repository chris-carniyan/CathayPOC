package com.cathay.service.domain;

public class SavingsRecord {

	private String productDesc;

	public String getProductDesc() {
		return productDesc;
	}

	public void setProductDesc(String productDesc) {
		this.productDesc = productDesc;
	}

	@Override
	public String toString() {
		return new StringBuilder("{productDesc=" + productDesc + "}").toString();
	}

}
