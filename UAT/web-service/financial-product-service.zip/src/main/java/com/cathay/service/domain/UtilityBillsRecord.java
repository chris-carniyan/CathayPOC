package com.cathay.service.domain;

public class UtilityBillsRecord {

	private String cardNbr;
	private String txnDate;
	private String merchantName;
	private double txnAmt;

	public String getCardNbr() {
		return cardNbr;
	}

	public void setCardNbr(String cardNbr) {
		this.cardNbr = cardNbr;
	}

	public String getTxnDate() {
		return txnDate;
	}

	public void setTxnDate(String txnDate) {
		this.txnDate = txnDate;
	}

	public String getMerchantName() {
		return merchantName;
	}

	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}

	public double getTxnAmt() {
		return txnAmt;
	}

	public void setTxnAmt(double txnAmt) {
		this.txnAmt = txnAmt;
	}

	@Override
	public String toString() {
		return new StringBuilder("{cardNbr=" + cardNbr + ", txnDate=" + txnDate + ", merchantName=" + merchantName
				+ ", txnAmt=" + txnAmt + "}").toString();
	}
}
