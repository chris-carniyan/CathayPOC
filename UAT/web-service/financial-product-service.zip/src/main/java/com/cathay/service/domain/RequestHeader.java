package com.cathay.service.domain;

public class RequestHeader {
	
	private String apId;
	private String branchNo;
	private String tellerId;
	private String sourceIp;
	private String txnDateTime;
	
	public String getApId() {
		return apId;
	}
	public void setApId(String apId) {
		this.apId = apId;
	}
	public String getBranchNo() {
		return branchNo;
	}
	public void setBranchNo(String branchNo) {
		this.branchNo = branchNo;
	}
	public String getTellerId() {
		return tellerId;
	}
	public void setTellerId(String tellerId) {
		this.tellerId = tellerId;
	}
	public String getSourceIp() {
		return sourceIp;
	}
	public void setSourceIp(String sourceIp) {
		this.sourceIp = sourceIp;
	}

	public String getTxnDateTime() {
		return txnDateTime;
	}
	public void setTxnDateTime(String txnDateTime) {
		this.txnDateTime = txnDateTime;
	}
	
	@Override
	public String toString() {
		return String.format(this.getClass().getSimpleName() + ": [apId: %s, branchNo: %s, tellerId: %s, "
				+ "sourceIp: %s, tnxDateTime: %s]", apId, branchNo, tellerId, sourceIp, txnDateTime); 
	}
}
