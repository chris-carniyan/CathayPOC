package com.cathay.service.domain;

import java.util.List;

public class CreditCardDetails {

	private String customerId;
	private String countNo;
	private List<CreditCardRecord> records;

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getCountNo() {
		return countNo;
	}

	public void setCountNo(String countNo) {
		this.countNo = countNo;
	}

	public List<CreditCardRecord> getRecords() {
		return records;
	}

	public void setRecords(List<CreditCardRecord> records) {
		this.records = records;
	}

	@Override
	public String toString() {
		return new StringBuilder("{customerId=" + customerId + ", countNo=" + countNo + ", records=" + records + "}")
				.toString();
	}
}
