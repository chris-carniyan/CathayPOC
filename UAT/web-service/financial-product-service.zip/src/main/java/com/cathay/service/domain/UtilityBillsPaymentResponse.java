package com.cathay.service.domain;

public class UtilityBillsPaymentResponse extends BaseResponse {

	private UtilityBillsPayment result;

	public UtilityBillsPaymentResponse() {
		super();
	}

	public UtilityBillsPaymentResponse(String code, String description) {
		super(code, description);
	}

	public UtilityBillsPaymentResponse(String code, String message, String description, String source) {
		super(code, message, description, source);
	}

	public UtilityBillsPayment getResult() {
		return result;
	}

	public void setResult(UtilityBillsPayment result) {
		this.result = result;
	}

	@Override
	public String toString() {
		return new StringBuilder("{code=" + getCode() + ", message=" + getMessage() + ", description="
				+ getDescription() + ", source=" + getSource() + ", result=" + result + "}").toString();
	}

}
