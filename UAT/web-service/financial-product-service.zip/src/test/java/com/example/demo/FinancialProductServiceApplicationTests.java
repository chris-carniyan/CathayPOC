package com.example.demo;



public class FinancialProductServiceApplicationTests {

	/*@Test
	public void contextLoads() {
	}*/

}
