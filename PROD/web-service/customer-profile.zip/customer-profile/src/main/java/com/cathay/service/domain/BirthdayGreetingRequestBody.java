package com.cathay.service.domain;

public class BirthdayGreetingRequestBody extends RequestBodyProfile{
	
	private String customerName;
	private String ccVipInd;
	private String bankVipInd;
	

	public String getCcVipInd() {
		return ccVipInd;
	}
	public void setCcVipInd(String ccVipInd) {
		this.ccVipInd = ccVipInd;
	}
	public String getBankVipInd() {
		return bankVipInd;
	}
	public void setBankVipInd(String bankVipInd) {
		this.bankVipInd = bankVipInd;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	
}

