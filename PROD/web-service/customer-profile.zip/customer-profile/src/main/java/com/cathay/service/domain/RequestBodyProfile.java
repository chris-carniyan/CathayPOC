package com.cathay.service.domain;

public class RequestBodyProfile {
	private String apId;
	private String tellerId;
	private String branchNo;
	private String uniqueNumber;
	private String trustKey;
	
	public String getApId() {
		return apId;
	}
	public void setApId(String apId) {
		this.apId = apId;
	}
	public String getTellerId() {
		return tellerId;
	}
	public void setTellerId(String tellerId) {
		this.tellerId = tellerId;
	}
	public String getBranchNo() {
		return branchNo;
	}
	public void setBranchNo(String branchNo) {
		this.branchNo = branchNo;
	}
	public String getUniqueNumber() {
		return uniqueNumber;
	}
	public void setUniqueNumber(String uniqueNumber) {
		this.uniqueNumber = uniqueNumber;
	}
	public String getTrustKey() {
		return trustKey;
	}
	public void setTrustKey(String trustKey) {
		this.trustKey = trustKey;
	}
	@Override
	public String toString() {
		return "RequestBodyProfile [apId=" + apId + ", tellerId=" + tellerId + ", branchNo=" + branchNo
				+ ", uniqueNumber=" + uniqueNumber + ", trustKey=" + trustKey + "]";
	}
	
}
