package com.cathay.service.domain;

public class AuthenticationResponseBody {
	private String message;
	private CustomerObject body;
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public CustomerObject getBody() {
		return body;
	}
	public void setBody(CustomerObject body) {
		this.body = body;
	}
	@Override
	public String toString() {
		return "AuthenticationResponseBody [message=" + message + ", body=" + body + "]";
	}
	
}
