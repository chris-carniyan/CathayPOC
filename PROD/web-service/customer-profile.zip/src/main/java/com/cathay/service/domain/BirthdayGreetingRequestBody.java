package com.cathay.service.domain;

import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotBlank;

public class BirthdayGreetingRequestBody extends RequestBodyProfile {

	@NotBlank
	private String customerName;
	@Size(min = 1, max = 1, message = "text size must be 1")
	private String ccVipInd;
	@Size(min = 1, max = 1, message = "text size must be 1")
	private String bankVipInd;

	public String getCcVipInd() {
		return ccVipInd;
	}

	public void setCcVipInd(String ccVipInd) {
		this.ccVipInd = ccVipInd;
	}

	public String getBankVipInd() {
		return bankVipInd;
	}

	public void setBankVipInd(String bankVipInd) {
		this.bankVipInd = bankVipInd;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	@Override
	public String toString() {
		return new StringBuilder("{apId=" + getApId() + ", tellerId=" + getTellerId() + ", branchNo=" + getBranchNo()
				+ ", uniqueNumber=" + getUniqueNumber() + ", trustKey=" + getTrustKey() + ", customerName="
				+ customerName + ", ccVipInd=" + ccVipInd + ", bankVipInd=" + bankVipInd + "}").toString();
	}

}
