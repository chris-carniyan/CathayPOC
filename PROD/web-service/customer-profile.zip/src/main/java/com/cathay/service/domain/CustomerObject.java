package com.cathay.service.domain;

public class CustomerObject {
	private String customerId;
	private String description;
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	@Override
	public String toString() {
		return "CustomerID [customerId=" + customerId + ", description=" + description + "]";
	}
}
