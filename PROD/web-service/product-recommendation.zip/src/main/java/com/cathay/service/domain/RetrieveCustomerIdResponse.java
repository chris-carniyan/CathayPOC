package com.cathay.service.domain;

public class RetrieveCustomerIdResponse extends BaseResponse {

	private RetrieveCustomerIdResponseBody result;

	public RetrieveCustomerIdResponse() {
		super();
	}

	public RetrieveCustomerIdResponse(String code, String description) {
		super(code, description);
	}

	public RetrieveCustomerIdResponse(String code, String message, String description, String source) {
		super(code, message, description, source);
	}

	public RetrieveCustomerIdResponseBody getResult() {
		return result;
	}

	public void setResult(RetrieveCustomerIdResponseBody result) {
		this.result = result;
	}

	@Override
	public String toString() {
		return new StringBuilder("{code=" + getCode() + ", message=" + getMessage() + ", description="
				+ getDescription() + ", source=" + getSource() + ", result=" + result + "}").toString();
	}

}
