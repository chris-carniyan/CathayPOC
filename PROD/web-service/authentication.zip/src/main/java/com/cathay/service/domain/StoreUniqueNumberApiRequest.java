package com.cathay.service.domain;

public class StoreUniqueNumberApiRequest {

	private Header header;
	private String uniqueNumber;
	private String customerId;
	private String trustKey;

	public StoreUniqueNumberApiRequest(Header header, String uniqueNumber, String customerId, String trustKey) {
		super();
		this.header = header;
		this.uniqueNumber = uniqueNumber;
		this.customerId = customerId;
		this.trustKey = trustKey;
	}

	public Header getHeader() {
		return header;
	}

	public void setHeader(Header header) {
		this.header = header;
	}

	public String getUniqueNumber() {
		return uniqueNumber;
	}

	public void setUniqueNumber(String uniqueNumber) {
		this.uniqueNumber = uniqueNumber;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getTrustKey() {
		return trustKey;
	}

	public void setTrustKey(String trustKey) {
		this.trustKey = trustKey;
	}

	@Override
	public String toString() {
		return new StringBuilder("{header=" + header + ", uniqueNumber=" + uniqueNumber + ", customerId=" + customerId
				+ ", trustKey=" + trustKey + "}").toString();
	}

}
