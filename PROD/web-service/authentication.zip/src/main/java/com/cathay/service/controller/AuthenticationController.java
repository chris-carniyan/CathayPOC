package com.cathay.service.controller;

import java.util.Collections;
import java.util.UUID;

import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.cathay.service.domain.CommonResponse;
import com.cathay.service.domain.Constants;
import com.cathay.service.domain.GetTrustKeyApiRequest;
import com.cathay.service.domain.GetTrustKeyApiResponse;
import com.cathay.service.domain.GetTrustKeyRequest;
import com.cathay.service.domain.Header;
import com.cathay.service.domain.RetrieveCustomerIdRequest;
import com.cathay.service.domain.RetrieveCustomerIdResponse;
import com.cathay.service.domain.StoreUniqueNumberApiRequest;
import com.cathay.service.domain.StoreUniqueNumberResponse;
import com.cathay.service.domain.StoreUniqueNumberResult;
import com.cathay.service.domain.ValidateTrustKeyRequest;
import com.cathay.service.domain.ValidateTrustKeyResponse;

@CrossOrigin
@RestController
public class AuthenticationController {

	private static final Logger LOGGER = LogManager.getLogger(AuthenticationController.class);

	@Value("${auth.get.trustkey.url}")
	String getTrustKeyUrl;

	@Value("${auth.store.unique.number.url}")
	String storeUniqueNumberUrl;

	@Value("${auth.retrieve.customer.id.url}")
	String retrieveCustomerIdUrl;

	@Value("${validate-trust-key}")
	String validateTrustKeyUrl;

	@PostMapping("${auth.get.trustkey.mapping}")
	public CommonResponse getTrustKey(@Valid @RequestBody GetTrustKeyRequest request) {
		LOGGER.info(Constants.LOGGER_START, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		LOGGER.info(Constants.GET_TRUST_KEY_REQUEST, request);
		CommonResponse response = null;

		try {
			Header header = new Header(request);
			GetTrustKeyApiResponse getTrustKeyApiResponse = getTrustKeyFromApi(header);

			if (getTrustKeyApiResponse.getCode().equals(Constants.SUCCESS_CODE)) {
				StoreUniqueNumberResponse storeUniqueNumberResponse = storeUniqueNumber(header, request.getCustomerId(),
						getTrustKeyApiResponse.getTrustKey());
				response = new CommonResponse(storeUniqueNumberResponse);
			} else {
				response = new CommonResponse(getTrustKeyApiResponse);
			}
		} catch (Exception e) {
			LOGGER.error(Constants.GENERIC_ERROR, e);
			response = new CommonResponse(Constants.ERROR_CODE, Constants.GENERIC_ERROR);
		}

		LOGGER.info(Constants.GET_TRUST_KEY_RESPONSE, response);
		LOGGER.info(Constants.LOGGER_END, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		return response;
	}

	@PostMapping("${auth.retrieve.customer.id.mapping}")
	public CommonResponse retrieveCustomerId(@Valid @RequestBody RetrieveCustomerIdRequest request) {
		LOGGER.info(Constants.LOGGER_START, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		LOGGER.info(Constants.RETRIEVE_CUSTOMER_ID_REQUEST, request);
		CommonResponse response = null;

		try {
			RestTemplate restTemplate = new RestTemplate();
			RetrieveCustomerIdResponse restrieveCustomerIdResponse = restTemplate.postForObject(retrieveCustomerIdUrl,
					request, RetrieveCustomerIdResponse.class);
			response = new CommonResponse(restrieveCustomerIdResponse);
		} catch (HttpClientErrorException e) {
			String description = String.format(Constants.RETRIEVE_CUSTOMER_ID_HTTP_ERROR, retrieveCustomerIdUrl);
			LOGGER.error(description, e);
			response = new CommonResponse(e.getStatusCode().toString(), description);
		} catch (Exception e) {
			LOGGER.error(Constants.GENERIC_ERROR, e);
			response = new CommonResponse(Constants.ERROR_CODE, Constants.GENERIC_ERROR);
		}

		LOGGER.info(Constants.RETRIEVE_CUSTOMER_ID_RESPONSE, response);
		LOGGER.info(Constants.LOGGER_END, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		return response;
	}

	@PostMapping("${auth.validate.trustkey}")
	public ValidateTrustKeyResponse validateTrustKey(@Valid @RequestBody ValidateTrustKeyRequest request) {
		LOGGER.info(Constants.LOGGER_START, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		LOGGER.info(Constants.VALIDATE_TRUSTKEY_REQUEST, request);
		ValidateTrustKeyResponse response = null;

		try {
			RestTemplate restTemplate = new RestTemplate();
			response = restTemplate.postForObject(validateTrustKeyUrl, request, ValidateTrustKeyResponse.class);
		} catch (HttpClientErrorException e) {
			String description = String.format(Constants.VALIDATE_TRUST_KEY_ERROR, validateTrustKeyUrl);
			LOGGER.error(description, e);
			response = new ValidateTrustKeyResponse(request.getHeader(), e.getStatusCode().toString(), description,
					request.getTrustKey());
		} catch (Exception e) {
			LOGGER.error(Constants.GENERIC_ERROR, e);
			response = new ValidateTrustKeyResponse(request.getHeader(), Constants.ERROR_CODE, Constants.GENERIC_ERROR,
					request.getTrustKey());
		}

		LOGGER.info(Constants.VALIDATE_TRUSTKEY_RESPONSE, response);
		LOGGER.info(Constants.LOGGER_END, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		return response;
	}

	private StoreUniqueNumberResponse storeUniqueNumber(Header header, String customerId, String trustKey) {
		StoreUniqueNumberResponse response = null;

		try {
			String uniqueNumber = String.valueOf(UUID.randomUUID());
			StoreUniqueNumberApiRequest request = new StoreUniqueNumberApiRequest(header, uniqueNumber, customerId,
					trustKey);
			LOGGER.info(Constants.STORE_UNIQUE_NUMBER_REQUEST, request);
			RestTemplate restTemplate = new RestTemplate();
			response = restTemplate.postForObject(storeUniqueNumberUrl, request, StoreUniqueNumberResponse.class);

			if (response.getCode().equals(Constants.SUCCESS_CODE)) {
				response.setResult(new StoreUniqueNumberResult(header, uniqueNumber, customerId, trustKey));
			}
		} catch (HttpClientErrorException e) {
			String description = String.format(Constants.STORE_UNIQUE_NUMBER_HTTP_ERROR, storeUniqueNumberUrl);
			LOGGER.error(description, e);
			response = new StoreUniqueNumberResponse(e.getStatusCode().toString(), description);
		} catch (Exception e) {
			LOGGER.error(Constants.GENERIC_ERROR, e);
			response = new StoreUniqueNumberResponse(Constants.ERROR_CODE, Constants.GENERIC_ERROR);
		}

		LOGGER.info(Constants.STORE_UNIQUE_NUMBER_RESPONSE, response);
		return response;
	}

	private GetTrustKeyApiResponse getTrustKeyFromApi(Header header) {
		GetTrustKeyApiRequest request = new GetTrustKeyApiRequest(header);
		LOGGER.info(Constants.GET_TRUST_KEY_API_REQUEST, request);
		GetTrustKeyApiResponse response;

		try {
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
			RestTemplate restTemplate = new RestTemplate();
			HttpEntity<?> entity = new HttpEntity<>(request, headers);
			response = restTemplate.postForObject(getTrustKeyUrl, entity, GetTrustKeyApiResponse.class);
		} catch (HttpClientErrorException e) {
			String description = String.format(Constants.GET_TRUST_KEY_API_ERROR, getTrustKeyUrl);
			LOGGER.error(description, e);
			response = new GetTrustKeyApiResponse(e.getStatusCode().toString(), description);
		} catch (Exception e) {
			LOGGER.error(Constants.GENERIC_ERROR, e);
			response = new GetTrustKeyApiResponse(Constants.ERROR_CODE, Constants.GENERIC_ERROR);
		}

		LOGGER.info(Constants.GET_TRUST_KEY_API_RESPONSE, response);
		return response;
	}

}