package com.cathay.service.domain;

public class GetTrustKeyResponse {
	
	private Header header;
	private String trustKey;
	private String uniqueNumber;
	
	public GetTrustKeyResponse(Header header, String trustKey, String uniqueNumber) {
		super();
		this.header = header;
		this.trustKey = trustKey;
		this.uniqueNumber = uniqueNumber;
	}
	
	public Header getHeader() {
		return header;
	}

	public void setHeader(Header header) {
		this.header = header;
	}

	public String getTrustKey() {
		return trustKey;
	}

	public void setTrustKey(String trustKey) {
		this.trustKey = trustKey;
	}

	public String getUniqueNumber() {
		return uniqueNumber;
	}

	public void setUniqueNumber(String uniqueNumber) {
		this.uniqueNumber = uniqueNumber;
	}
	
}
