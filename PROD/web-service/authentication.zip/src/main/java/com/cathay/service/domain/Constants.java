package com.cathay.service.domain;

public class Constants {

	// Logging scope format
	public static final String LOGGER_START = "[START @{} ({})]";
	public static final String LOGGER_END = "[END @{} ({})]";

	// Response Code
	public static final String SUCCESS_CODE = "0000";
	public static final String ERROR_CODE = "1111";

	// Response Message
	public static final String SUCCESS_MESSAGE = "Success";
	public static final String ERROR_MESSAGE = "Error";

	// Origin or Source
	public static final String SOURCE = "Authentication Service";

	// Get trust key service
	public static final String GET_TRUST_KEY_REQUEST = "Get trust key request: {}";
	public static final String GET_TRUST_KEY_RESPONSE = "Get trust key response: {}";

	// Get trust key API
	public static final String GET_TRUST_KEY_API_REQUEST = "Getting trust key from API: {}";
	public static final String GET_TRUST_KEY_API_RESPONSE = "Get trust key API response: {}";

	// Store unique number service
	public static final String STORE_UNIQUE_NUMBER_REQUEST = "Store unique number request: {}";
	public static final String STORE_UNIQUE_NUMBER_RESPONSE = "Store unique number response: {}";

	// Retrieve customer id
	public static final String RETRIEVE_CUSTOMER_ID_REQUEST = "Retrieve customer id request: {}";
	public static final String RETRIEVE_CUSTOMER_ID_RESPONSE = "Retrieve customer id response: {}";
	
	// Validate trust key
	public static final String VALIDATE_TRUSTKEY_REQUEST = "Validate trust key request: {}";
	public static final String VALIDATE_TRUSTKEY_RESPONSE = "Validate trust key response: {}";

	/** Error Description **/
	public static final String GENERIC_ERROR = "An error occured, please see log details";
	public static final String BAD_REQUEST = "Invalid argument or request parameters";
	public static final String TYPE_MISMATCH_ERROR = "Type mismatch error, please check your request parameters";
	public static final String GET_TRUST_KEY_API_ERROR = "Error getting trust key from API using this url %s";
	public static final String STORE_UNIQUE_NUMBER_HTTP_ERROR = "Error storing unique number using this url %s";
	public static final String RETRIEVE_CUSTOMER_ID_HTTP_ERROR = "Error retrieving customer id using this url %s";
	public static final String VALIDATE_TRUST_KEY_ERROR = "Error validating trust key using this url %s";

	public static final String SAVING_AUDIT_TRAIL = "Saving audit trail..";
	public static final String SUCCESS = "Success";
	public static final String FAILURE = "Failure";
	
	private Constants() {
	}

}
