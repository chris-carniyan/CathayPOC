package com.cathay.service.controller;

import javax.servlet.http.HttpServletRequest;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.cathay.service.CustomerJourneyApplication;
import com.cathay.service.bean.ExceptionDetails;
import com.cathay.service.bean.Header;
import com.cathay.service.bean.ResponseBodyAuthentication;
import com.cathay.service.bean.TokenCustomerIdDetails;
import com.cathay.service.exception.BadRequestException;
import com.cathay.service.exception.InternalServerException;
import com.cathay.service.exception.NotFoundException;
import com.cathay.service.utility.Helper;

@CrossOrigin
@RestController
public class CustomerJourneyController {

	private static final Logger LOGGER = LogManager.getLogger(CustomerJourneyApplication.class);
	private static final String LOGGER_START = "*** START %s ***";
	private static final String LOGGER_END = "*** END %s ***";
	private static final String AP_ID = "ap_id";
	private static final String TELLER_ID = "teller_id";
	private static final String UNIQUE_NUMBER = "unique_number";
	private static final String BRANCH = "branch";
	private static final String TOKEN = "token";
	private static final String CHANNEL = "channel";
	private static final String DATE = "date";
	private static final String GET_REQUEST = "GET request, 200, ";
	private static final String EXCEPTION_BAD_REQUEST = "400 Bad Request";
	private static final String EXCEPTION_NOT_FOUND = "404 Not Found";
	private static final String EXCEPTION_INTERNAL_SERVER = "500 Internal Server Error";
	private static final String URL_SOURCE = "Data Source URL: {}";

	@Value("${authentication.uri}")
	public String authenticationUrl;

	@Value("${customer-journey.uri}")
	public String customerJourneyUrl;

	@Value("${customer-journey-detail.uri}")
	public String customerJourneyDetailUrl;

	@GetMapping(path = "${customer-journey.mapping}")
	public Object getCustomerJourney(@RequestParam(AP_ID) String apId, @RequestParam(TELLER_ID) String tellerId,
			@RequestParam(UNIQUE_NUMBER) String uniqueNumber, @RequestParam(BRANCH) String branch,
			@RequestParam(TOKEN) String token, HttpServletRequest request)
			throws BadRequestException, NotFoundException, InternalServerException {

		LOGGER.info(String.format(LOGGER_START, Helper.getCurrentClassAndMethodName()));
		Object data = null;

		Header header = new Header(apId, branch, tellerId, request.getRemoteAddr());

		String retrievedCustomerId;
		data = callAuthentication(header, uniqueNumber, token);

		if (data instanceof ResponseBodyAuthentication
				&& ((ResponseBodyAuthentication) data).getCode().equals("0000")) {
			retrievedCustomerId = ((ResponseBodyAuthentication) data).getResult().getCustomerId();
			String finalUrl = "";

			try {
				RestTemplate restTemplate = new RestTemplate();
				String tempUrl = customerJourneyUrl + "?ap_id=%s&teller_id=%s&customer_id=%s&branch=%s&token=%s";
				finalUrl = String.format(tempUrl, apId, tellerId, retrievedCustomerId, branch, token);
				data = restTemplate.getForObject(finalUrl, Object.class);
				LOGGER.info(GET_REQUEST + data.toString());
			} catch (RestClientException e) {
				LOGGER.error(e);
				LOGGER.error(URL_SOURCE, finalUrl);
				ExceptionDetails exceptionDetails = new ExceptionDetails(e);
				data = new ResponseEntity<Object>(exceptionDetails, HttpStatus.valueOf(exceptionDetails.getCode()));
			} catch (Exception e) {
				LOGGER.error(e);
				LOGGER.error(URL_SOURCE, finalUrl);
				data = new ResponseEntity<Object>(e, HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}

		LOGGER.info(String.format(LOGGER_END, Helper.getCurrentClassAndMethodName()));
		return data;
	}

	@GetMapping(path = "${customer-journey-detail.mapping}", produces = MediaType.APPLICATION_JSON_VALUE)
	public Object getCustomerJourneyDetail(@RequestParam(CHANNEL) String channel, @RequestParam(DATE) int date,
			@RequestParam(AP_ID) String apId, @RequestParam(TELLER_ID) String tellerId,
			@RequestParam(UNIQUE_NUMBER) String uniqueNumber, @RequestParam(BRANCH) String branch,
			@RequestParam(TOKEN) String token, HttpServletRequest request)
			throws BadRequestException, NotFoundException, InternalServerException {

		LOGGER.info(String.format(LOGGER_START, Helper.getCurrentClassAndMethodName()));
		Object data = null;
		String retrievedCustomerId;
		String tempUrl = customerJourneyDetailUrl + "?channel=%s&date=%s&ap_id=%s&teller_id=%s&customer_id=%s"
				+ "&branch=%s&token=%s";
		String finalUrl = "";

		Header header = new Header(apId, branch, tellerId, request.getRemoteAddr());
		data = callAuthentication(header, uniqueNumber, token);

		if (data instanceof ResponseBodyAuthentication
				&& ((ResponseBodyAuthentication) data).getCode().equals("0000")) {
			retrievedCustomerId = ((ResponseBodyAuthentication) data).getResult().getCustomerId();

			try {
				RestTemplate restTemplate = new RestTemplate();
				finalUrl = String.format(tempUrl, channel, date, apId, tellerId, retrievedCustomerId, branch, token);
				data = restTemplate.getForObject(finalUrl, Object.class);
				LOGGER.info(GET_REQUEST + data.toString());
			} catch (RestClientException e) {
				LOGGER.error(e);
				LOGGER.error(URL_SOURCE, customerJourneyUrl);
				ExceptionDetails exceptionDetails = new ExceptionDetails(e);
				data = new ResponseEntity<Object>(exceptionDetails, HttpStatus.valueOf(exceptionDetails.getCode()));
			} catch (Exception e) {
				LOGGER.error(e);
				LOGGER.error(URL_SOURCE, customerJourneyUrl);
				data = new ResponseEntity<Object>(e, HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}

		LOGGER.info(String.format(LOGGER_END, Helper.getCurrentClassAndMethodName()));
		return data;
	}

	private Object callAuthentication(Header header, String uniqueNumber, String token)
			throws BadRequestException, NotFoundException, InternalServerException {

		LOGGER.info(String.format(LOGGER_START, Helper.getCurrentClassAndMethodName()));
		Object retrievedCustomerId = null;
		TokenCustomerIdDetails tokenCustomerIdDetails = new TokenCustomerIdDetails(header, uniqueNumber, token);
		LOGGER.info("TOKEN: {}", tokenCustomerIdDetails);

		try {
			RestTemplate restTemplate = new RestTemplate();
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<Object> entity = new HttpEntity<>(tokenCustomerIdDetails, headers);
			retrievedCustomerId = restTemplate.postForObject(authenticationUrl, entity,
					ResponseBodyAuthentication.class);
		} catch (RestClientException e) {
			LOGGER.error(e);
			LOGGER.error(URL_SOURCE, authenticationUrl);

			if (e.getMessage().equals(EXCEPTION_BAD_REQUEST)) {
				throw new BadRequestException(e.getClass().getName(), e.getLocalizedMessage());
			}

			if (e.getMessage().equals(EXCEPTION_NOT_FOUND)) {
				throw new NotFoundException(e.getClass().getName(), e.getLocalizedMessage());
			}

			if (e.getMessage().equals(EXCEPTION_INTERNAL_SERVER)) {
				throw new InternalServerException(e.getClass().getName(), e.getLocalizedMessage());
			}
		}
		LOGGER.info(String.format(LOGGER_END, Helper.getCurrentClassAndMethodName()));
		LOGGER.info("Customer Id: " + retrievedCustomerId);
		return retrievedCustomerId;
	}

}