package com.cathay.service.domain;

public class SavingsResponse extends BaseResponse {

	private Savings result;

	public SavingsResponse() {
		super();
	}

	public SavingsResponse(String code, String description) {
		super(code, description);
	}

	public SavingsResponse(String code, String message, String description, String source) {
		super(code, message, description, source);
	}

	public Savings getResult() {
		return result;
	}

	public void setResult(Savings result) {
		this.result = result;
	}

	@Override
	public String toString() {
		return new StringBuilder("{code=" + getCode() + ", message=" + getMessage() + ", description="
				+ getDescription() + ", source=" + getSource() + ", result=" + result + "}").toString();
	}

}
