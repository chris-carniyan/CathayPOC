package com.cathay.service.domain;

public class AutoAcctDebitingRecord {

	private String bankDesc;
	private String acctNbr;
	private String autopayPercent;
	private String validDate;

	public String getBankDesc() {
		return bankDesc;
	}

	public void setBankDesc(String bankDesc) {
		this.bankDesc = bankDesc;
	}

	public String getAcctNbr() {
		return acctNbr;
	}

	public void setAcctNbr(String acctNbr) {
		this.acctNbr = acctNbr;
	}

	public String getAutopayPercent() {
		return autopayPercent;
	}

	public void setAutopayPercent(String autopayPercent) {
		this.autopayPercent = autopayPercent;
	}

	public String getValidDate() {
		return validDate;
	}

	public void setValidDate(String validDate) {
		this.validDate = validDate;
	}

	@Override
	public String toString() {
		return new StringBuilder("{bankDesc=" + bankDesc + ", acctNbr=" + acctNbr + ", autopayPercent=" + autopayPercent
				+ ", validDate=" + validDate + "}").toString();
	}
}
