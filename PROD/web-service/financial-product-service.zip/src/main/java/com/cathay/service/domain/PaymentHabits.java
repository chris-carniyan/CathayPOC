package com.cathay.service.domain;

import java.util.List;

public class PaymentHabits {

	private String customerId;
	private String recordNum;
	private List<PaymentHabitsRecord> records;

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getRecordNum() {
		return recordNum;
	}

	public void setRecordNum(String recordNum) {
		this.recordNum = recordNum;
	}

	public List<PaymentHabitsRecord> getRecords() {
		return records;
	}

	public void setRecords(List<PaymentHabitsRecord> records) {
		this.records = records;
	}

	@Override
	public String toString() {
		return new StringBuilder(
				"{customerId=" + customerId + ", recordNum=" + recordNum + ", records=" + records + "}").toString();
	}

}
