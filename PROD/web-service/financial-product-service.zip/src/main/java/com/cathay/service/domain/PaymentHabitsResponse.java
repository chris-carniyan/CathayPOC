package com.cathay.service.domain;

public class PaymentHabitsResponse extends BaseResponse {

	private PaymentHabits result;

	public PaymentHabitsResponse() {
		super();
	}

	public PaymentHabitsResponse(String code, String description) {
		super(code, description);
	}

	public PaymentHabitsResponse(String code, String message, String description, String source) {
		super(code, message, description, source);
	}

	public PaymentHabits getResult() {
		return result;
	}

	public void setResult(PaymentHabits result) {
		this.result = result;
	}

	@Override
	public String toString() {
		return new StringBuilder("{code=" + getCode() + ", message=" + getMessage() + ", description="
				+ getDescription() + ", source=" + getSource() + ", result=" + result + "}").toString();
	}

}
