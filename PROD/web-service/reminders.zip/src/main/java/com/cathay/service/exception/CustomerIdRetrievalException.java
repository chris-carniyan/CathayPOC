package com.cathay.service.exception;

public class CustomerIdRetrievalException extends Exception{

	private static final long serialVersionUID = 8256001114194751810L;

	public CustomerIdRetrievalException() {
        this("Error while retrieving customer Id.");
    }

    public CustomerIdRetrievalException(String message) {
        super(message);
    }

    public CustomerIdRetrievalException(Throwable throwable) {
        super(throwable);
    }

    public CustomerIdRetrievalException(String message, Throwable throwable) {
        super(message, throwable);
    }
}
