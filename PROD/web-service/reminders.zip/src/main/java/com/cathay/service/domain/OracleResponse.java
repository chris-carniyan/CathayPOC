package com.cathay.service.domain;

public class OracleResponse extends BaseResponse{
	
	private OracleResponseBody result;

	public OracleResponseBody getResult() {
		return result;
	}

	public void setResult(OracleResponseBody result) {
		this.result = result;
	}

	@Override
	public String toString() {
		return "OracleResponse [result=" + result + "]";
	}
	
}
