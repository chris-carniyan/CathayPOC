package com.cathay.job.repository;

import org.springframework.data.repository.CrudRepository;

import com.cathay.job.domain.GiftDetails;

public interface GiftDetailsRepository extends CrudRepository<GiftDetails, Long>{

}
