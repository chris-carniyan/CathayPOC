package com.cathay.job.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.cathay.job.domain.GiftDetails;

@Service
public class GiftDataRetrievalService {

	private static final Logger LOGGER = LogManager.getLogger(GiftDataRetrievalService.class);
	
	private static final String LOGGER_START = "[START @{} ({})]";
	private static final String LOGGER_END = "[END @{} ({})]";
	
	private static final int PID_INDEX = 0;
	private static final int PNAME_INDEX = 1;
	private static final int FFLAG_INDEX = 2;
	private static final int FCNT_INDEX = 3;
	private static final int FAMT_INDEX = 4;
	private static final int TFLAG_INDEX = 5;
	private static final int TAMT_INDEX = 6;
	
	@Value("${data-location}")
	private String path;

	public List<GiftDetails> retrieveDataFromFile(File file){
		
		LOGGER.info(LOGGER_START, 
				this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());

		String line = "";
		List<GiftDetails> data = new ArrayList<>();
		int i = 1; 	
		
		try(BufferedReader br  = new BufferedReader(
			    new InputStreamReader(new FileInputStream(file), "big5"))) {
			
	        while ((line = br.readLine()) != null) {   
	        	String[] details = line.split("\\^");
	        	GiftDetails giftData = new GiftDetails();
	        	giftData.setPid(details[PID_INDEX]);  
	        	giftData.setpName(details[PNAME_INDEX]);		    
	        	giftData.setfFlag(details[FFLAG_INDEX]);
	        	giftData.setfCnt(Integer.parseInt(details[FCNT_INDEX]));
	        	
	        	if(details[FAMT_INDEX].equals("－")) {
		        	giftData.setfAmt(0);
	        	} else {
		        	giftData.setfAmt(Double.parseDouble(details[FAMT_INDEX]));
	        	}
	        	
	        	giftData.settFlag(details[TFLAG_INDEX]);
	        	
	        	if(details[TAMT_INDEX].equals("－")) {
	        		giftData.settAmt(0);	        	
	        	} else {
	        		giftData.settAmt(Double.parseDouble(details[TAMT_INDEX]));	        					
				}
		
	        	data.add(giftData);
	        	i++;
	        }
	     	      
		} catch (NumberFormatException e) {
	    	LOGGER.error("Invalid value/s for numerical fields at row " + i, e);	           
	    } catch (IllegalArgumentException e) {
	    	LOGGER.error("Invalid value/s at row " + i, e);	       
	    }		
		catch (IOException e) {
	    	LOGGER.error(e.getMessage(), e);
	    } 
		
		LOGGER.info(LOGGER_END, 
				this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		
		return data;
		
	}
	
	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}
}
