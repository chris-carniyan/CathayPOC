package com.api.cub.mongoserviceapi.domain;

public class ResponseObjectTemp<T> {
	private String api_code;
	private String message;
	private T result;

	public String getApi_code() {
		return api_code;
	}

	public void setApi_code(String api_code) {
		this.api_code = api_code;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public T getResult() {
		return result;
	}

	public void setResult(T result) {
		this.result = result;
	}

	@Override
	public String toString() {
		return "ResponseObject [api_code=" + api_code + ", message=" + message + ", result=" + result + "]";
	}
}
