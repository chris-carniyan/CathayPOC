package com.api.cub.mongoserviceapi.domain;

public class TokenValidator {
	private String errorMessage;
	private boolean tokenValid;
	private String code;
	
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public boolean isTokenValid() {
		return tokenValid;
	}
	public void setTokenValid(boolean tokenValid) {
		this.tokenValid = tokenValid;
	}
	@Override
	public String toString() {
		return "TokenValidator [errorMessage=" + errorMessage + ", tokenValid=" + tokenValid + ", code=" + code + "]";
	}
}
