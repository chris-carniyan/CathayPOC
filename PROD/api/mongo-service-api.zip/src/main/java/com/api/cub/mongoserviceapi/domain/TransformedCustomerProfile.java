package com.api.cub.mongoserviceapi.domain;

public class TransformedCustomerProfile {
	private String apId;
	private int age;
	private int birthMonth;
	private String bankVip;
	private int complaintCount;
	
	public String getApId() {
		return apId;
	}
	public void setApId(String apId) {
		this.apId = apId;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int getBirthMonth() {
		return birthMonth;
	}
	public void setBirthMonth(int birthMonth) {
		this.birthMonth = birthMonth;
	}
	public String getBankVip() {
		return bankVip;
	}
	public void setBankVip(String bankVip) {
		this.bankVip = bankVip;
	}
	public int getComplaintCount() {
		return complaintCount;
	}
	public void setComplaintCount(int complaintCount) {
		this.complaintCount = complaintCount;
	}
	@Override
	public String toString() {
		return "TransformedCustomerProfile [apId=" + apId + ", age=" + age + ", birthMonth=" + birthMonth + ", bankVip="
				+ bankVip + ", complaintCount=" + complaintCount + "]";
	}
}
