package com.api.cub.mongoserviceapi.domain;

public class TransformedReminder {
	private String apId;
	private Boolean anyActivities;

	public String getApId() {
		return apId;
	}

	public void setApId(String apId) {
		this.apId = apId;
	}


	public Boolean getAnyActivities() {
		return anyActivities;
	}

	public void setAnyActivities(Boolean anyActivities) {
		this.anyActivities = anyActivities;
	}

	@Override
	public String toString() {
		return "TransformedReminder [apId=" + apId + ", anyActivities=" + anyActivities + "]";
	}
}
