package com.api.cub.mongoserviceapi.domain;

import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document(collection="cti_crm")
public class ProblemPrediction {
	@Field("problem_prediction")
	private List<String> questions;

	public List<String> getQuestions() {
		return questions;
	}

	public void setQuestions(List<String> questions) {
		this.questions = questions;
	}

	@Override
	public String toString() {
		return "ProblemPrediction [questions=" + questions + "]";
	}
}
