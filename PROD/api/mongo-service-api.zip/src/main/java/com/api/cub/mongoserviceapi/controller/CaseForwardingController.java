package com.api.cub.mongoserviceapi.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestClientException;

import com.api.cub.mongoserviceapi.domain.EncryptDataRequest;
import com.api.cub.mongoserviceapi.domain.EncryptDataResponse;
import com.api.cub.mongoserviceapi.domain.ParameterValidationResponse;
import com.api.cub.mongoserviceapi.domain.RequestTokenObject;
import com.api.cub.mongoserviceapi.domain.ResponseObject;
import com.api.cub.mongoserviceapi.domain.TokenValidator;
import com.api.cub.mongoserviceapi.domain.TransformedCaseForwarding;
import com.api.cub.mongoserviceapi.domain.TransformedCaseForwardingContactInfo;
import com.api.cub.mongoserviceapi.helper.APIHelper;
import com.api.cub.mongoserviceapi.helper.ExceptionDetails;
import com.api.cub.mongoserviceapi.helper.ParameterValidator;
import com.api.cub.mongoserviceapi.service.CaseForwardingService;
import com.api.cub.mongoserviceapi.service.EncryptedDataService;
import com.api.cub.mongoserviceapi.service.TokenValidatorService;

@CrossOrigin
@RestController
public class CaseForwardingController {
	
	private static final Logger logger = LogManager.getLogger(CaseForwardingController.class);
	private static final String LOGGER_START = "[START @{} ({})]";
	private static final String LOGGER_END = "[END @{} ({})]";
	private static final String ERROR = "ERROR";
	private static final String CODE_ERROR = "1111";
	
	@Autowired
	TokenValidatorService tokenValidatorService;
	
	@Autowired
	CaseForwardingService caseForwardingService;	
	
	@Autowired
	EncryptedDataService encryptedDataService;
	
	@GetMapping("/case_forwarding")
	public ResponseObject<TransformedCaseForwarding> getCaseForwarding(@RequestParam(value = "ap_id") String apId,
			@RequestParam(value = "teller_id") String tellerId, @RequestParam(value = "customer_id") String customerId,
			@RequestParam(value = "branch") String branch, @RequestParam(value = "token") String token) {
		
		logger.info(LOGGER_START, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		
		ParameterValidationResponse validResponse = new ParameterValidationResponse();
		TokenValidator tokenResponse = new TokenValidator();
		ResponseObject<TransformedCaseForwarding> transformedCaseForwardingResponse = new ResponseObject<>();
		EncryptDataResponse encryptDataResponse = new EncryptDataResponse();
		EncryptDataRequest encryptedDataRequest = new EncryptDataRequest();
		
		try {
			logger.info("validating parameters");
			validResponse = ParameterValidator.validateParameters(apId, tellerId, customerId, branch, token);
			if (validResponse.isValidParams()) {
				RequestTokenObject requestTokenObject = APIHelper.requestObjectTokenBuilder(apId, tellerId, branch,
						token);
				logger.info("requestTokenObject: " + requestTokenObject.toString());
				tokenResponse = tokenValidatorService.validateToken(requestTokenObject);
				if (tokenResponse.isTokenValid()) {
					encryptedDataRequest = APIHelper.encryptDataRequestBuilder(apId, branch, tellerId, "127.0.0.1", customerId, encryptedDataService.getPlainDataType(customerId), token);
					logger.info("encryptedDataRequest: " + encryptedDataRequest.toString());
					encryptDataResponse = encryptedDataService.encryptData(encryptedDataRequest);
					logger.info("encryptDataResponse: " + encryptDataResponse.toString());
					transformedCaseForwardingResponse = caseForwardingService.getCaseForwarding(encryptDataResponse.getEncrytedData(), apId);
				} else {
					transformedCaseForwardingResponse.setCode(tokenResponse.getCode());
					transformedCaseForwardingResponse.setMessage(ERROR);
					transformedCaseForwardingResponse.setDescription(tokenResponse.getErrorMessage());
					transformedCaseForwardingResponse.setSource("Mongo-API Validating Token CaseForwardController.java [method]getCaseForwarding()");
				}
			} else {
				transformedCaseForwardingResponse.setCode(validResponse.getCode());
				transformedCaseForwardingResponse.setMessage(ERROR);
				transformedCaseForwardingResponse.setDescription(validResponse.getErrorMessage());
				transformedCaseForwardingResponse.setSource("Mongo-API Validating Parameters CaseForwardController.java [method]getCaseForwarding()");
			}
		} catch (RestClientException e) {
			transformedCaseForwardingResponse.setCode(CODE_ERROR);
			transformedCaseForwardingResponse.setMessage(ERROR);
			transformedCaseForwardingResponse.setDescription("RestClientException occured during token validator in CaseForwardingController.java");
			transformedCaseForwardingResponse.setSource("CaseForwardController.java [method]getCaseForwarding()");
			ExceptionDetails exceptionDetails = new ExceptionDetails(e);
			logger.error("RestClientException occured during token validator.", exceptionDetails.toString());
		} catch (Exception e) {
			transformedCaseForwardingResponse.setCode(CODE_ERROR);
			transformedCaseForwardingResponse.setMessage(ERROR);
			transformedCaseForwardingResponse.setDescription("Exception occured during token validator in CaseForwardingController.java");
			transformedCaseForwardingResponse.setSource("CaseForwardController.java [method]getCaseForwarding()");
			ExceptionDetails exceptionDetails = new ExceptionDetails(e);
			logger.error("Exception occured during token validator. ", exceptionDetails.toString());
		}
		
		logger.info(LOGGER_END, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		
		return transformedCaseForwardingResponse;
	}
	
	@GetMapping("/case_forwarding/contact_info")
	public ResponseObject<TransformedCaseForwardingContactInfo> getCaseForwardingContactInfo(@RequestParam(value = "ap_id") String apId,
			@RequestParam(value = "teller_id") String tellerId, @RequestParam(value = "customer_id") String customerId,
			@RequestParam(value = "branch") String branch, @RequestParam(value = "token") String token) {
		
		logger.info(LOGGER_START, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		
		ParameterValidationResponse validResponse = new ParameterValidationResponse();
		TokenValidator tokenResponse = new TokenValidator();
		ResponseObject<TransformedCaseForwardingContactInfo> transformedCaseForwardingContactInfoResponse = new ResponseObject<>();
		EncryptDataResponse encryptDataResponse = new EncryptDataResponse();
		EncryptDataRequest encryptedDataRequest = new EncryptDataRequest();
		
		try {
			logger.info("validating parameters");
			validResponse = ParameterValidator.validateParameters(apId, tellerId, customerId, branch, token);
			if (validResponse.isValidParams()) {
				RequestTokenObject requestTokenObject = APIHelper.requestObjectTokenBuilder(apId, tellerId, branch,
						token);
				logger.info("requestTokenObject: " + requestTokenObject.toString());
				tokenResponse = tokenValidatorService.validateToken(requestTokenObject);
				if (tokenResponse.isTokenValid()) {
					encryptedDataRequest = APIHelper.encryptDataRequestBuilder(apId, branch, tellerId, "127.0.0.1", customerId, encryptedDataService.getPlainDataType(customerId), token);
					logger.info("encryptedDataRequest: " + encryptedDataRequest.toString());
					encryptDataResponse = encryptedDataService.encryptData(encryptedDataRequest);
					logger.info("encryptDataResponse: " + encryptDataResponse.toString());
					transformedCaseForwardingContactInfoResponse = caseForwardingService.getCaseForwardingContactInfo(encryptDataResponse.getEncrytedData(), apId);
				} else {
					transformedCaseForwardingContactInfoResponse.setCode(tokenResponse.getCode());
					transformedCaseForwardingContactInfoResponse.setMessage(ERROR);
					transformedCaseForwardingContactInfoResponse.setDescription(tokenResponse.getErrorMessage());
					transformedCaseForwardingContactInfoResponse.setSource("Mongo-API Validating Token CaseForwardController.java [method]getCaseForwardingContactInfo()");
				}
			} else {
				transformedCaseForwardingContactInfoResponse.setCode(validResponse.getCode());
				transformedCaseForwardingContactInfoResponse.setMessage(ERROR);
				transformedCaseForwardingContactInfoResponse.setDescription(validResponse.getErrorMessage());
				transformedCaseForwardingContactInfoResponse.setSource("Mongo-API Validating Parameters CaseForwardController.java [method]getCaseForwardingContactInfo()");
			}
		} catch (RestClientException e) {
			transformedCaseForwardingContactInfoResponse.setCode(CODE_ERROR);
			transformedCaseForwardingContactInfoResponse.setMessage(ERROR);
			transformedCaseForwardingContactInfoResponse.setDescription("RestClientException occured during token validator in CaseForwardingController.java");
			transformedCaseForwardingContactInfoResponse.setSource("CaseForwardController.java [method]getCaseForwardingContactInfo()");
			ExceptionDetails exceptionDetails = new ExceptionDetails(e);
			logger.error("RestClientException occured during token validator.", exceptionDetails.toString());
		} catch (Exception e) {
			transformedCaseForwardingContactInfoResponse.setCode(CODE_ERROR);
			transformedCaseForwardingContactInfoResponse.setMessage(ERROR);
			transformedCaseForwardingContactInfoResponse.setDescription("Exception occured during token validator in CaseForwardingController.java");
			transformedCaseForwardingContactInfoResponse.setSource("CaseForwardController.java [method]getCaseForwardingContactInfo()");
			ExceptionDetails exceptionDetails = new ExceptionDetails(e);
			logger.error("Exception occured during token validator. ", exceptionDetails.toString());
		}
		
		logger.info(LOGGER_END, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		
		return transformedCaseForwardingContactInfoResponse;
	
	}
}
