package com.api.cub.mongoserviceapi.controller;

import java.text.ParseException;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestClientException;

import com.api.cub.mongoserviceapi.domain.EncryptDataRequest;
import com.api.cub.mongoserviceapi.domain.EncryptDataResponse;
import com.api.cub.mongoserviceapi.domain.JourneyDetailEvent;
import com.api.cub.mongoserviceapi.domain.ParameterValidationResponse;
import com.api.cub.mongoserviceapi.domain.RequestTokenObject;
import com.api.cub.mongoserviceapi.domain.ResponseObject;
import com.api.cub.mongoserviceapi.domain.TokenValidator;
import com.api.cub.mongoserviceapi.domain.TransformedCustomerJourney;
import com.api.cub.mongoserviceapi.helper.APIHelper;
import com.api.cub.mongoserviceapi.helper.ExceptionDetails;
import com.api.cub.mongoserviceapi.helper.LogServiceHelper;
import com.api.cub.mongoserviceapi.helper.ParameterValidator;
import com.api.cub.mongoserviceapi.service.CustomerJourneyService;
import com.api.cub.mongoserviceapi.service.EncryptedDataService;
import com.api.cub.mongoserviceapi.service.TokenValidatorService;

@CrossOrigin
@RestController
public class CustomerJourneyController {
	private static final Logger logger = LogManager.getLogger(CustomerJourneyController.class);
	private static final String ERROR = "ERROR";
	private static final String CODE_ERROR = "1111";
	
	@Autowired
	TokenValidatorService tokenValidatorService;

	@Autowired
	CustomerJourneyService customerJourneyService;

	@Autowired
	EncryptedDataService encryptedDataService;

	@GetMapping("/journey")
	public ResponseObject<TransformedCustomerJourney> getCustomerJourney(@RequestParam(value = "ap_id") String apiId,
			@RequestParam(value = "teller_id") String tellerId, @RequestParam(value = "customer_id") String customerId,
			@RequestParam(value = "branch") String branch, @RequestParam(value = "token") String token) {
		logger.info("*START* {}", LogServiceHelper.getCurrentClassAndMethodName());
		logger.info("*apiId* {}" + apiId);
		ParameterValidationResponse validResponse = new ParameterValidationResponse();
		TokenValidator tokenResponse = new TokenValidator();
		ResponseObject<TransformedCustomerJourney> journeyResponse = new ResponseObject<>();
		EncryptDataResponse encryptDataResponse = new EncryptDataResponse();
		EncryptDataRequest encryptedDataRequest = new EncryptDataRequest();

		try {
			// validating params
			logger.info("validating parameters");
			validResponse = ParameterValidator.validateParameters(apiId, tellerId, customerId, branch, token);
			if (validResponse.isValidParams()) {
				// validating token
				RequestTokenObject requestTokenObject = APIHelper.requestObjectTokenBuilder(apiId, tellerId, branch,
						token);
				logger.info("requestTokenObject: " + requestTokenObject.toString());

				tokenResponse = tokenValidatorService.validateToken(requestTokenObject);
				// if token valid, proceed. Else, invalid token.
				if (tokenResponse.isTokenValid()) {
					encryptedDataRequest = APIHelper.encryptDataRequestBuilder(apiId, branch, tellerId, "127.0.0.1",
							customerId, encryptedDataService.getPlainDataType(customerId), token);
					logger.info("encryptedDataRequest: " + encryptedDataRequest.toString());
					encryptDataResponse = encryptedDataService.encryptData(encryptedDataRequest);
					logger.info("encryptDataResponse: " + encryptDataResponse.toString());
					journeyResponse = customerJourneyService.getCustomerJourney(encryptDataResponse.getEncrytedData(),
							apiId);
				} else {
					journeyResponse.setCode(tokenResponse.getCode());
					journeyResponse.setMessage(ERROR);
					journeyResponse.setDescription(tokenResponse.getErrorMessage());
					journeyResponse.setSource("Mongo-API Validating Token CustomerJourneyController.java [method] getCustomerJourney()");
				}
			} else {
				journeyResponse.setCode(validResponse.getCode());
				journeyResponse.setMessage(ERROR);
				journeyResponse.setDescription(validResponse.getErrorMessage());
				journeyResponse.setSource("Mongo-API Validating Parameters CustomerJourneyController.java [method] getCustomerJourney()");
			}

		} catch (RestClientException e) {
			journeyResponse.setCode(CODE_ERROR);
			journeyResponse.setMessage(ERROR);
			journeyResponse.setDescription("RestClientException occured during token validator in CustomerJourneyController.java");
			journeyResponse.setSource("CustomerJourneyController.java [method] getCustomerJourney()");
			ExceptionDetails exceptionDetails = new ExceptionDetails(e);
			logger.error("RestClientException occured during token validator.", exceptionDetails.toString());
		} catch (Exception e) {
			journeyResponse.setCode(CODE_ERROR);
			journeyResponse.setMessage(ERROR);
			journeyResponse.setDescription("RestClientException occured during token validator in CustomerJourneyController.java");
			journeyResponse.setSource("CustomerJourneyController.java [method] getCustomerJourney()");
			ExceptionDetails exceptionDetails = new ExceptionDetails(e);
			logger.error("Exception occured during token validator. ", exceptionDetails.toString());
		}
		logger.info("*END* {}", LogServiceHelper.getCurrentClassAndMethodName());
		return journeyResponse;
	}

	@GetMapping("/journey/detail")
	public ResponseObject<List<JourneyDetailEvent>> getCustomerJourneyDetails(
			@RequestParam(value = "channel") String channel, @RequestParam(value = "date") long date,
			@RequestParam(value = "ap_id") String apiId, @RequestParam(value = "teller_id") String tellerId,
			@RequestParam(value = "customer_id") String customerId, @RequestParam(value = "branch") String branch,
			@RequestParam(value = "token") String token) {
		ResponseObject<List<JourneyDetailEvent>> journeyDetailsResponse = new ResponseObject<>();
		logger.info("*START* {}", LogServiceHelper.getCurrentClassAndMethodName());
		ParameterValidationResponse validResponse = new ParameterValidationResponse();
		TokenValidator tokenResponse = new TokenValidator();
		EncryptDataResponse encryptDataResponse = new EncryptDataResponse();
		EncryptDataRequest encryptedDataRequest = new EncryptDataRequest();

		try {
			validResponse = ParameterValidator.validateCustomerJourneyDetailsParams(channel, date, apiId, tellerId,
					customerId, branch, token);
			if (validResponse.isValidParams()) {
				// validating token
				RequestTokenObject requestTokenObject = APIHelper.requestObjectTokenBuilder(apiId, tellerId, branch,
						token);
				logger.info("requestTokenObject: " + requestTokenObject.toString());

				tokenResponse = tokenValidatorService.validateToken(requestTokenObject);
				logger.info("tokenResponse: " + tokenResponse.toString());
				// if token valid, proceed. Else, invalid token.
				if (tokenResponse.isTokenValid()) {
					encryptedDataRequest = APIHelper.encryptDataRequestBuilder(apiId, branch, tellerId, "127.0.0.1",
							customerId, encryptedDataService.getPlainDataType(customerId), token);
					logger.info("encryptedDataRequest: " + encryptedDataRequest.toString());
					encryptDataResponse = encryptedDataService.encryptData(encryptedDataRequest);
					logger.info("encryptDataResponse: " + encryptDataResponse.toString());
					journeyDetailsResponse = customerJourneyService
							.getCustomerJourneyDetails(encryptDataResponse.getEncrytedData(), apiId, date);
				} else {
					journeyDetailsResponse.setCode(tokenResponse.getCode());
					journeyDetailsResponse.setMessage(ERROR);
					journeyDetailsResponse.setDescription(tokenResponse.getErrorMessage());
					journeyDetailsResponse.setSource("Mongo-API Validating Token CustomerJourneyController.java [method] getCustomerJourneyDetails()");
				}
			} else {
				journeyDetailsResponse.setCode(validResponse.getCode());
				journeyDetailsResponse.setMessage(ERROR);
				journeyDetailsResponse.setDescription(validResponse.getErrorMessage());
				journeyDetailsResponse.setSource("Mongo-API Validating Parameters CustomerJourneyController.java [method] getCustomerJourneyDetails()");
			}
		} catch (RestClientException e) {
			journeyDetailsResponse.setCode(CODE_ERROR);
			journeyDetailsResponse.setDescription("RestClientException occured during token validator in CustomerJourneyController.java");
			journeyDetailsResponse.setSource("CustomerJourneyController.java [method] getCustomerJourneyDetails()");
			journeyDetailsResponse.setMessage(ERROR);
			ExceptionDetails exceptionDetails = new ExceptionDetails(e);
			logger.error("RestClientException occured during token validator. ", exceptionDetails.toString());
		} catch (NumberFormatException e) {
			journeyDetailsResponse.setCode(CODE_ERROR);
			journeyDetailsResponse.setMessage(ERROR);
			journeyDetailsResponse.setDescription("NumberFormatException occured during token validator");
			journeyDetailsResponse.setSource("CustomerJourneyController.java [method] getCustomerJourneyDetails()");
			ExceptionDetails exceptionDetails = new ExceptionDetails(e);
			logger.error("Exception occured during token validator. " + exceptionDetails.toString()
					+ exceptionDetails.getCode());
		} catch (ParseException e) {
			journeyDetailsResponse.setCode(CODE_ERROR);
			journeyDetailsResponse.setMessage(ERROR);
			journeyDetailsResponse.setDescription("ParseException occured during token validator. ");
			journeyDetailsResponse.setSource("CustomerJourneyController.java [method] getCustomerJourneyDetails()");
			ExceptionDetails exceptionDetails = new ExceptionDetails(e);
			logger.error("ParseException occured during token validator. ", exceptionDetails.toString());
		}
		logger.info("*END* {}", LogServiceHelper.getCurrentClassAndMethodName());
		return journeyDetailsResponse;
	}
}
