package com.api.customerjourney.mongoserviceapi.controller;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.api.cub.mongoserviceapi.controller.ReminderController;
import com.api.cub.mongoserviceapi.domain.ResponseObject;
import com.api.cub.mongoserviceapi.domain.TransformedReminder;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes=ReminderTest.class)
@WebMvcTest(value = ReminderController.class, secure = false)
public class ReminderTest {
	
	@Autowired
	private MockMvc mockMvc;
	
	@MockBean
	private ReminderController mockReminderController;
	
	@Test
	public void testGetReminder() throws Exception {
		Mockito.when(mockReminderController.getReminder(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(getMockReminderData());
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/reminder")
				.accept(MediaType.APPLICATION_JSON).param("ap_id", "CRMLXCRM01").param("teller_id", "13063").param("token", "token")
				.param("branch", "branch1").param("customer_id", "A123456789");
		MvcResult mvcResult = mockMvc.perform(requestBuilder).andReturn();
		
		ObjectMapper mapper =  new ObjectMapper();
		String expectedResult = mapper.writeValueAsString(getMockReminderData());
		String actualResult = mvcResult.getResponse().getContentAsString();
		JSONAssert.assertEquals(expectedResult, actualResult, false);
	}
	
	public ResponseObject<TransformedReminder> getMockReminderData() {
		ResponseObject<TransformedReminder> reminderResponse = new ResponseObject<>();
		reminderResponse.setCode("0000");
		reminderResponse.setMessage("SUCCESS");
		reminderResponse.setDescription("");
		reminderResponse.setSource("");
		TransformedReminder transformedReminder = new TransformedReminder();
		transformedReminder.setApId("SOMEAPID");
		transformedReminder.setAnyActivities(true);
		reminderResponse.setResult(transformedReminder);
		return reminderResponse;
	}
}
