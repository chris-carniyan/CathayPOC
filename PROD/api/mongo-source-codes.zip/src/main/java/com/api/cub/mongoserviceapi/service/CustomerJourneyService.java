package com.api.cub.mongoserviceapi.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import com.api.cub.mongoserviceapi.domain.CustomerJourney;
import com.api.cub.mongoserviceapi.domain.Event;
import com.api.cub.mongoserviceapi.domain.JourneyDetailEvent;
import com.api.cub.mongoserviceapi.domain.ResponseObject;
import com.api.cub.mongoserviceapi.domain.TimeSlot;
import com.api.cub.mongoserviceapi.domain.Timeline;
import com.api.cub.mongoserviceapi.domain.TransformedCustomerJourney;
import com.api.cub.mongoserviceapi.domain.TransformedEvent;
import com.api.cub.mongoserviceapi.domain.TransformedTimeSlot;
import com.api.cub.mongoserviceapi.helper.APIHelper;
import com.api.cub.mongoserviceapi.helper.ExceptionDetails;
import com.api.cub.mongoserviceapi.repository.CustomerJourneyMongoRepository;

@Service
public class CustomerJourneyService {

	private static final Logger logger = LogManager.getLogger(CustomerJourneyService.class);
	@Autowired
	CustomerJourneyMongoRepository customerJourneyRepo;
	@Value("${api.env}")
	private String apiEnv;

	public ResponseObject<TransformedCustomerJourney> getCustomerJourney(String customerId, String apiId)
			throws ParseException {
		ResponseObject<TransformedCustomerJourney> journeyResponse = new ResponseObject<>();
		CustomerJourney customerJourney = new CustomerJourney();
		TransformedCustomerJourney transformedObject = new TransformedCustomerJourney();

		// Get current date
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			Date date = new Date();
			if (apiEnv.equalsIgnoreCase("DEV")) {
				date = sdf.parse("14/04/2018");
			}
			Timeline timeline = APIHelper.getTimelineScope(date);
			logger.info("CurrentDate is: " + timeline.getCurrentDate());
			logger.info("LastTwoWeeksDate is: " + timeline.getLastTwoWeeksDate());
			if (timeline.getCurrentDate() > 0) {
				customerJourney = customerJourneyRepo.findByCustomerIdAndTimeSlotsCurrentDate(customerId,
						timeline.getCurrentDate(), timeline.getLastTwoWeeksDate());
				if (customerJourney != null && customerJourney.getTimeSlot() != null) {
					logger.info("customerJourney is: " + customerJourney.toString());
					transformedObject.setUpdateDate(customerJourney.getUpdateTime());
					transformedObject.setCurrentDate(timeline.getCurrentDate());
					transformedObject.setTimeSlots(convertTimeSlotToTransformedTimeSlot(customerJourney.getTimeSlot()));
					journeyResponse.setResult(transformedObject);
					journeyResponse.setCode("0000");
					journeyResponse.setMessage("Success");
					journeyResponse.setDescription("Success");
				} else {
					journeyResponse.setCode("1001");
					journeyResponse.setDescription("No data was found for the Customer ID.");
					journeyResponse.setMessage("Success");
				}
			}

		} catch (DataAccessException | ParseException e) {
			ExceptionDetails exceptionDetails = new ExceptionDetails(e);
			journeyResponse.setMessage(
					"Error in CustomerJourneyService@ getCustomerJourney() with " + exceptionDetails.getMessage());
			journeyResponse.setCode("1111");
			journeyResponse.setDescription(e.getLocalizedMessage());
			logger.error(exceptionDetails.toString());
		}

		return journeyResponse;

	}

	public ResponseObject<List<JourneyDetailEvent>> getCustomerJourneyDetails(String customerId, String apiId,
			long date) throws ParseException {
		ResponseObject<List<JourneyDetailEvent>> response = new ResponseObject<>();
		CustomerJourney customerJourney = new CustomerJourney();
		try {
			logger.info("date param is: " + date);
			customerJourney = customerJourneyRepo.findCustomerJourneyByCustomerId(customerId);
			if (customerJourney.getCustomerId() != null && customerJourney.getTimeSlot() != null) {
				logger.info("customerJourney is: " + customerJourney.toString());
				response.setMessage("");
				response.setCode("0000");
				response.setResult(convertResponseToJourneyDetailsEvent(customerJourney.getTimeSlot(), date));
			} else {
				response.setMessage("No data was found for the Customer ID.");
				response.setCode("1001");
				response.setResult(new ArrayList<JourneyDetailEvent>());
			}

		} catch (DataAccessException e) {
			ExceptionDetails exceptionDetails = new ExceptionDetails(e);
			response.setMessage("Error in CustomerJourneyService@ getCustomerJourneyDetails() with "
					+ exceptionDetails.getMessage());
			response.setCode("1111");
			response.setDescription(e.getLocalizedMessage());
			logger.error(exceptionDetails.toString());
		}

		return response;
	}

	private List<JourneyDetailEvent> convertResponseToJourneyDetailsEvent(List<TimeSlot> timeslot, long date)
			throws ParseException {
		List<JourneyDetailEvent> journeyDetailEvent = new ArrayList<>();
		if (!timeslot.isEmpty()) {
			for (TimeSlot slot : timeslot) {
				if (slot.getDate() == date) {
					for (Event event : slot.getEvents()) {
						JourneyDetailEvent eventDetails = new JourneyDetailEvent();
						eventDetails.setChannel(event.getChannel());
						eventDetails.setDetail(event.getName());
						eventDetails.setTime(APIHelper.convertStringDateTimeToEpoch(date, event.getTime()));
						journeyDetailEvent.add(eventDetails);
					}
				}

			}
		}
		return journeyDetailEvent;
	}

	private List<TransformedTimeSlot> convertTimeSlotToTransformedTimeSlot(List<TimeSlot> timeslot) {
		List<TransformedTimeSlot> transformedTimeSlots = new ArrayList<>();
		if (!timeslot.isEmpty()) {
			for (TimeSlot slot : timeslot) {
				TransformedTimeSlot tranSlot = new TransformedTimeSlot();
				List<TransformedEvent> tranSlotEvents = new ArrayList<>();

				tranSlot.setTimestamp(slot.getDate());
				for (Event event : slot.getEvents()) {
					TransformedEvent transEvent = new TransformedEvent();
					transEvent.setChannel(event.getChannel());
					tranSlotEvents.add(transEvent);
				}
				tranSlot.setEvents(tranSlotEvents);
				transformedTimeSlots.add(tranSlot);
			}
		}
		return transformedTimeSlots;

	}
}
