package com.api.cub.mongoserviceapi.domain;

public class Timeline {
	private long currentDate;
	private long lastTwoWeeksDate;
	public long getCurrentDate() {
		return currentDate;
	}
	public void setCurrentDate(long currentDate) {
		this.currentDate = currentDate;
	}
	public long getLastTwoWeeksDate() {
		return lastTwoWeeksDate;
	}
	public void setLastTwoWeeksDate(long lastTwoWeeksDate) {
		this.lastTwoWeeksDate = lastTwoWeeksDate;
	}
}
