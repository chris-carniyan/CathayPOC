package com.api.cub.mongoserviceapi.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestClientException;

import com.api.cub.mongoserviceapi.domain.EncryptDataRequest;
import com.api.cub.mongoserviceapi.domain.EncryptDataResponse;
import com.api.cub.mongoserviceapi.domain.ParameterValidationResponse;
import com.api.cub.mongoserviceapi.domain.ProblemPrediction;
import com.api.cub.mongoserviceapi.domain.RequestTokenObject;
import com.api.cub.mongoserviceapi.domain.ResponseObject;
import com.api.cub.mongoserviceapi.domain.TokenValidator;
import com.api.cub.mongoserviceapi.helper.APIHelper;
import com.api.cub.mongoserviceapi.helper.ExceptionDetails;
import com.api.cub.mongoserviceapi.helper.ParameterValidator;
import com.api.cub.mongoserviceapi.service.EncryptedDataService;
import com.api.cub.mongoserviceapi.service.ProblemPredictionService;
import com.api.cub.mongoserviceapi.service.TokenValidatorService;

@CrossOrigin
@RestController
public class ProblemPredictionController {
	private static final Logger logger = LogManager.getLogger(ProblemPredictionController.class);
	private static final String LOGGER_START = "[START @{} ({})]";
	private static final String LOGGER_END = "[END @{} ({})]";
	private static final String ERROR = "ERROR";
	private static final String CODE_ERROR = "1111";

	@Autowired
	TokenValidatorService tokenValidatorService;

	@Autowired
	EncryptedDataService encryptedDataService;

	@Autowired
	ProblemPredictionService problemPredictionService;

	@GetMapping("/ProblemPredict")
	public ResponseObject<ProblemPrediction> getProblemPrediction(@RequestParam(value = "ap_id") String apId,
			@RequestParam(value = "teller_id") String tellerId, @RequestParam(value = "customer_id") String customerId,
			@RequestParam(value = "branch") String branch, @RequestParam(value = "token") String token) {

		logger.info(LOGGER_START, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());

		ParameterValidationResponse validResponse = new ParameterValidationResponse();
		TokenValidator tokenResponse = new TokenValidator();
		ResponseObject<ProblemPrediction> problemPredictionResponse = new ResponseObject<>();
		EncryptDataResponse encryptDataResponse = new EncryptDataResponse();
		EncryptDataRequest encryptedDataRequest = new EncryptDataRequest();

		try {
			logger.info("validating parameters");
			validResponse = ParameterValidator.validateParameters(apId, tellerId, customerId, branch, token);
			if (validResponse.isValidParams()) {
				RequestTokenObject requestTokenObject = APIHelper.requestObjectTokenBuilder(apId, tellerId, branch,
						token);
				logger.info("requestTokenObject: " + requestTokenObject.toString());
				tokenResponse = tokenValidatorService.validateToken(requestTokenObject);

				if (tokenResponse.isTokenValid()) {
					encryptedDataRequest = APIHelper.encryptDataRequestBuilder(apId, branch, tellerId, "127.0.0.1",
							customerId, encryptedDataService.getPlainDataType(customerId), token);
					logger.info("encryptedDataRequest: " + encryptedDataRequest.toString());
					encryptDataResponse = encryptedDataService.encryptData(encryptedDataRequest);
					logger.info("encryptDataResponse: " + encryptDataResponse.toString());
					problemPredictionResponse = problemPredictionService
							.getProblemPrediction(encryptDataResponse.getEncrytedData());
				} else {
					problemPredictionResponse.setCode(tokenResponse.getCode());
					problemPredictionResponse.setMessage(ERROR);
					problemPredictionResponse.setDescription(tokenResponse.getErrorMessage());
					problemPredictionResponse.setSource(
							"Mongo-API Validating Token ProblemPredictionController.java [method] getProblemPrediction()");
				}
			} else {
				problemPredictionResponse.setCode(validResponse.getCode());
				problemPredictionResponse.setMessage(ERROR);
				problemPredictionResponse.setDescription(validResponse.getErrorMessage());
				problemPredictionResponse.setSource(
						"Mongo-API Validating Parameters ProblemPredictionController.java [method] getProblemPrediction()");
			}
		} catch (RestClientException e) {
			problemPredictionResponse.setCode(CODE_ERROR);
			problemPredictionResponse.setMessage(ERROR);
			problemPredictionResponse.setDescription(
					"RestClientException occured during token validator in ProblemPredictionController.java");
			problemPredictionResponse.setSource("ProblemPredictionController.java [method] getProblemPrediction()");
			ExceptionDetails exceptionDetails = new ExceptionDetails(e);
			logger.error("RestClientException occured during token validator.", exceptionDetails.toString());
		} catch (Exception e) {
			problemPredictionResponse.setCode(CODE_ERROR);
			problemPredictionResponse.setMessage(ERROR);
			problemPredictionResponse
					.setDescription("Exception occured during token validator in ProblemPredictionController.java");
			problemPredictionResponse.setSource("ProblemPredictionController.java [method] getProblemPrediction()");
			ExceptionDetails exceptionDetails = new ExceptionDetails(e);
			logger.error("Exception occured during token validator. ", exceptionDetails.toString());
		}

		logger.info(LOGGER_END, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		return problemPredictionResponse;
	}
}
