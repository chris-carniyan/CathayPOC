package com.cathay.api.domain;

public class TransactionSequence {
	
	public TransactionSequence(long currentSequence){
		this.currentSequence = currentSequence;
	}
	
	private long currentSequence;

	public long getCurrentSequence() {
		return currentSequence;
	}

	public void setCurrentSequence(long currentSequence) {
		this.currentSequence = currentSequence;
	}
}
