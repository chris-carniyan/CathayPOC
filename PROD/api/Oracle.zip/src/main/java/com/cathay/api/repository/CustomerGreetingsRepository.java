package com.cathay.api.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.cathay.api.domain.CustomerGreetings;

public interface CustomerGreetingsRepository extends CrudRepository<CustomerGreetings, Long> {

	@Query(value = "SELECT * FROM crm_bir_rpt WHERE rownum<=1 AND customer_id = :customerId ORDER BY seq_no DESC", nativeQuery = true)
	CustomerGreetings findTopByCustomerIdOrderBySeqNoDesc(@Param("customerId") String customerId);

}
