package com.cathay.api.repository;


import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.cathay.api.domain.GiftFile;

public interface GiftFileRepository extends CrudRepository<GiftFile, Long>{
	
	@Query(value = "select * from crm_gift_file_history where date_created = (select max(date_created) from crm_gift_file_history)", nativeQuery = true)
	GiftFile findFirstByOrderByDateCreatedDesc();
	
	@Query(value = "select crm_gift_trans_seq.nextval from dual", nativeQuery = true)
	Long getCurrentTransaction();
}
