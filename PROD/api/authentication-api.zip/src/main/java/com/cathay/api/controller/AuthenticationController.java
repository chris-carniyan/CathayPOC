package com.cathay.api.controller;

import java.sql.Timestamp;
import java.util.Collections;

import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

import com.cathay.api.domain.BaseResponse;
import com.cathay.api.domain.Constants;
import com.cathay.api.domain.CustUniqueNumber;
import com.cathay.api.domain.Header;
import com.cathay.api.domain.RetrieveCustomerIdRequest;
import com.cathay.api.domain.RetrieveCustomerIdResponse;
import com.cathay.api.domain.RetrieveCustomerIdResult;
import com.cathay.api.domain.StoreUniqueNumberRequest;
import com.cathay.api.domain.ValidateTrustKeyRequest;
import com.cathay.api.domain.ValidateTrustKeyResponse;
import com.cathay.api.repository.CustUniqueNumberRepository;

@CrossOrigin
@RestController
public class AuthenticationController {

	private static final Logger LOGGER = LogManager.getLogger(AuthenticationController.class);

	@Value("${validate-trust-key}")
	protected String validateTrustKeyUrl;

	@Autowired
	CustUniqueNumberRepository custUniqueNumberRepository;

	private RestTemplate restTemplate;

	@Autowired
	protected AuthenticationController(RestTemplate restTemplate,
			CustUniqueNumberRepository custUniqueNumberRepository) {
		this.restTemplate = restTemplate;
		this.custUniqueNumberRepository = custUniqueNumberRepository;
	}

	@Value("${expire.hours}")
	private int expireHours;

	@PostMapping("${mapping.store-unique-number}")
	public BaseResponse storeUniqueNumber(@Valid @RequestBody StoreUniqueNumberRequest request) {
		LOGGER.info(Constants.LOGGER_START, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		LOGGER.info(Constants.STORE_UNIQUE_NUMBER_REQUEST, request);
		BaseResponse response = null;

		try {
			ValidateTrustKeyResponse validateTrustKeyResponse = validateTrustKey(request.getTrustKey(),
					request.getHeader());

			if (validateTrustKeyResponse.getCode().equals(Constants.SUCCESS_CODE)) {
				CustUniqueNumber custUniqueNumber = new CustUniqueNumber(request.getUniqueNumber(),
						request.getCustomerId(), request.getHeader().getApId(), expireHours);

				if (custUniqueNumberRepository.save(custUniqueNumber) == null) {
					response = new BaseResponse(Constants.INSERT_ERROR_CODE, Constants.STORE_UNIQUE_NUMBER_FAILED);
				} else {
					response = new BaseResponse(Constants.SUCCESS_CODE);
				}
			} else {
				response = new BaseResponse(validateTrustKeyResponse.getCode(), validateTrustKeyResponse.getDesc());
			}
		} catch (DataIntegrityViolationException e) {
			LOGGER.error(Constants.DATA_INTEGRITY_VIOLATION_ERROR, e);
			response = new BaseResponse(Constants.DATA_INTEGRITY_CODE, Constants.DATA_INTEGRITY_VIOLATION_ERROR);
		} catch (Exception e) {
			LOGGER.error(Constants.GENERIC_ERROR, e);
			response = new BaseResponse(Constants.ERROR_CODE, Constants.GENERIC_ERROR);
		}

		LOGGER.info(Constants.STORE_UNIQUE_NUMBER_RESPONSE, response);
		LOGGER.info(Constants.LOGGER_END, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		return response;
	}

	@PostMapping("${mapping.retrieve-customer-id}")
	public RetrieveCustomerIdResponse retrieveCustomerId(@Valid @RequestBody RetrieveCustomerIdRequest request) {
		LOGGER.info(Constants.LOGGER_START, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		LOGGER.info(Constants.RETRIEVE_CUSTOMER_ID_REQUEST, request);

		RetrieveCustomerIdResponse response = null;

		try {
			ValidateTrustKeyResponse validateTrustKeyResponse = validateTrustKey(request.getTrustKey(),
					request.getHeader());

			if (validateTrustKeyResponse.getCode().equals(Constants.SUCCESS_CODE)) {
				CustUniqueNumber custUniqueNumber = custUniqueNumberRepository
						.findByUniqueNumber(request.getUniqueNumber());

				if (custUniqueNumber != null) {
					if (new Timestamp(System.currentTimeMillis()).after(custUniqueNumber.getExpireTime())) {
						LOGGER.error(Constants.UNIQUE_NUMBER_EXPIRED);
						response = new RetrieveCustomerIdResponse(Constants.UNIQUE_NUMBER_EXPIRED_CODE,
								Constants.UNIQUE_NUMBER_EXPIRED);
					} else {
						RetrieveCustomerIdResult result = new RetrieveCustomerIdResult(
								custUniqueNumber.getCustomerId());
						response = new RetrieveCustomerIdResponse(result);
					}
				} else {
					LOGGER.error(Constants.UNIQUE_NUMBER_NOT_FOUND);
					response = new RetrieveCustomerIdResponse(Constants.UNIQUE_NUMBER_NOT_FOUND_CODE,
							Constants.UNIQUE_NUMBER_NOT_FOUND);
				}
			} else {
				response = new RetrieveCustomerIdResponse(validateTrustKeyResponse.getCode(),
						validateTrustKeyResponse.getDesc());
			}
		} catch (DataAccessException e) {
			LOGGER.error(Constants.DATA_ACCESS_ERROR, e);
			response = new RetrieveCustomerIdResponse(String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()),
					Constants.DATA_ACCESS_ERROR);
		} catch (Exception e) {
			LOGGER.error(Constants.GENERIC_ERROR, e);
			response = new RetrieveCustomerIdResponse(Constants.ERROR_CODE, Constants.GENERIC_ERROR);
		}

		LOGGER.info(Constants.RETRIEVE_CUSTOMER_ID_RESPONSE, response);
		LOGGER.info(Constants.LOGGER_END, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		return response;
	}

	private ValidateTrustKeyResponse validateTrustKey(String trustKey, Header header) {
		ValidateTrustKeyRequest request = new ValidateTrustKeyRequest(header, trustKey);
		LOGGER.info(Constants.VALIDATE_TRUST_KEY_REQUEST, request);
		ValidateTrustKeyResponse response = null;

		try {
			if (restTemplate == null) {
				restTemplate = new RestTemplate();
			}

			HttpHeaders httpHeaders = new HttpHeaders();
			httpHeaders.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
			httpHeaders.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<?> entity = new HttpEntity<>(request, httpHeaders);
			response = restTemplate.postForObject(validateTrustKeyUrl, entity, ValidateTrustKeyResponse.class);
		} catch (ResourceAccessException e) {
			String description = String.format(Constants.RESOURCE_ACCESS_ERROR, validateTrustKeyUrl);
			LOGGER.error(description, e);
			response = new ValidateTrustKeyResponse(String.valueOf(HttpStatus.REQUEST_TIMEOUT.value()), description);
		} catch (HttpClientErrorException e) {
			String description = String.format(Constants.VALIDATE_TRUST_KEY_HTTP_ERROR, validateTrustKeyUrl);
			LOGGER.error(description, e);
			response = new ValidateTrustKeyResponse(e.getStatusCode().toString(), description);
		} catch (Exception e) {
			LOGGER.error(Constants.GENERIC_ERROR, e);
			response = new ValidateTrustKeyResponse(Constants.ERROR_CODE, Constants.GENERIC_ERROR);
		}

		LOGGER.info(Constants.VALIDATE_TRUST_KEY_RESPONSE, response);
		return response;
	}
}
