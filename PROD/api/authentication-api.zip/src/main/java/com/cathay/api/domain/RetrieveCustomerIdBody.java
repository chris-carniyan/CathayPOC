package com.cathay.api.domain;

public class RetrieveCustomerIdBody  {
	private String customerId;
	
	public RetrieveCustomerIdBody(String customerId){
		this.customerId = customerId;
	}


	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
}
