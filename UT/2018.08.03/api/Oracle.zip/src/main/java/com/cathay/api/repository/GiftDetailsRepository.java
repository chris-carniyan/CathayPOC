package com.cathay.api.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.cathay.api.domain.GiftDetails;

public interface GiftDetailsRepository extends CrudRepository<GiftDetails, Long>{
	
	@Query(value = "SELECT * FROM crm_gift_details WHERE rownum<=1 AND pid = :pid AND file_seq_no = :fileSeqNo", nativeQuery = true)
	GiftDetails findOneByPidAndFileSeqNo(@Param("pid") String pid, @Param("fileSeqNo") long fileSeqNo);

}
