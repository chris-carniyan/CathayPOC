package com.cathay.api.domain;

import javax.validation.Valid;

import org.hibernate.validator.constraints.NotBlank;

public class RemindersRequest {

	@Valid
	private Header header;

	@NotBlank
	private String campaignCode;

	@NotBlank
	private String trustKey;

	public String getCampaignCode() {
		return campaignCode;
	}

	public void setCampaignCode(String campaignCode) {
		this.campaignCode = campaignCode;
	}

	public RemindersRequest() {
		super();
	}

	public Header getHeader() {
		return header;
	}

	public void setHeader(Header header) {
		this.header = header;
	}

	public String getTrustKey() {
		return trustKey;
	}

	public void setTrustKey(String trustKey) {
		this.trustKey = trustKey;
	}

	@Override
	public String toString() {
		return new StringBuilder(
				"{header=" + header + ", campaignCode=" + campaignCode + ", trustKey=" + trustKey + "}").toString();
	}

}
