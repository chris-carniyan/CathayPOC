package com.cathay.api.domain;

import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "crm_gift_file_history")
public class GiftFile {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "crm_gift_file_history_seq")
	@SequenceGenerator(sequenceName = "crm_gift_file_history_seq", initialValue = 1, allocationSize = 1, name = "crm_gift_file_history_seq")
	@Column(name = "seq_no")
	private long seqNo;
	
	@Column(name = "file_name")
	private String fileName;
	
	@Column(name = "date_created")
	private Timestamp dateCreated;

	public long getSeqNo() {
		return seqNo;
	}

	public void setSeqNo(long seqNo) {
		this.seqNo = seqNo;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public Timestamp getDateCreated() {
		return dateCreated;
	}
	
	public void setDateCreated(Timestamp dateCreated) {
		this.dateCreated = dateCreated;
	}

}


