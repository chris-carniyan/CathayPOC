package com.cathay.api.controller;

import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cathay.api.domain.CommonRequest;
import com.cathay.api.domain.CommonResponse;
import com.cathay.api.domain.Constants;
import com.cathay.api.domain.GetCardsRequest;
import com.cathay.api.domain.ValidateTrustKeyResponse;
import com.cathay.api.service.FinancialProductsService;
import com.cathay.api.service.TrustKeyService;

@CrossOrigin
@RestController
public class FinancialProductsController {

	private static final Logger LOGGER = LogManager.getLogger(FinancialProductsController.class);

	@Autowired
	TrustKeyService trustKeyService;

	@Autowired
	FinancialProductsService financialProductsService;

	@PostMapping("${mapping.get-customer-financial-products}")
	public CommonResponse getCustomerFinancialProducts(@RequestBody @Valid CommonRequest request) {
		LOGGER.info(Constants.LOGGER_START, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		LOGGER.info(Constants.FINANCIAL_PRODUCTS_REQUEST, request);

		CommonResponse response = null;

		ValidateTrustKeyResponse validateTrustKeyResponse = trustKeyService.validateTrustKey(request.getHeader(),
				request.getTrustKey());

		if (validateTrustKeyResponse.getCode().equals(Constants.SUCCESS_CODE)) {
			response = financialProductsService.getCustomerFinancialProducts(request.getCustomerId());
		} else {
			response = new CommonResponse(validateTrustKeyResponse.getCode(), Constants.ERROR_MESSAGE,
					validateTrustKeyResponse.getDesc(), Constants.SOURCE);
		}

		LOGGER.info(Constants.FINANCIAL_PRODUCTS_RESPONSE, response);
		LOGGER.info(Constants.LOGGER_END, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());

		return response;
	}

	@PostMapping("${mapping.retrieve-cards}")
	public CommonResponse getCards(@RequestBody @Valid GetCardsRequest request) {
		LOGGER.info(Constants.LOGGER_START, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());

		if (request.getQueryCardInd().equalsIgnoreCase("P")) {
			LOGGER.info(Constants.PRIMARY_CARDS_REQUEST, request);
		} else if (request.getQueryCardInd().equalsIgnoreCase("S")) {
			LOGGER.info(Constants.SECONDARY_CARDS_REQUEST, request);
		} else if (request.getQueryCardInd().equalsIgnoreCase("B")) {
			LOGGER.info(Constants.BUSINESS_CARDS_REQUEST, request);
		} else if (request.getQueryCardInd().equalsIgnoreCase("F")) {
			LOGGER.info(Constants.PRIMARY_HAS_SECONDARY_CARDS_REQUEST, request);
		}

		CommonResponse response = null;

		ValidateTrustKeyResponse validateTrustKeyResponse = trustKeyService.validateTrustKey(request.getHeader(),
				request.getTrustKey());

		if (validateTrustKeyResponse.getCode().equals(Constants.SUCCESS_CODE)) {
			response = financialProductsService.getCards(request.getCustomerId(), request.getQueryCardInd());
		} else {
			response = new CommonResponse(validateTrustKeyResponse.getCode(), Constants.ERROR_MESSAGE,
					validateTrustKeyResponse.getDesc(), Constants.SOURCE);
		}

		if (request.getQueryCardInd().equalsIgnoreCase("P")) {
			LOGGER.info(Constants.PRIMARY_CARDS_RESPONSE, response);
		} else if (request.getQueryCardInd().equalsIgnoreCase("S")) {
			LOGGER.info(Constants.SECONDARY_CARDS_RESPONSE, response);
		} else if (request.getQueryCardInd().equalsIgnoreCase("B")) {
			LOGGER.info(Constants.BUSINESS_CARDS_RESPONSE, response);
		} else if (request.getQueryCardInd().equalsIgnoreCase("F")) {
			LOGGER.info(Constants.PRIMARY_HAS_SECONDARY_CARDS_RESPONSE, response);
		}

		LOGGER.info(Constants.LOGGER_END, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());

		return response;
	}

	@PostMapping("${mapping.retrieve-payment-habits}")
	public CommonResponse getPaymentHabits(@RequestBody @Valid CommonRequest request) {
		LOGGER.info(Constants.LOGGER_START, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		LOGGER.info(Constants.PAYMENT_HABITS_REQUEST, request);

		CommonResponse response = null;

		ValidateTrustKeyResponse validateTrustKeyResponse = trustKeyService.validateTrustKey(request.getHeader(),
				request.getTrustKey());

		if (validateTrustKeyResponse.getCode().equals(Constants.SUCCESS_CODE)) {
			response = financialProductsService.getPaymentHabits(request.getCustomerId());
		} else {
			response = new CommonResponse(validateTrustKeyResponse.getCode(), Constants.ERROR_MESSAGE,
					validateTrustKeyResponse.getDesc(), Constants.SOURCE);
		}

		LOGGER.info(Constants.PAYMENT_HABITS_RESPONSE, response);
		LOGGER.info(Constants.LOGGER_END, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());

		return response;
	}

	@PostMapping("${mapping.retrieve-auto-account-debiting}")
	public CommonResponse getAutoAccountDebiting(@RequestBody @Valid CommonRequest request) {
		LOGGER.info(Constants.LOGGER_START, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		LOGGER.info(Constants.AUTO_ACCOUNT_DEBITING_REQUEST, request);

		CommonResponse response = null;

		ValidateTrustKeyResponse validateTrustKeyResponse = trustKeyService.validateTrustKey(request.getHeader(),
				request.getTrustKey());

		if (validateTrustKeyResponse.getCode().equals(Constants.SUCCESS_CODE)) {
			response = financialProductsService.getAutoAccountDebiting(request.getCustomerId());
		} else {
			response = new CommonResponse(validateTrustKeyResponse.getCode(), Constants.ERROR_MESSAGE,
					validateTrustKeyResponse.getDesc(), Constants.SOURCE);
		}

		LOGGER.info(Constants.AUTO_ACCOUNT_DEBITING_RESPONSE, response);
		LOGGER.info(Constants.LOGGER_END, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());

		return response;
	}

	@PostMapping("${mapping.retrieve-utility-payments}")
	public CommonResponse getUtilityBillsPayments(@RequestBody @Valid CommonRequest request) {
		LOGGER.info(Constants.LOGGER_START, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		LOGGER.info(Constants.UTILITY_BILLS_PAYMENT_REQUEST, request);

		CommonResponse response = null;

		ValidateTrustKeyResponse validateTrustKeyResponse = trustKeyService.validateTrustKey(request.getHeader(),
				request.getTrustKey());

		if (validateTrustKeyResponse.getCode().equals(Constants.SUCCESS_CODE)) {
			response = financialProductsService.getUtilityBillsPayments(request.getCustomerId());
		} else {
			response = new CommonResponse(validateTrustKeyResponse.getCode(), Constants.ERROR_MESSAGE,
					validateTrustKeyResponse.getDesc(), Constants.SOURCE);
		}

		LOGGER.info(Constants.UTILITY_BILLS_PAYMENT_RESPONSE, response);
		LOGGER.info(Constants.LOGGER_END, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());

		return response;
	}

	@PostMapping("${mapping.retrieve-savings}")
	public CommonResponse getSavings(@RequestBody @Valid CommonRequest request) {
		LOGGER.info(Constants.LOGGER_START, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		LOGGER.info(Constants.SAVINGS_REQUEST, request);

		CommonResponse response = null;

		ValidateTrustKeyResponse validateTrustKeyResponse = trustKeyService.validateTrustKey(request.getHeader(),
				request.getTrustKey());

		if (validateTrustKeyResponse.getCode().equals(Constants.SUCCESS_CODE)) {
			response = financialProductsService.getSavings(request.getCustomerId());
		} else {
			response = new CommonResponse(validateTrustKeyResponse.getCode(), Constants.ERROR_MESSAGE,
					validateTrustKeyResponse.getDesc(), Constants.SOURCE);
		}

		LOGGER.info(Constants.SAVINGS_RESPONSE, response);
		LOGGER.info(Constants.LOGGER_END, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());

		return response;
	}
}
