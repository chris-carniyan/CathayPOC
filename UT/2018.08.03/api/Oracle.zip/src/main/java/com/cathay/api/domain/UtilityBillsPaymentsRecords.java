package com.cathay.api.domain;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "v_crm_event_cc_public_txn")
public class UtilityBillsPaymentsRecords {

	@Id
	@Column(name = "ROWID")
	@JsonIgnore
	String rowid;

	@JsonIgnore
	@Column(name = "customer_id")
	private String customerId;

	@Column(name = "card_nbr")
	private String cardNbr;

	@Column(name = "txn_date")
	private Date txnDate;

	@Column(name = "merchant_name")
	private String merchantName;

	@Column(name = "txn_amt")
	private double txnAmt;

	public UtilityBillsPaymentsRecords() {
		super();
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getCardNbr() {
		return cardNbr;
	}

	public void setCardNbr(String cardNbr) {
		this.cardNbr = cardNbr;
	}

	public Date getTxnDate() {
		return txnDate;
	}

	public void setTxnDate(Date txnDate) {
		this.txnDate = txnDate;
	}

	public String getMerchantName() {
		return merchantName;
	}

	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}

	public double getTxnAmt() {
		return txnAmt;
	}

	public void setTxnAmt(double txnAmt) {
		this.txnAmt = txnAmt;
	}

	@Override
	public String toString() {
		return "UtilityBillsPaymentsRecords [customerId=" + customerId + ", cardNbr=" + cardNbr + ", txnDate=" + txnDate
				+ ", merchantName=" + merchantName + ", txnAmt=" + txnAmt + "]";
	}
}
