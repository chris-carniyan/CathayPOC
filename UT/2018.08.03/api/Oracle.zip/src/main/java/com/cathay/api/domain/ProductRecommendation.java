package com.cathay.api.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "crm_referral_rpt")
public class ProductRecommendation {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "crm_referral_rpt_sequence")
	@SequenceGenerator(sequenceName = "crm_referral_rpt_sequence", initialValue = 1, allocationSize = 1, name = "crm_referral_rpt_sequence")
	@Column(name = "seq_no")
	private Long seqNo;

	@Column(name = "customer_id")
	private String customerId;

	@Column(name = "customer_name")
	private String customerName;

	@Column(name = "product_name")
	private String productName;

	@Column(name = "customer_tag")
	private String customerTag;

	@Column(name = "ref_result")
	private String refResult;

	@Column(name = "ref_method")
	private String refMethod;

	@Column(name = "ref_source")
	private String refSource;

	@Column(name = "ob_employee_no")
	private String obEmployeeNo;

	@Column(name = "ob_emp_last_name")
	private String obEmployeeLastName;

	@Column(name = "cti_employee_no")
	private String ctiEmployeeNo;

	@Column(name = "ref_date")
	private String refDate;

	@Column(name = "ref_time")
	private String refTime;

	public ProductRecommendation() {
		super();
	}

	public ProductRecommendation(StoreRecommendationRequest storeRecommendationRequest) {
		super();
		customerId = storeRecommendationRequest.getCustomerId();
		customerName = storeRecommendationRequest.getCustomerName();
		productName = storeRecommendationRequest.getProductName();
		customerTag = storeRecommendationRequest.getCustomerTag();
		refResult = storeRecommendationRequest.getRefResult();
		refMethod = storeRecommendationRequest.getRefMethod();
		refSource = storeRecommendationRequest.getRefSource();
		obEmployeeNo = storeRecommendationRequest.getObEmployeeNo();
		obEmployeeLastName = storeRecommendationRequest.getObEmployeeLastName();
		ctiEmployeeNo = storeRecommendationRequest.getHeader().getEmployeeId();
		refDate = storeRecommendationRequest.getRefDate();
		refTime = storeRecommendationRequest.getRefTime();
	}

	public Long getSeqNo() {
		return seqNo;
	}

	public void setSeqNo(Long seqNo) {
		this.seqNo = seqNo;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getCustomerTag() {
		return customerTag;
	}

	public void setCustomerTag(String customerTag) {
		this.customerTag = customerTag;
	}

	public String getRefResult() {
		return refResult;
	}

	public void setRefResult(String refResult) {
		this.refResult = refResult;
	}

	public String getRefMethod() {
		return refMethod;
	}

	public void setRefMethod(String refMethod) {
		this.refMethod = refMethod;
	}

	public String getRefSource() {
		return refSource;
	}

	public void setRefSource(String refSource) {
		this.refSource = refSource;
	}

	public String getObEmployeeNo() {
		return obEmployeeNo;
	}

	public void setObEmployeeNo(String obEmployeeNo) {
		this.obEmployeeNo = obEmployeeNo;
	}

	public String getObEmployeeLastName() {
		return obEmployeeLastName;
	}

	public void setObEmployeeLastName(String obEmployeeLastName) {
		this.obEmployeeLastName = obEmployeeLastName;
	}

	public String getCtiEmployeeNo() {
		return ctiEmployeeNo;
	}

	public void setCtiEmployeeNo(String ctiEmployeeNo) {
		this.ctiEmployeeNo = ctiEmployeeNo;
	}

	public String getRefDate() {
		return refDate;
	}

	public void setRefDate(String refDate) {
		this.refDate = refDate;
	}

	public String getRefTime() {
		return refTime;
	}

	public void setRefTime(String refTime) {
		this.refTime = refTime;
	}

	@Override
	public String toString() {
		return new StringBuilder("{seqNo=" + seqNo + ", customerId=" + customerId + ", customerName=" + customerName
				+ ", productName=" + productName + ", customerTag=" + customerTag + ", refResult=" + refResult
				+ ", refMethod=" + refMethod + ", refSource=" + refSource + ", obEmployeeNo=" + obEmployeeNo
				+ ", obEmployeeLastName=" + obEmployeeLastName + ", ctiEmployeeNo=" + ctiEmployeeNo + ", refDate="
				+ refDate + ", refTime=" + refTime + "}").toString();
	}
}
