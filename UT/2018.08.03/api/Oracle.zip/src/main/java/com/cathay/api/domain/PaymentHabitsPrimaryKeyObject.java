package com.cathay.api.domain;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class PaymentHabitsPrimaryKeyObject implements Serializable {

	private static final long serialVersionUID = 740670778679380733L;

	@Column(name = "stmt_year_month")
	private String stmtYearMonth;

	@Column(name = "txn_date")
	private Date txnDate;

	@Column(name = "pay_channel_type_desc")
	private String payChannelTypeDesc;

	@Column(name = "pay_amt")
	private double payAmt;

	public PaymentHabitsPrimaryKeyObject() {
	}

	public PaymentHabitsPrimaryKeyObject(String stmtYearMonth, Date txnDate, String payChannelTypeDesc) {
		super();
		this.stmtYearMonth = stmtYearMonth;
		this.txnDate = txnDate;
		this.payChannelTypeDesc = payChannelTypeDesc;
	}

	public String getStmtYearMonth() {
		return stmtYearMonth;
	}

	public void setStmtYearMonth(String stmtYearMonth) {
		this.stmtYearMonth = stmtYearMonth;
	}

	public Date getTxnDate() {
		return txnDate;
	}

	public void setTxnDate(Date txnDate) {
		this.txnDate = txnDate;
	}

	public String getPayChannelTypeDesc() {
		return payChannelTypeDesc;
	}

	public void setPayChannelTypeDesc(String payChannelTypeDesc) {
		this.payChannelTypeDesc = payChannelTypeDesc;
	}

	public double getPayAmt() {
		return payAmt;
	}

	public void setPayAmt(double payAmt) {
		this.payAmt = payAmt;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		long temp;
		temp = Double.doubleToLongBits(payAmt);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((payChannelTypeDesc == null) ? 0 : payChannelTypeDesc.hashCode());
		result = prime * result + ((stmtYearMonth == null) ? 0 : stmtYearMonth.hashCode());
		result = prime * result + ((txnDate == null) ? 0 : txnDate.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!(obj instanceof PaymentHabitsPrimaryKeyObject)) {
			return false;
		}
		PaymentHabitsPrimaryKeyObject other = (PaymentHabitsPrimaryKeyObject) obj;
		if (Double.doubleToLongBits(payAmt) != Double.doubleToLongBits(other.payAmt)) {
			return false;
		}
		if (payChannelTypeDesc == null) {
			if (other.payChannelTypeDesc != null) {
				return false;
			}
		} else if (!payChannelTypeDesc.equals(other.payChannelTypeDesc)) {
			return false;
		}
		if (stmtYearMonth == null) {
			if (other.stmtYearMonth != null) {
				return false;
			}
		} else if (!stmtYearMonth.equals(other.stmtYearMonth)) {
			return false;
		}
		if (txnDate == null) {
			if (other.txnDate != null) {
				return false;
			}
		} else if (!txnDate.equals(other.txnDate)) {
			return false;
		}
		return true;
	}

}
