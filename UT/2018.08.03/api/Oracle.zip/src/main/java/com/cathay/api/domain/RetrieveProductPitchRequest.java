package com.cathay.api.domain;

import javax.validation.Valid;

import org.hibernate.validator.constraints.NotBlank;

public class RetrieveProductPitchRequest {

	@Valid
	private Header header;
	@NotBlank
	private String pitchClassify;
	@NotBlank
	private String trustKey;

	public Header getHeader() {
		return header;
	}

	public void setHeader(Header header) {
		this.header = header;
	}

	public String getPitchClassify() {
		return pitchClassify;
	}

	public void setPitchClassify(String pitchClassify) {
		this.pitchClassify = pitchClassify;
	}

	public String getTrustKey() {
		return trustKey;
	}

	public void setTrustKey(String trustKey) {
		this.trustKey = trustKey;
	}

	@Override
	public String toString() {
		return new StringBuilder(
				"{header=" + header + ", pitchClassify=" + pitchClassify + ", trustKey=" + trustKey + "}").toString();
	}

}
