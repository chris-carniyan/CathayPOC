package com.cathay.api.domain;

import javax.validation.Valid;

import org.hibernate.validator.constraints.NotBlank;

public class GetCardsRequest {

	@Valid
	private Header header;
	@NotBlank
	private String customerId;
	@NotBlank
	private String trustKey;
	@NotBlank
	private String queryCardInd;

	public GetCardsRequest() {
		super();
	}

	public Header getHeader() {
		return header;
	}

	public String getCustomerId() {
		return customerId;
	}

	public String getTrustKey() {
		return trustKey;
	}

	public String getQueryCardInd() {
		return queryCardInd;
	}

	public void setHeader(Header header) {
		this.header = header;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public void setTrustKey(String trustKey) {
		this.trustKey = trustKey;
	}

	public void setQueryCardInd(String queryCardInd) {
		this.queryCardInd = queryCardInd;
	}

	@Override
	public String toString() {
		return new StringBuilder("{header=" + header + ", customerId=" + customerId + ", trustKey=" + trustKey
				+ ", queryCardInd=" + queryCardInd + "}").toString();
	}
}
