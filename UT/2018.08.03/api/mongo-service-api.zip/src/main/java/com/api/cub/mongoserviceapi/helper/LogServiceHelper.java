package com.api.cub.mongoserviceapi.helper;

public class LogServiceHelper {
	private LogServiceHelper() {
		super();
	}

	public static String getCurrentClassAndMethodName() { 
		return Thread.currentThread().getStackTrace()[2].getClassName() + "." + 
				Thread.currentThread().getStackTrace()[2].getMethodName() + "()"; 
	}
}
