package com.api.cub.mongoserviceapi.domain;

import java.util.List;


public class TransformedCustomerJourney {
	private List<TransformedTimeSlot> timeSlots;
	private long updateDate;
	private long currentDate;
	
	public List<TransformedTimeSlot> getTimeSlots() {
		return timeSlots;
	}
	public void setTimeSlots(List<TransformedTimeSlot> timeSlots) {
		this.timeSlots = timeSlots;
	}
	public long getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(long updateDate) {
		this.updateDate = updateDate;
	}
	public long getCurrentDate() {
		return currentDate;
	}
	public void setCurrentDate(long currentDate) {
		this.currentDate = currentDate;
	}
	@Override
	public String toString() {
		return "TransformedCustomerJourney [timeSlots=" + timeSlots + ", updateDate=" + updateDate + ", currentDate="
				+ currentDate + "]";
	}
	
	
}
