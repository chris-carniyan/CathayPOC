package com.cathay.audit.api.service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cathay.audit.api.domain.AppAuditTrail;
import com.cathay.audit.api.domain.CommonResponse;
import com.cathay.audit.api.domain.Constants;
import com.cathay.audit.api.repository.AppAuditTrailRepository;

@Service
public class AppAuditTrailService {
	
	private static final Logger LOGGER = LogManager.getLogger(AppAuditTrailService.class);
	
	@Autowired
	AppAuditTrailRepository appAuditTrailRepository;
	
	public CommonResponse insertAppAuditTrail(AppAuditTrail appAuditTrail) {
		LOGGER.info(Constants.LOGGER_START, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		
		CommonResponse responseBody = new CommonResponse();
		
		try {
			DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
			Date date = new Date();
//			date = sdf.parse(appAuditTrail.getDateTime());
			String txnDateTime = sdf.format(date);
			appAuditTrail.setDateTime(txnDateTime);
			
			AppAuditTrail returnedAppAuditTrail = appAuditTrailRepository.save(appAuditTrail);
			
			if (returnedAppAuditTrail == null) {
				LOGGER.error(Constants.APP_AUDIT_TRAIL_SAVE_UNSUCCESSFUL);
				return new CommonResponse(Constants.ERROR_CODE, Constants.ERROR_MESSAGE,
						Constants.APP_AUDIT_TRAIL_SAVE_UNSUCCESSFUL, Constants.SOURCE);
			}
			
			responseBody = new CommonResponse(Constants.SUCCESS_CODE, Constants.SUCCESS_MESSAGE);
			
		} catch (Exception e) {
			LOGGER.error(Constants.GENERIC_ERROR, e);
			responseBody = new CommonResponse(Constants.ERROR_CODE, Constants.ERROR_MESSAGE, Constants.GENERIC_ERROR,
					Constants.SOURCE);
		}
		
		
		LOGGER.info(Constants.LOGGER_END, this.getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());
		return responseBody;
	}

}
