import React from "react";

const restrictedAccessPage = ({ message }) => (
  <div className="retrictedAccessContainer">
    <div className="retrictedAccessMessage">{message}</div>
  </div>
);

export default restrictedAccessPage;
