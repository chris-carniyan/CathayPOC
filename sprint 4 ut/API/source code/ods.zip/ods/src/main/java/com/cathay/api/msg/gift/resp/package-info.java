
@XmlSchema(
		namespace="http://www.cathaybk.com.tw/webservice/mis99",
		elementFormDefault=javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.cathay.api.msg.gift.resp;

import javax.xml.bind.annotation.XmlSchema;
