
@XmlSchema(
		xmlns = { 
			      @javax.xml.bind.annotation.XmlNs(prefix = "tem", 
			                 namespaceURI="http://tempuri.org/")        
			    },
		elementFormDefault=javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.cathay.api.ods.gift;

import javax.xml.bind.annotation.XmlSchema;
